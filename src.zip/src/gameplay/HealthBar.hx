package gameplay;

/**
	The playfield's health bar.
	This is an internal structure and should only be used inside of the playfield NOT to be touched with.
	It is used to display the health of the player and the opponent, with a bar that tries to mimic rpg fighting games like flixel's `FlxBar` is intended to do.
	This class is responsible for rendering the health bar and updating it based on the player's health.
	It also handles the health icons that are displayed above the health bar, which represent the player's and opponent's health status.
	It is also responsible for updating the health bar's position and size based on the playfield's properties, such as the down scroll and the flip health bar settings.
	@since Development
**/
@:publicFields
class HealthBar {
	static var hbBuf(default, null):Buffer<HealthBarSprite>;
	static var hbProg(default, null):CustomProgram;

	var display(default, null):CustomDisplay;
	var parent(default, null):PlayField;

	var parts(default, null):Array<HealthBarSprite> = [];
	var bg(default, null):HealthBarSprite;

	var healthIcons(default, null):Array<HealthBarSprite> = [];
	var healthIconIDs(default, null):Array<Array<Int>> = [[0, 1], [2, 3]];

	var customHealthBarColorEnabled:Bool;
	var healthIconColors:Array<Array<Color>> = [
		[Color.WHITE, Color.BLUE, Color.YELLOW, Color.RED3, Color.GREY2, Color.CYAN],
		[Color.LIME, Color.LIME, Color.LIME, Color.LIME, Color.LIME, Color.LIME]
	];

	// Editor-mode actor data (see actorDataAt): Field's character trio
	// (gf/dad/bfSgwlfnf — Field.SPECTATOR_NAME etc.), each one's
	// charData.json parsed once and cached. No Field, no sprites, no
	// stage. Indexed like Field.actors: [0]=spectator, [1]=opponent,
	// [2]=player. THIS mirrors the same names Field builds actors from,
	// so the editor's icons/palette match gameplay by construction.
	var _editorActorData:Array<ActorData> = null;

	/**
		ActorData for actor slot `index` (Field.actors layout), or null.
		Gameplay: straight from the real actors. Editor mode: parsed from
		the SAME characters Field would build (no Field exists there) —
		this is what makes the editor health icons match the game's.
	**/
	function actorDataAt(index:Int):ActorData {
		var field = parent.field;
		if (field != null) {
			var actor = field.actors[index];
			return actor != null ? actor.data : null;
		}

		if (index < 0 || index > 2)
			return null;

		if (_editorActorData == null) {
			_editorActorData = [null, null, null];
			var folder = "images/characters/";
			var names = [Field.SPECTATOR_NAME, Field.OPPONENT_NAME, Field.PLAYER_NAME];
			for (i => name in names) {
				var path = 'assets/$folder$name/charData.json';
				if (name == null || !sys.FileSystem.exists(path))
					continue;
				try {
					_editorActorData[i] = ActorData.parse(path);
				} catch (e:Dynamic) {
					// Unparseable/missing char data — that slot keeps the
					// default palette/icons (null below).
				}
			}
		}
		return _editorActorData[index];
	}

	var healthBarWS(default, null):Float;
	var healthBarHS(default, null):Float;
	var healthBarXA(default, null):Float;
	var healthBarYA(default, null):Float;

	public static var tex:Texture;

	// var playerOGIcon:Any; // Tracks the player's original icon.

	/**
		Initializes the health bar.
		@param display The display to initialize the health bar on. Should be the playfield's display.
	**/
	static function init(display:CustomDisplay) {
		if (hbBuf == null) {
			hbBuf = new Buffer<HealthBarSprite>(16, 16);
			hbProg = new CustomProgram(hbBuf);

			tex = TextureSystem.getTexture("hbTex");
			HealthBarSprite.init(hbProg, "hbTex", tex);
		}
	}

	/**
		Initializes the health bar.
		@param display The display to initialize the health bar on. Should be the playfield's display.
		@param parent The playfield to initialize the health bar on.
	**/
	function new(display:CustomDisplay, parent:PlayField) {
		this.display = display;
		this.parent = parent;

		display.addProgram(hbProg);

		healthBarWS = HealthBarSprite.healthBarProperties[2];
		healthBarHS = HealthBarSprite.healthBarProperties[3];

		healthBarXA = HealthBarSprite.healthBarProperties[4];
		healthBarYA = HealthBarSprite.healthBarProperties[5];

		// HEALTH BAR SETUP
		bg = new HealthBarSprite();
		bg.type = HEALTH_BAR;
		bg.changeID(0);
		bg.x = 275;
		bg.y = parent.downScroll ? 90 : Main.INITIAL_HEIGHT - 90;

		// Actor data per slot via actorDataAt(): gameplay reads the real
		// actors; editor mode reads the SAME trio's charData.json (no
		// sprites built), so the editor shows the same icons and palette
		// as gameplay. Null slot → default palette/IDs (guards below).
		var actorData = [actorDataAt(1), actorDataAt(2)]; // [opponent, player]

		// HEALTH BAR PART SETUP
		for (i in 0...2) {
			var part = parts[i] = new HealthBarSprite();
			part.h = bg.h - healthBarHS;
			part.y = bg.y + healthBarYA;
			part.gradientMode = 1.0;
			// A side without data (missing charData.json) keeps the
			// default palette.
			if (!customHealthBarColorEnabled && actorData[i] != null)
				part.setAllColors(actorData[i].colors);

			hbBuf.addElement(part);
		}

		hbBuf.addElement(bg);

		updateBar();

		// HEALTH ICONS SETUP

		var x = bg.x + (bg.w * 0.5);

		for (i in 0...2) {
			if (actorData[i] != null) {
				var healthIconIndexes = Tools.fromIconGridXMLCharacter(actorData[i].healthIcon);
				// Unknown character name in iconData.xml → keep the default
				// grid IDs for that side instead of crashing on null.
				if (healthIconIndexes != null)
					healthIconIDs[i] = healthIconIndexes;
			}
		}

		var iconP2 = healthIcons[0] = new HealthBarSprite();
		iconP2.type = HEALTH_ICON;
		iconP2.changeID(healthIconIDs[0][0]);

		var iconP1 = healthIcons[1] = new HealthBarSprite(); // Made more like FNF, so P1 is da player LOL.
		iconP1.type = HEALTH_ICON;
		iconP1.changeID(healthIconIDs[1][0]);
		// playerOGIcon = healthIconIDs[1][0];
		// trace(playerOGIcon + "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n"); //alory's done that print lol

		iconP2.y = iconP1.y = bg.y - 75;
		iconP1.flip = true;

		iconP1.texW = 150;
		iconP1.texH = 150;
		iconP2.texW = 150;
		iconP2.texH = 150;
		// trace('tex dimensions: ${tex.width} x ${tex.height}');
		// trace('iconP1 texW: ${iconP1.texW}, texH: ${iconP1.texH}');

		hbBuf.addElement(iconP2);
		hbBuf.addElement(iconP1);

		updateHealthIcons();
	}

	/**
		Updates the health bar.
	**/
	function update(deltaTime:Float) {
		var health = parent.health;
		_smoothHealth = Tools.lerp(_smoothHealth, health, SaveData.state.preferences.smoothHealthbar ? Math.max(Math.min(deltaTime / 60, 1.0), 0.0) : 1.0);

		updateBar();
		updateHealthIcons();
	}

	private var _smoothHealth(default, null):Float;

	/**
		Updates the health bar's body.
	**/
	function updateBar() {
		if (parent.disposed || parent.died)
			return;

		bg.y = parent.downScroll ? 90 : Main.INITIAL_HEIGHT - 90;

		// Actor data per slot via actorDataAt() (editor: charData.json of
		// the same trio gameplay uses; null slot → default palette).
		var actorData = [actorDataAt(1), actorDataAt(2)]; // [opponent, player]

		var part1 = parts[0];

		if (part1 == null)
			return;

		// Default palette (white/red) when a side has no actor data.
		var actor1 = actorData[parent.flipHealthBar ? 1 : 0];
		var healthIconColor = actor1 != null ? actor1.colors : healthIconColors[0];

		if (customHealthBarColorEnabled)
			healthIconColor = healthIconColors[(parent.flipHealthBar ? 1 : 0)];
		//BOTTLENECK: mid [per-frame setAllColors re-uploads part colors every frame though palette is static all song] | FIX: [cache last applied palette and only set colors on change]
		part1.setAllColors(healthIconColor);

		part1.w = (bg.w - Math.floor(bg.w * (parent.flipHealthBar ? 1 - _smoothHealth : _smoothHealth))) - (healthBarWS * 2.0);
		part1.x = bg.x + healthBarXA;
		part1.y = bg.y + healthBarYA;

		if (part1.w < 0)
			part1.w = 0;

		var part2 = parts[1];

		if (part2 == null)
			return;

		var actor2 = actorData[parent.flipHealthBar ? 0 : 1];
		var healthIconColor = actor2 != null ? actor2.colors : healthIconColors[1];

		if (customHealthBarColorEnabled)
			healthIconColor = healthIconColors[(parent.flipHealthBar ? 0 : 1)];

		part2.setAllColors(healthIconColor);

		part2.w = (bg.w - part1.w) - (healthBarWS * 2.0);
		part2.x = (bg.x + part1.w) + healthBarXA;
		part2.y = bg.y + healthBarYA;

		if (part2.w < 0)
			part2.w = 0;
	}

	/**
		Updates the health icons.
	**/
	function updateHealthIcons() {
		if (parent.disposed || parent.died)
			return;

		var part1 = parts[1];

		if (part1 == null)
			return;

		var health = parent.health;
		var icons = healthIcons;
		var ids = healthIconIDs;

		var iconP2 = icons[0];
		var iconP1 = icons[1];

		var iconP2 = healthIcons[0];
		iconP2.x = part1.x - 118;

		var iconP1 = healthIcons[1];
		iconP1.x = part1.x - 18;

		iconP2.y = iconP1.y = bg.y - 75;

		var oppIco = parent.flipHealthBar ? iconP1 : iconP2;
		var plrIco = parent.flipHealthBar ? iconP2 : iconP1;

		//BOTTLENECK: mid [per-frame changeID re-uploads icon texcoords every frame though ID rarely changes] | FIX: [skip changeID when curID already equals target id]
		if (health > 0.75)
			oppIco.changeID(ids[0][1]);
		else
			oppIco.changeID(ids[0][0]);

		if (health < 0.25)
			plrIco.changeID(ids[1][1]);
		else
			plrIco.changeID(ids[1][0]);
	}

	/**
		Disposes the health bar.
	**/
	function dispose() {
		hbBuf.removeElement(bg);
		bg = null;

		while (parts.length != 0) {
			var healthBarPart = parts.pop();
			hbBuf.removeElement(healthBarPart);
		}
		parts = null;

		while (healthIcons.length != 0) {
			var healthIcon = healthIcons.pop();
			hbBuf.removeElement(healthIcon);
		}
		healthIcons = null;

		display.removeProgram(hbProg);
	}
}

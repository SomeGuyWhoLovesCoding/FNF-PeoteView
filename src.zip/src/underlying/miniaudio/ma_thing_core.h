#pragma once
/*
ma_thing_core.h
Shared audio engine core — included by both the standalone build and the
HashLink binding.  Nothing in here knows about HashLink or any other host
binding layer.
Triple-buffered sliding window implementation with proper continuity.
RAII implementation - Resources manage their own lifetimes.
LOCK-FREE ARCHITECTURE:
All OS-level mutexes and condition variables have been removed from hot paths.
Cross-thread state is communicated via atomic variables and lock-free triple buffers.
The audio callback is 100% wait-free and lock-free.
*/

// ---- platform / library includes -----------------------------------------
#ifdef HX_WINDOWS
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <mmdeviceapi.h>
#include <endpointvolume.h>
#include <functiondiscoverykeys_devpkey.h>
#include <locale>
#include <codecvt>
#pragma comment(lib, "ole32.lib")
#pragma comment(lib, "advapi32.lib")
#elif _WIN32
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#endif

#if SSE
#include <immintrin.h>
#endif

#ifdef __cplusplus
extern "C" {
#endif
#include "extras/stb_vorbis.c"   // included as C, must come before miniaudio
#ifdef __cplusplus
}
#endif

#include "miniaudio.h"
#include <stdio.h>
#include <stdint.h>
#include <algorithm>
#include <array>
#include <atomic>
#include <deque>
#include <string>
#include <thread>
#include <unordered_map>
#include <vector>
#include <iostream>
#include <cmath>
#include <chrono>
#include <memory>
#include <mutex>

#ifdef SSE
#include <emmintrin.h>
#include <xmmintrin.h>
#endif

std::atomic<double> MUSIC_MASTER_VOLUME_099{1.0};
// Game-wide surround preference, shared by both devices: the AudioSystem
// (song playback) AND the mixer (menu music + SFX) open with the
// 8-channel map when this is set, so surround survives a device switch
// on the mixer path too.
static std::atomic<bool> g_maThingSurround{false};

// ---- audio constants ------------------------------------------------------
#define SAMPLE_FORMAT  ma_format_f32
#define CHANNEL_COUNT  2
#define SAMPLE_RATE    48000
#define PERIOD_SIZE    512
#define PADDING_MS      150
#define BUFFER_MS       750
#define HALF_BUFFER_MS  600

#define PADDING_FRAMES      ((SAMPLE_RATE * PADDING_MS)     / 1000)
#define BUFFER_FRAMES       ((SAMPLE_RATE * BUFFER_MS)      / 1000)
#define HALF_BUFFER_FRAMES  ((SAMPLE_RATE * HALF_BUFFER_MS) / 1000)
#define TOTAL_BUFFER_FRAMES (PADDING_FRAMES + BUFFER_FRAMES + PADDING_FRAMES)
#define MAX_CALLBACK_FRAMES 4096
// Pitched playback reads up to rate * frameCount source frames per
// callback; the editor allows up to 10x, so the buffers must cover
// 10 * MAX_CALLBACK_FRAMES with headroom.
#define MAX_PITCH_FRAMES   (MAX_CALLBACK_FRAMES * 12)

// ---- surround sound system ------------------------------------------------
// 8-channel map in miniaudio/Microsoft 7.1 order:
//   0 FL  1 FR  2 C  3 LFE  4 BL  5 BR  6 SL  7 SR
// The SAME order is the explicit channelMap handed to every device open,
// so miniaudio's internal converters (rebuilt on device reroute or
// rebuild) always place our indices correctly no matter what the device's
// native layout is (stereo fold-down, 5.1, 7.1...). Without an explicit
// map miniaudio assumes plain quad (FL FR BL BR) for 4+ channels and the
// converter silently drops/misroutes center + LFE — the "plays barely
// nothing after a device switch" bug.
#define SURROUND_CHANNEL_COUNT 8
#define SURROUND_LPF_COEF   0.016951f
#define SURROUND_LFE_BASS_GAIN 0.75f
#define SURROUND_LFE_FULL_GAIN 1.0f
// v3.9.0 room discipline — the REAR ANCHOR TONE. The song never spreads
// into BL/BR/SL/SR (the environment around the song's front image stays
// untouched); those channels carry an inaudible 20 Hz tone instead —
// never zero by construction (see the MIN-BIASED block just below).
// It keeps the channels alive so the receiver never sleeps on them and
// never renormalizes the front image.
#define SURROUND_ANCHOR_HZ      20.0f
#define SURROUND_ANCHOR_AMP     0.001f
// The tone is MIN-BIASED BY CONSTRUCTION: sample = amp*(0.5 + 0.49*sin).
// Even when sinf returns -1.0f EXACTLY (float32 argument reduction does
// that for phases within ~2.4e-7 of 3*pi/2, which the phase orbit hits
// within ~10 minutes of frames), 0.5f + 0.49f*(-1.0f) = 0.01f > 0 — the
// sample can never be zero, in any float mode, at any phase. Range
// [amp*0.01, amp*0.99]; the ~5e-4 DC center is inaudible and keeps the
// channels alive so the receiver never sleeps on them or renormalizes
// the front image. (The earlier "amp + amp*sin" form hits exact 0.0f at
// sinf == -1.0f; the surround test caught both that and the phase-
// drift precision loss, hence the 2*pi wrap below.)
#define SURROUND_ANCHOR_BIAS    0.5f
#define SURROUND_ANCHOR_SPAN    0.49f
// The phase the anchor oscillators start at (both the per-stream
// rearAnchorPhase and the mixer's anchorPhase). Any value works — the
// tone is never-zero by construction — this just pins a deterministic
// start.
#define SURROUND_ANCHOR_PHASE0  0.261799f

// ---- SubBusDSP constants --------------------------------------------------
#define SUB_LPF_BODY_HZ   55.0f
#define SUB_LPF_PUNCH_HZ  120.0f
#define SUB_LPF_BODY_COEF  ((float)(1.0 - exp(-2.0 * 3.14159265358979323846 * SUB_LPF_BODY_HZ  / SAMPLE_RATE)))
#define SUB_LPF_PUNCH_COEF ((float)(1.0 - exp(-2.0 * 3.14159265358979323846 * SUB_LPF_PUNCH_HZ / SAMPLE_RATE)))
#define SUB_ENV_ATTACK_COEF  0.012f
#define SUB_ENV_RELEASE_COEF 0.0006f
#define SUB_KICK_TRANSIENT_RATIO 2.2f
#define SUB_KICK_FLOOR           0.03f
#define SUB_KICK_HYSTERESIS      0.5f
#define SUB_KICK_BOOST_GAIN      0.75f
#define SUB_KICK_BOOST_ATTACK    0.05f
#define SUB_KICK_BOOST_RELEASE   0.0009f
#define SUB_RUMBLE_BODY_RATIO    0.55f
#define SUB_RUMBLE_FLOOR         0.02f
#define SUB_RUMBLE_DUCK          0.55f
#define SUB_RUMBLE_SMOOTH        0.0009f

enum MaThingAudioChannel {
    MA_CH_CENTER     = 0,
    MA_CH_BACKGROUND = 1,
    MA_CH_SUB        = 2
};

// The engine's 8-channel layout, indices as written by routeStreamToOutput
// (Microsoft 7.1 order — what miniaudio's standard converter matrices
// expect): FL FR C LFE BL BR SL SR.
static ma_channel MA_THING_SURROUND_MAP[SURROUND_CHANNEL_COUNT] = {
    MA_CHANNEL_FRONT_LEFT, MA_CHANNEL_FRONT_RIGHT, MA_CHANNEL_FRONT_CENTER, MA_CHANNEL_LFE,
    MA_CHANNEL_BACK_LEFT,  MA_CHANNEL_BACK_RIGHT,  MA_CHANNEL_SIDE_LEFT,   MA_CHANNEL_SIDE_RIGHT
};
// Plain stereo: FL FR.
static ma_channel MA_THING_STEREO_MAP[CHANNEL_COUNT] = {
    MA_CHANNEL_FRONT_LEFT, MA_CHANNEL_FRONT_RIGHT
};
// Points a device config at the explicit channel map for its layout so
// miniaudio's converters know exactly what our interleaved frames mean.
// The arrays are static storage — they outlive the device. Without this,
// a reroute or rebuild onto a device with a different native layout makes
// miniaudio guess (quad for 4ch, etc.) and center/LFE content vanishes.
static void ma_thing_set_channel_map(ma_device_config* cfg, int channels) {
    cfg->playback.pChannelMap = (channels == SURROUND_CHANNEL_COUNT)
        ? MA_THING_SURROUND_MAP : MA_THING_STEREO_MAP;
}

// Wrapper to allow std::atomic<int> inside standard containers like std::vector
struct AtomicInt {
    std::atomic<int> val;
    AtomicInt() : val(0) {}
    AtomicInt(int v) : val(v) {}
    AtomicInt(AtomicInt&& other) noexcept : val(other.val.load(std::memory_order_relaxed)) {}
    AtomicInt& operator=(AtomicInt&& other) noexcept {
        val.store(other.val.load(std::memory_order_relaxed), std::memory_order_relaxed);
        return *this;
    }
    void store(int v, std::memory_order o) { val.store(v, o); }
    int load(std::memory_order o) const { return val.load(o); }
};

// ---- SIMD mix helpers -----------------------------------------------------
#ifdef SSE
static inline void mix_simd(float* dst, const float* src, int samples, float volume) {
    int i = 0;
    if (volume == 1.0f) {
        for (; i < samples - 7; i += 8) {
            _mm_storeu_ps(dst + i,     _mm_add_ps(_mm_loadu_ps(dst + i),     _mm_loadu_ps(src + i)));
            _mm_storeu_ps(dst + i + 4, _mm_add_ps(_mm_loadu_ps(dst + i + 4), _mm_loadu_ps(src + i + 4)));
        }
        if (i < samples - 3) {
            _mm_storeu_ps(dst + i, _mm_add_ps(_mm_loadu_ps(dst + i), _mm_loadu_ps(src + i)));
            i += 4;
        }
    } else {
        __m128 vvol = _mm_set1_ps(volume);
        for (; i < samples - 7; i += 8) {
            _mm_storeu_ps(dst + i,     _mm_add_ps(_mm_loadu_ps(dst + i),     _mm_mul_ps(_mm_loadu_ps(src + i),     vvol)));
            _mm_storeu_ps(dst + i + 4, _mm_add_ps(_mm_loadu_ps(dst + i + 4), _mm_mul_ps(_mm_loadu_ps(src + i + 4), vvol)));
        }
        for (; i < samples - 3; i += 4)
            _mm_storeu_ps(dst + i, _mm_add_ps(_mm_loadu_ps(dst + i), _mm_mul_ps(_mm_loadu_ps(src + i), vvol)));
    }
    for (; i < samples; i++) {
        dst[i] = std::fma(src[i], volume, dst[i]);
    }
}
#else
static inline void mix_scalar(float* dst, const float* src, int samples, float volume) {
    if (volume == 1.0f) {
        for (int i = 0; i < samples; i++) dst[i] += src[i];
    } else {
        for (int i = 0; i < samples; i++) {
            dst[i] = std::fma(src[i], volume, dst[i]);
        }
    }
}
#endif

// ==========================================================================
//  Runtime AVX2 Detection & Dispatch
// ==========================================================================
#if defined(_MSC_VER)
#include <intrin.h>
#elif defined(__GNUC__) || defined(__clang__)
#include <cpuid.h>
#endif

static inline bool os_has_avx_support() {
#if defined(_MSC_VER)
    int regs[4];
    __cpuid(regs, 1);
    if (!(regs[2] & (1 << 27))) return false;
    unsigned long long xcr0 = _xgetbv(0);
    return (xcr0 & 0x6) == 0x6;
#elif defined(__GNUC__) || defined(__clang__)
    unsigned int eax, ebx, ecx, edx;
    if (!__get_cpuid(1, &eax, &ebx, &ecx, &edx)) return false;
    if (!(ecx & (1 << 27))) return false;
    unsigned int xcr0lo = 0, xcr0hi = 0;
    __asm__ volatile("xgetbv" : "=a"(xcr0lo), "=d"(xcr0hi) : "c"(0));
    unsigned long long xcr0 = ((unsigned long long)xcr0hi << 32) | xcr0lo;
    return (xcr0 & 0x6) == 0x6;
#else
    return false;
#endif
}

static inline bool has_avx2_runtime() {
#if defined(_MSC_VER)
    int regs[4];
    __cpuidex(regs, 7, 0);
    return ((regs[1] & (1 << 5)) != 0) && os_has_avx_support();
#elif defined(__GNUC__) || defined(__clang__)
    unsigned int eax, ebx, ecx, edx;
    return __get_cpuid_count(7, 0, &eax, &ebx, &ecx, &edx) &&
           ((ebx >> 5) & 1) && os_has_avx_support();
#else
    return false;
#endif
}

#if defined(__GNUC__) || defined(__clang__)
__attribute__((target("avx2,fma")))
#endif
static inline void mix_avx2(float* dst, const float* src, int samples, float volume) {
    int i = 0;
    if (volume == 1.0f) {
        for (; i + 8 <= samples; i += 8)
            _mm256_storeu_ps(dst + i, _mm256_add_ps(_mm256_loadu_ps(dst + i), _mm256_loadu_ps(src + i)));
    } else {
        __m256 vvol = _mm256_set1_ps(volume);
        for (; i + 8 <= samples; i += 8) {
            __m256 vdst = _mm256_loadu_ps(dst + i);
            __m256 vsrc = _mm256_loadu_ps(src + i);
            _mm256_storeu_ps(dst + i, _mm256_fmadd_ps(vsrc, vvol, vdst));
        }
    }
    for (; i < samples; i++) dst[i] = std::fma(src[i], volume, dst[i]);
}

static void (*g_mix_func)(float*, const float*, int, float) =
#ifdef SSE
    mix_simd;
#else
    mix_scalar;
#endif

static void init_simd_dispatch() {
    if (has_avx2_runtime()) {
        g_mix_func = mix_avx2;
    }
}

// ==========================================================================
//  SubBusDSP
// ==========================================================================
class SubBusDSP {
public:
    SubBusDSP() { reset(); }
    void reset() {
        body_lpf = punch_lpf = total_env = body_env = 0.0f;
        punch_fast = punch_slow = boost_env = 0.0f;
        kick_armed = false;
        duck_gain = 1.0f;
    }
    void process(float* interleaved, ma_uint32 frames) {
        for (ma_uint32 i = 0; i < frames; i++) {
            float* lfe = &interleaved[i * SURROUND_CHANNEL_COUNT + 3];
            float x = *lfe;
            body_lpf  += SUB_LPF_BODY_COEF  * (x - body_lpf);
            punch_lpf += SUB_LPF_PUNCH_COEF * (x - punch_lpf);
            float abs_punch = fabsf(punch_lpf);
            if (abs_punch > punch_fast) punch_fast += SUB_ENV_ATTACK_COEF  * (abs_punch - punch_fast);
            else                        punch_fast += SUB_ENV_RELEASE_COEF * (abs_punch - punch_fast);
            if (abs_punch > punch_slow) punch_slow += SUB_ENV_ATTACK_COEF  * (abs_punch - punch_slow);
            else                        punch_slow += SUB_ENV_RELEASE_COEF * (abs_punch - punch_slow);
            
            bool kick_now = (punch_fast > SUB_KICK_FLOOR && punch_slow > 0.0001f && punch_fast > punch_slow * SUB_KICK_TRANSIENT_RATIO);
            if (kick_now) kick_armed = true;
            else if (punch_fast < SUB_KICK_FLOOR * SUB_KICK_HYSTERESIS) kick_armed = false;
            
            float boost_target = kick_armed ? 1.0f : 0.0f;
            if (boost_target > boost_env) boost_env += SUB_KICK_BOOST_ATTACK  * (boost_target - boost_env);
            else                          boost_env += SUB_KICK_BOOST_RELEASE * (boost_target - boost_env);
            float boosted = x * (1.0f + SUB_KICK_BOOST_GAIN * boost_env);
            
            float abs_total = fabsf(boosted);
            float abs_body  = fabsf(body_lpf);
            total_env += 0.0006f * (abs_total - total_env);
            body_env  += 0.0006f * (abs_body  - body_env);
            bool rumbling = (!kick_armed && total_env > SUB_RUMBLE_FLOOR && body_env > total_env * SUB_RUMBLE_BODY_RATIO);
            float duck_target = rumbling ? SUB_RUMBLE_DUCK : 1.0f;
            duck_gain += SUB_RUMBLE_SMOOTH * (duck_target - duck_gain);
            *lfe = boosted * duck_gain;
        }
    }
private:
    float body_lpf, punch_lpf, total_env, body_env, punch_fast, punch_slow, boost_env, duck_gain;
    bool kick_armed;
};

// ==========================================================================
//  DecoderStream
// ==========================================================================
struct DecoderStream {
    float* pcmBufferA = nullptr;
    float* pcmBufferB = nullptr;
    float* pcmBufferC = nullptr;
    float* activeBuffer = nullptr;
    float* nextBuffer = nullptr;
    float* loadingBuffer = nullptr;
    std::atomic<ma_uint64> filePosition{0};
    ma_uint64 bufferStartPos = 0;
    ma_uint64 localReadPos = 0;
    ma_uint64 validFrames = 0;
    
    struct AsyncState {
        ma_uint64 nextBufferStartPos = 0;
        ma_uint64 nextBufferValidFrames = 0;
        ma_uint64 loadingBufferStartPos = 0;
        ma_uint64 loadingBufferValidFrames = 0;
        std::atomic<bool> nextBufferReady{false};
        std::atomic<bool> loadingBufferReady{false};
        std::atomic<bool> loadingInProgress{false};
        std::atomic<bool> needsLoad{false};
        std::atomic<bool> requestNextBuffer{false};
        std::atomic<bool> requestLoadingBuffer{false};
        float* asyncNextBuffer = nullptr;
        float* asyncLoadingBuffer = nullptr;
    } asyncState;
    
    std::atomic<bool> active{false};
    ma_uint64 decoderLength = 0;
    std::string decoderPath;
    ma_decoder workerDecoder;
    bool workerDecoderInitialized = false;

    DecoderStream() { memset(&workerDecoder, 0, sizeof(ma_decoder)); }
    ~DecoderStream() { cleanup(); }
    DecoderStream(DecoderStream&& other) noexcept { moveFrom(std::move(other)); }
    DecoderStream& operator=(DecoderStream&& other) noexcept {
        if (this != &other) { cleanup(); moveFrom(std::move(other)); }
        return *this;
    }
    DecoderStream(const DecoderStream&) = delete;
    DecoderStream& operator=(const DecoderStream&) = delete;

    bool openTempDecoder(ma_decoder* out) const {
        if (decoderPath.empty()) return false;
        ma_decoder_config cfg = ma_decoder_config_init(SAMPLE_FORMAT, CHANNEL_COUNT, SAMPLE_RATE);
        if (ma_decoder_init_file(decoderPath.c_str(), &cfg, out) != MA_SUCCESS) return false;
        ma_data_source_set_looping(out, MA_FALSE);
        return true;
    }

    void fillBufferTemp(ma_uint64 decodeStart, float* buffer, ma_uint64* framesRead) {
        *framesRead = 0;
        ma_decoder dec;
        if (!openTempDecoder(&dec)) {
            memset(buffer, 0, TOTAL_BUFFER_FRAMES * CHANNEL_COUNT * sizeof(float));
            return;
        }
        ma_uint64 maxFrames = TOTAL_BUFFER_FRAMES;
        if (decodeStart + TOTAL_BUFFER_FRAMES > decoderLength) maxFrames = decoderLength - decodeStart;
        if (maxFrames > 0 && decodeStart < decoderLength) {
            if (ma_decoder_seek_to_pcm_frame(&dec, decodeStart) == MA_SUCCESS)
                ma_decoder_read_pcm_frames(&dec, buffer, maxFrames, framesRead);
        }
        if (*framesRead < maxFrames)
            memset(buffer + (*framesRead) * CHANNEL_COUNT, 0, (maxFrames - *framesRead) * CHANNEL_COUNT * sizeof(float));
        ma_decoder_uninit(&dec);
    }

    void fillBufferWorker(ma_uint64 decodeStart, float* buffer, ma_uint64* framesRead) {
        *framesRead = 0;
        if (!workerDecoderInitialized) {
            memset(buffer, 0, TOTAL_BUFFER_FRAMES * CHANNEL_COUNT * sizeof(float));
            return;
        }
        ma_uint64 maxFrames = TOTAL_BUFFER_FRAMES;
        if (decodeStart + TOTAL_BUFFER_FRAMES > decoderLength) maxFrames = decoderLength - decodeStart;
        if (maxFrames > 0 && decodeStart < decoderLength) {
            if (ma_decoder_seek_to_pcm_frame(&workerDecoder, decodeStart) == MA_SUCCESS)
                ma_decoder_read_pcm_frames(&workerDecoder, buffer, maxFrames, framesRead);
        }
        if (*framesRead < maxFrames)
            memset(buffer + (*framesRead) * CHANNEL_COUNT, 0, (maxFrames - *framesRead) * CHANNEL_COUNT * sizeof(float));
    }

    bool trySwapBuffers() {
        if (!asyncState.nextBufferReady.load(std::memory_order_acquire)) return false;
        ma_uint64 currentGlobalPos = bufferStartPos + localReadPos;
        float* oldActive = activeBuffer;
        float* oldNext = nextBuffer;
        float* oldLoading = loadingBuffer;
        activeBuffer = oldNext;
        nextBuffer = oldLoading;
        loadingBuffer = oldActive;
        bufferStartPos = asyncState.nextBufferStartPos;
        validFrames = asyncState.nextBufferValidFrames;
        asyncState.nextBufferStartPos = asyncState.loadingBufferStartPos;
        asyncState.nextBufferValidFrames = asyncState.loadingBufferValidFrames;
        asyncState.loadingBufferStartPos = 0;
        asyncState.loadingBufferValidFrames = 0;
        asyncState.nextBufferReady.store(asyncState.loadingBufferReady.load(std::memory_order_relaxed), std::memory_order_release);
        asyncState.loadingBufferReady.store(false, std::memory_order_release);
        asyncState.asyncNextBuffer = oldLoading;
        asyncState.asyncLoadingBuffer = oldActive;
        if (currentGlobalPos >= bufferStartPos && currentGlobalPos < bufferStartPos + validFrames)
            localReadPos = currentGlobalPos - bufferStartPos;
        else if (currentGlobalPos < bufferStartPos) localReadPos = 0;
        else localReadPos = std::min<ma_uint64>(validFrames, (ma_uint64)TOTAL_BUFFER_FRAMES);
        if (localReadPos >= TOTAL_BUFFER_FRAMES) localReadPos = TOTAL_BUFFER_FRAMES - 1;
        asyncState.requestLoadingBuffer.store(true, std::memory_order_release);
        return true;
    }

    void resetState() {
        asyncState.nextBufferReady.store(false, std::memory_order_release);
        asyncState.loadingBufferReady.store(false, std::memory_order_release);
        asyncState.loadingInProgress.store(false, std::memory_order_release);
        asyncState.needsLoad.store(false, std::memory_order_release);
        asyncState.requestNextBuffer.store(false, std::memory_order_release);
        asyncState.requestLoadingBuffer.store(false, std::memory_order_release);
        asyncState.nextBufferValidFrames = 0;
        asyncState.loadingBufferValidFrames = 0;
        asyncState.nextBufferStartPos = 0;
        asyncState.loadingBufferStartPos = 0;
        filePosition.store(0, std::memory_order_release);
        bufferStartPos = localReadPos = validFrames = 0;
        if (pcmBufferA) memset(pcmBufferA, 0, TOTAL_BUFFER_FRAMES * CHANNEL_COUNT * sizeof(float));
        if (pcmBufferB) memset(pcmBufferB, 0, TOTAL_BUFFER_FRAMES * CHANNEL_COUNT * sizeof(float));
        if (pcmBufferC) memset(pcmBufferC, 0, TOTAL_BUFFER_FRAMES * CHANNEL_COUNT * sizeof(float));
    }

    bool shouldSwapBuffers() const {
        if (localReadPos >= validFrames) return true;
        if (localReadPos >= (PADDING_FRAMES + HALF_BUFFER_FRAMES)) return true;
        return false;
    }

    bool isBufferLow() const {
        ma_uint64 available = (localReadPos < validFrames) ? (validFrames - localReadPos) : 0;
        return available < (HALF_BUFFER_FRAMES / 2);
    }

    void requestBufferLoad() {
        if (!asyncState.nextBufferReady.load(std::memory_order_relaxed) && !asyncState.loadingInProgress.load(std::memory_order_relaxed))
            asyncState.requestNextBuffer.store(true, std::memory_order_release);
    }

private:
    void cleanup() {
        if (workerDecoderInitialized) { ma_decoder_uninit(&workerDecoder); workerDecoderInitialized = false; }
        memset(&workerDecoder, 0, sizeof(ma_decoder));
        decoderPath.clear();
        if (pcmBufferA) { free(pcmBufferA); pcmBufferA = nullptr; }
        if (pcmBufferB) { free(pcmBufferB); pcmBufferB = nullptr; }
        if (pcmBufferC) { free(pcmBufferC); pcmBufferC = nullptr; }
        activeBuffer = nextBuffer = loadingBuffer = nullptr;
        asyncState.asyncNextBuffer = asyncState.asyncLoadingBuffer = nullptr;
    }
    void moveFrom(DecoderStream&& other) noexcept {
        pcmBufferA = other.pcmBufferA; pcmBufferB = other.pcmBufferB; pcmBufferC = other.pcmBufferC;
        activeBuffer = other.activeBuffer; nextBuffer = other.nextBuffer; loadingBuffer = other.loadingBuffer;
        memcpy(&workerDecoder, &other.workerDecoder, sizeof(ma_decoder));
        workerDecoderInitialized = other.workerDecoderInitialized;
        decoderPath = std::move(other.decoderPath);
        filePosition.store(other.filePosition.load(std::memory_order_relaxed), std::memory_order_relaxed);
        bufferStartPos = other.bufferStartPos; localReadPos = other.localReadPos; validFrames = other.validFrames;
        active.store(other.active.load(std::memory_order_relaxed), std::memory_order_relaxed);
        decoderLength = other.decoderLength;
        asyncState.nextBufferStartPos = other.asyncState.nextBufferStartPos;
        asyncState.nextBufferValidFrames = other.asyncState.nextBufferValidFrames;
        asyncState.loadingBufferStartPos = other.asyncState.loadingBufferStartPos;
        asyncState.loadingBufferValidFrames = other.asyncState.loadingBufferValidFrames;
        asyncState.asyncNextBuffer = other.asyncState.asyncNextBuffer;
        asyncState.asyncLoadingBuffer = other.asyncState.asyncLoadingBuffer;
        other.pcmBufferA = other.pcmBufferB = other.pcmBufferC = nullptr;
        other.activeBuffer = other.nextBuffer = other.loadingBuffer = nullptr;
        other.asyncState.asyncNextBuffer = other.asyncState.asyncLoadingBuffer = nullptr;
        other.workerDecoderInitialized = false;
        memset(&other.workerDecoder, 0, sizeof(ma_decoder));
        other.decoderPath.clear();
    }
};

// ==========================================================================
//  AsyncLoader
// ==========================================================================
class AsyncLoader {
public:
    explicit AsyncLoader(std::vector<DecoderStream*>& streamRefs) : streams(streamRefs) { start(); }
    ~AsyncLoader() { stop(); }
    void pauseLoading() { pause.store(true, std::memory_order_release); signal(); }
    void resumeLoading() { pause.store(false, std::memory_order_release); signal(); }
    void signal() { workPending.store(true, std::memory_order_release); }
    void waitUntilIdle() {
        if (!running.load(std::memory_order_acquire)) return;
        signal();
        auto startTime = std::chrono::steady_clock::now();
        const auto timeout = std::chrono::milliseconds(1000);
        for (;;) {
            bool anyLoading = false;
            for (DecoderStream* s : streams) {
                if (s && s->asyncState.loadingInProgress.load(std::memory_order_acquire)) { anyLoading = true; break; }
            }
            if (!anyLoading && workerIdle.load(std::memory_order_acquire)) break;
            if (std::chrono::steady_clock::now() - startTime > timeout) break;
            std::this_thread::sleep_for(std::chrono::milliseconds(1));
        }
        std::this_thread::sleep_for(std::chrono::microseconds(500));
    }
    bool isRunning() const { return running.load(std::memory_order_acquire); }
private:
    std::vector<DecoderStream*>& streams;
    std::thread workerThread;
    std::atomic<bool> running{false};
    std::atomic<bool> pause{false};
    std::atomic<bool> workerIdle{false};
    std::atomic<bool> stopRequested{false};
    std::atomic<bool> workPending{false};

    void start() {
        if (running.load(std::memory_order_acquire)) return;
        running.store(true, std::memory_order_release);
        stopRequested.store(false, std::memory_order_release);
        try { workerThread = std::thread([this]() { worker(); }); }
        catch (...) { running.store(false, std::memory_order_release); }
    }
    void stop() {
        if (!running.load(std::memory_order_acquire)) return;
        stopRequested.store(true, std::memory_order_release);
        running.store(false, std::memory_order_release);
        signal();
        std::this_thread::sleep_for(std::chrono::microseconds(100));
        signal();
        if (workerThread.joinable()) workerThread.join();
        workPending.store(false, std::memory_order_release);
    }
    void worker() {
        constexpr int MAX_PER_CYCLE = 2;
        int currentStream = 0;
        while (running.load(std::memory_order_acquire)) {
            if (stopRequested.load(std::memory_order_acquire)) break;
            if (pause.load(std::memory_order_acquire) && !stopRequested.load(std::memory_order_acquire)) {
                workerIdle.store(true, std::memory_order_release);
                auto start = std::chrono::steady_clock::now();
                while (pause.load(std::memory_order_acquire) && !stopRequested.load(std::memory_order_acquire) && running.load(std::memory_order_acquire)) {
                    if (std::chrono::steady_clock::now() - start > std::chrono::milliseconds(10)) break;
                    std::this_thread::sleep_for(std::chrono::milliseconds(1));
                }
                workerIdle.store(false, std::memory_order_release);
                continue;
            }
            if (streams.empty()) {
                workerIdle.store(true, std::memory_order_release);
                auto start = std::chrono::steady_clock::now();
                while (streams.empty() && !stopRequested.load(std::memory_order_acquire) && running.load(std::memory_order_acquire)) {
                    if (std::chrono::steady_clock::now() - start > std::chrono::milliseconds(10)) break;
                    std::this_thread::sleep_for(std::chrono::milliseconds(1));
                }
                workerIdle.store(false, std::memory_order_release);
                continue;
            }
            workPending.store(false, std::memory_order_release);
            int processed = 0;
            size_t streamCount = streams.size();
            for (int i = 0; i < (int)streamCount && processed < MAX_PER_CYCLE; i++) {
                if (stopRequested.load(std::memory_order_acquire) || !running.load(std::memory_order_acquire)) break;
                int idx = (currentStream + i) % (int)streamCount;
                DecoderStream* s = (idx >= 0 && idx < (int)streams.size()) ? streams[idx] : nullptr;
                if (s && s->active.load(std::memory_order_acquire)) {
                    if (processStreamLoad(s)) processed++;
                }
            }
            if (processed > 0) currentStream = (currentStream + 1) % (int)streamCount;
            if (processed == 0 && !stopRequested.load(std::memory_order_acquire)) {
                workerIdle.store(true, std::memory_order_release);
                auto start = std::chrono::steady_clock::now();
                while (!workPending.load(std::memory_order_acquire) && !stopRequested.load(std::memory_order_acquire) && running.load(std::memory_order_acquire)) {
                    if (std::chrono::steady_clock::now() - start > std::chrono::milliseconds(5)) break;
                    std::this_thread::sleep_for(std::chrono::milliseconds(1));
                }
                workerIdle.store(false, std::memory_order_release);
            }
        }
    }
    bool processStreamLoad(DecoderStream* s) {
        if (!s) return false;
        bool didWork = false;
        if (s->asyncState.requestNextBuffer.load(std::memory_order_acquire)) {
            if (!s->asyncState.loadingInProgress.load(std::memory_order_relaxed)) {
                if (tryLoadNextBuffer(s)) didWork = true;
            }
            s->asyncState.requestNextBuffer.store(false, std::memory_order_release);
        }
        if (s->asyncState.requestLoadingBuffer.load(std::memory_order_acquire)) {
            if (!s->asyncState.loadingInProgress.load(std::memory_order_relaxed) && s->asyncState.nextBufferReady.load(std::memory_order_relaxed)) {
                if (tryLoadLoadingBuffer(s)) didWork = true;
            }
            s->asyncState.requestLoadingBuffer.store(false, std::memory_order_release);
        }
        return didWork;
    }
    bool tryLoadNextBuffer(DecoderStream* s) {
        if (!s || stopRequested.load(std::memory_order_acquire)) return false;
        bool expected = false;
        if (!s->asyncState.loadingInProgress.compare_exchange_strong(expected, true, std::memory_order_acq_rel)) return false;
        if (stopRequested.load(std::memory_order_acquire)) { s->asyncState.loadingInProgress.store(false, std::memory_order_release); return false; }
        ma_uint64 start = s->bufferStartPos + HALF_BUFFER_FRAMES;
        if (start > PADDING_FRAMES) start -= PADDING_FRAMES;
        if (start >= s->decoderLength || !s->asyncState.asyncNextBuffer) { s->asyncState.loadingInProgress.store(false, std::memory_order_release); return false; }
        ma_uint64 framesRead = 0;
        s->fillBufferWorker(start, s->asyncState.asyncNextBuffer, &framesRead);
        if (!stopRequested.load(std::memory_order_acquire) && running.load(std::memory_order_acquire)) {
            s->asyncState.nextBufferStartPos = start;
            s->asyncState.nextBufferValidFrames = framesRead;
            s->asyncState.nextBufferReady.store(true, std::memory_order_release);
        }
        s->asyncState.loadingInProgress.store(false, std::memory_order_release);
        return true;
    }
    bool tryLoadLoadingBuffer(DecoderStream* s) {
        if (!s || stopRequested.load(std::memory_order_acquire)) return false;
        bool expected = false;
        if (!s->asyncState.loadingInProgress.compare_exchange_strong(expected, true, std::memory_order_acq_rel)) return false;
        if (stopRequested.load(std::memory_order_acquire)) { s->asyncState.loadingInProgress.store(false, std::memory_order_release); return false; }
        ma_uint64 start = s->asyncState.nextBufferStartPos + HALF_BUFFER_FRAMES;
        if (start > PADDING_FRAMES) start -= PADDING_FRAMES;
        if (start >= s->decoderLength || !s->asyncState.asyncLoadingBuffer) { s->asyncState.loadingInProgress.store(false, std::memory_order_release); return false; }
        ma_uint64 framesRead = 0;
        s->fillBufferWorker(start, s->asyncState.asyncLoadingBuffer, &framesRead);
        if (!stopRequested.load(std::memory_order_acquire) && running.load(std::memory_order_acquire)) {
            s->asyncState.loadingBufferStartPos = start;
            s->asyncState.loadingBufferValidFrames = framesRead;
            s->asyncState.loadingBufferReady.store(true, std::memory_order_release);
        }
        s->asyncState.loadingInProgress.store(false, std::memory_order_release);
        return true;
    }
};

// ==========================================================================
//  StretchPipeline — moves SignalsmithStretch's FFT work off the realtime
//  audio thread.
//
//  Lock-free SPSC ring buffers: the audio thread pushes mixed input chunks in,
//  a dedicated worker thread runs stretch->process(), and the audio thread
//  pulls the stretched output back out. Only the worker touches `stretch`, so
//  it never blocks the callback. If the worker hasn't produced a chunk yet
//  (cold start / rate change) the callback simply gets silence for that chunk.
// ==========================================================================

class StretchPipeline {
public:
    // 16384 stereo frames; must hold a full rate-scaled callback push
    // (10x * MAX_CALLBACK_FRAMES = 40960 with the editor's rate ladder —
    // doubled to 1<<16 so the input ring never rejects a push at 10x).
    static constexpr size_t RING_FRAMES = 1 << 16;      // 65536 stereo frames
    static constexpr size_t RING_MASK  = RING_FRAMES - 1;
    static constexpr size_t MAX_CHUNKS = 16;

    struct ChunkDesc {
        ma_uint32 inFrames;
        ma_uint32 outFrames;
    };

    StretchPipeline() {
        configureChannels(CHANNEL_COUNT);
    }

    ~StretchPipeline() { stop(); }

    // The stretch engine processes the song in the device's output layout so
    // pitched playback can carry the 3.1 surround buses natively.  Only call
    // while the worker is stopped (device stopped / pipeline reset), i.e. on
    // load or on a stereo <-> surround output toggle.
    void configureChannels(int ch) {
        if (channels == ch && !inSamples.empty()) return;
        stop();
        channels = ch;
        inSamples.assign(RING_FRAMES * channels, 0.0f);
        outSamples.assign(RING_FRAMES * channels, 0.0f);
        workIn.assign(MAX_PITCH_FRAMES * channels, 0.0f);
        workOut.assign(MAX_CALLBACK_FRAMES * channels, 0.0f);
        stretch.configure(channels, int(SAMPLE_RATE * 0.1), int(SAMPLE_RATE * 0.05));
    }

    // ---- audio thread -----------------------------------------------
    bool push(const float* input, ma_uint32 inFrames, ma_uint32 outFrames) {
        ensureStarted();

        size_t head = inHead.load(std::memory_order_acquire);
        size_t tail = inTail.load(std::memory_order_acquire);
        if (RING_FRAMES - (head - tail) < inFrames) return false;   // input ring full

        size_t cHead = chunkHead.load(std::memory_order_relaxed);
        size_t cTail = chunkTail.load(std::memory_order_acquire);
        if (MAX_CHUNKS - (cHead - cTail) < 1) return false;         // desc ring full

        writeSamples(inSamples.data(), head, input, inFrames);
        chunks[cHead & (MAX_CHUNKS - 1)] = { inFrames, outFrames };
        inHead.store(head + inFrames, std::memory_order_release);
        chunkHead.store(cHead + 1, std::memory_order_release);
        return true;
    }

    bool pull(float* output, ma_uint32 outFrames) {
        size_t head = outHead.load(std::memory_order_acquire);
        size_t tail = outTail.load(std::memory_order_acquire);
        if (head - tail < outFrames) return false;                  // not produced yet
        readSamples(outSamples.data(), tail, output, outFrames);
        outTail.store(tail + outFrames, std::memory_order_release);
        return true;
    }

    void stop() {
        if (!running.load(std::memory_order_acquire)) return;
        stopRequested.store(true, std::memory_order_release);
        if (thread.joinable()) thread.join();
        running.store(false, std::memory_order_release);
    }

    // Discard all in-flight stretched chunks and re-seed the stretch engine.
    // Only safe to call while the audio device is stopped (e.g. inside seek).
    void reset() {
        stop();
        inHead.store(0, std::memory_order_release); inTail.store(0, std::memory_order_release);
        outHead.store(0, std::memory_order_release); outTail.store(0, std::memory_order_release);
        chunkHead.store(0, std::memory_order_release); chunkTail.store(0, std::memory_order_release);
        stretch.reset();
    }

private:
    signalsmith::stretch::SignalsmithStretch stretch;
    int channels = CHANNEL_COUNT;   // output layout this pipeline stretches
    std::vector<float> inSamples, outSamples, workIn, workOut;
    std::array<ChunkDesc, MAX_CHUNKS> chunks;

    std::atomic<size_t> inHead{0}, inTail{0};
    std::atomic<size_t> outHead{0}, outTail{0};
    std::atomic<size_t> chunkHead{0}, chunkTail{0};

    std::thread thread;
    std::atomic<bool> running{false};
    std::atomic<bool> stopRequested{false};

    void ensureStarted() {
        bool expected = false;
        if (running.compare_exchange_strong(expected, true, std::memory_order_acq_rel)) {
            stopRequested.store(false, std::memory_order_release);
            try {
                thread = std::thread([this]() { workerLoop(); });
            } catch (...) {
                running.store(false, std::memory_order_release);
            }
        }
    }

    void writeSamples(float* dst, size_t at, const float* src, ma_uint32 frames) {
        size_t offset = (at & RING_MASK) * channels;
        size_t first  = std::min<size_t>(frames, RING_FRAMES - (at & RING_MASK));
        size_t total  = (size_t)frames * channels;
        memcpy(dst + offset, src, first * channels * sizeof(float));
        if (frames > first)
            memcpy(dst, src + first * channels, (total - first * channels) * sizeof(float));
    }

    void readSamples(const float* src, size_t at, float* dst, ma_uint32 frames) {
        size_t offset = (at & RING_MASK) * channels;
        size_t first  = std::min<size_t>(frames, RING_FRAMES - (at & RING_MASK));
        memcpy(dst, src + offset, first * channels * sizeof(float));
        if (frames > first)
            memcpy(dst + first * channels, src, (frames - first) * channels * sizeof(float));
    }

    void workerLoop() {
        while (running.load(std::memory_order_acquire) && !stopRequested.load(std::memory_order_acquire)) {
            size_t cHead = chunkHead.load(std::memory_order_acquire);
            size_t cTail = chunkTail.load(std::memory_order_acquire);
            if (cTail >= cHead) {
                std::this_thread::sleep_for(std::chrono::milliseconds(1));
                continue;
            }

            const ChunkDesc& c = chunks[cTail & (MAX_CHUNKS - 1)];

            size_t oHead = outHead.load(std::memory_order_acquire);
            size_t oTail = outTail.load(std::memory_order_acquire);
            if ((oHead - oTail) + c.outFrames > RING_FRAMES) {      // output ring full
                std::this_thread::sleep_for(std::chrono::milliseconds(1));
                continue;
            }

            size_t iTail = inTail.load(std::memory_order_acquire);
            readSamples(inSamples.data(), iTail, workIn.data(), c.inFrames);
            inTail.store(iTail + c.inFrames, std::memory_order_release);

            stretch.process(workIn.data(), c.inFrames, workOut.data(), c.outFrames);
            writeSamples(outSamples.data(), oHead, workOut.data(), c.outFrames);
            outHead.store(oHead + c.outFrames, std::memory_order_release);
            chunkTail.store(cTail + 1, std::memory_order_release);
        }
    }
};

// ==========================================================================
//  ma_device_lifecycle_watchdog
// ==========================================================================
// Runs a miniaudio device lifecycle call (stop / uninit / start) on a
// helper thread and waits a bounded time. When the call does not come
// back in time, the helper thread is DETACHED and the wedged device is
// declared dead: `stuckFlag` is set so callers stop touching it (the
// device object is leaked — its buffers stay alive — but the process
// keeps running and still closes cleanly, instead of deadlocking on
// every later stop/uninit like it did before).
// NOTE: this is deliberately a free function taking a flag reference —
// it must stay usable from both AudioSystem and AudioMixerManager.
template <typename Fn>
static bool ma_device_lifecycle_watchdog(Fn&& fn, std::atomic<bool>& stuckFlag, int timeoutMs) {
    if (stuckFlag.load(std::memory_order_acquire)) return false; // already in leak mode — don't poke it
    auto done = std::make_shared<std::atomic<bool>>(false);
    auto fnCopy = std::make_shared<Fn>(std::forward<Fn>(fn));
    std::thread helper([done, fnCopy]() {
        (*fnCopy)();
        done->store(true, std::memory_order_release);
    });
    auto limit = std::chrono::steady_clock::now() + std::chrono::milliseconds(timeoutMs);
    while (std::chrono::steady_clock::now() < limit) {
        if (done->load(std::memory_order_acquire)) { helper.join(); return true; }
        std::this_thread::sleep_for(std::chrono::milliseconds(2));
    }
    helper.detach();
    stuckFlag.store(true, std::memory_order_release);
    printf("[ma_thing] device lifecycle call timed out (%d ms) — device leaked, continuing without audio\n", timeoutMs);
    return false;
}

// Watchdogged ma_device_init: the ONE lifecycle call the original scheme
// missed. Called on the main thread during a default-device switch, init
// opens the new default endpoint through COM (GetDefaultAudioEndpoint /
// IMMDevice_Activate) — exactly while Windows is mid-switch and the
// audio session state is in flux, so it can block far past any sane
// bound. Returns 1 = initialized, 0 = init failed cleanly (storage is
// free, caller may delete it), -1 = TIMED OUT: the detached helper
// thread may still be inside ma_device_init on `target`, so the caller
// must treat the storage as owned by that thread forever (leak it).
static int ma_device_init_watchdog(ma_device* target, const ma_device_config* cfg,
                                   std::atomic<bool>& stuckFlag, int timeoutMs) {
    if (stuckFlag.load(std::memory_order_acquire)) return 0;
    auto done = std::make_shared<std::atomic<bool>>(false);
    auto res = std::make_shared<ma_result>(MA_ERROR);
    std::thread helper([done, res, target, cfg]() {
        *res = ma_device_init(nullptr, cfg, target);
        done->store(true, std::memory_order_release);
    });
    auto limit = std::chrono::steady_clock::now() + std::chrono::milliseconds(timeoutMs);
    while (std::chrono::steady_clock::now() < limit) {
        if (done->load(std::memory_order_acquire)) {
            helper.join();
            return *res == MA_SUCCESS ? 1 : 0;
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(2));
    }
    helper.detach();
    stuckFlag.store(true, std::memory_order_release);
    printf("[ma_thing] ma_device_init timed out (%d ms) — device storage leaked, retrying next pump\n", timeoutMs);
    return -1;
}

// ==========================================================================
//  AudioSystem
// ==========================================================================
class AudioSystem {
public:
    std::vector<DecoderStream> streams;
    std::unique_ptr<std::atomic<float>[]> decoderVolumes;
    size_t decoderVolumesCount = 0;
    std::atomic<uint64_t> volumeVersion{0}; // FIX: Version counter for cache invalidation
    
    std::vector<std::string> filePaths;
    /**
        The playback device, HEAP-ALLOCATED on purpose. When a device wedges
        (a lifecycle watchdog fired), its storage is moved to a graveyard
        vector and never touched again: the detached helper thread is still
        blocked inside miniaudio on that object, so the memory must outlive
        the process. A fresh device is then allocated for the rebuild. (A
        value member would be memset-recycled under the stuck thread's feet
        — use-after-free.)
    */
    ma_device* device = nullptr;
    /**
        Wedged device storage. Leaked on purpose (see `device` above) —
        never freed, never reused; just parked so the stuck thread can keep
        "using" it safely until process exit.
    */
    std::vector<ma_device*> deviceGraveyard;
    StretchPipeline* stretchPipe = nullptr;
    SubBusDSP subDSP;
    int longestDecoderIndex = 0;
    std::atomic<float> playbackRate{1.0f};
    std::atomic<int> mixerState{3};
    std::atomic<bool> exists{false};
    std::atomic<bool> stretchEnabled{true};
    
    std::atomic<bool> surroundEnabled{false};
    std::atomic<int> playbackChannels{CHANNEL_COUNT};
    std::vector<AtomicInt> streamChannels; // FIX: Replaced deque<atomic> with vector<AtomicInt> wrapper
    std::vector<float> streamLpfState;
    
    float pitchInputMix[MAX_PITCH_FRAMES * SURROUND_CHANNEL_COUNT] = {};
    // Staging for the surround routes. The PITCHED path stages up to
    // MAX_PITCH_FRAMES frames here (rate up to 10x means frameCount*rate
    // can far exceed MAX_CALLBACK_FRAMES), so it must be sized for the
    // pitch worst case — a MAX_CALLBACK_FRAMES-sized stage overflows the
    // heap the moment pitched playback runs with surround on.
    float streamStage[MAX_PITCH_FRAMES * CHANNEL_COUNT] = {};
    
    mutable std::atomic<long long> predictBaseTimeNs{0};
    mutable std::atomic<double> predictBaseFrames{0.0};
    mutable std::atomic<double> predictRate{1.0};
    mutable std::atomic<bool> predictInit{false};
    mutable std::atomic<float> predictPrevRate{1.0f};

    AudioSystem() {
        init_simd_dispatch();
        stretchPipe = new StretchPipeline();
    }
    ~AudioSystem() { destroy(); }
    AudioSystem(AudioSystem&& other) noexcept { moveFrom(std::move(other)); }
    AudioSystem& operator=(AudioSystem&& other) noexcept {
        if (this != &other) { destroy(); moveFrom(std::move(other)); }
        return *this;
    }
    AudioSystem(const AudioSystem&) = delete;
    AudioSystem& operator=(const AudioSystem&) = delete;

    // ---- device-change resilience ------------------------------------------
    // A default-device switch (unplug, Bluetooth takeover, control-panel
    // change) is handled by miniaudio's own device-change thread: it
    // stops, reinits and restarts the device. When that internal reroute
    // wedges or fails (the "collapse"), the device is dead while
    // mixerState still reports playing — the position keeps integrating
    // on wall clock over silence, and every later stop/uninit blocks
    // forever (the close deadlock that needed a process kill). Three legs:
    //   1) a notification callback that only raises flags — never calls
    //      back into the device (doing so from miniaudio's own
    //      device-change thread is the documented way to deadlock);
    //   2) a main-thread pump (pumpDeviceRecovery, once per frame) that
    //      waits out a short grace period for miniaudio's internal
    //      recovery, then rebuilds the device itself;
    //   3) watchdogged stop/uninit/start: a wedged device gets one
    //      timeout window, then the call thread is detached and the
    //      device LEAKED — audio is gone either way, but the game keeps
    //      running and the process still closes.
    std::atomic<bool> deviceLost{false};       // external stop seen (device died / switched)
    std::atomic<bool> stoppingSelf{false};     // our own stop is in flight — its notification is not a loss
    std::atomic<bool> recoveryInProgress{false};
    std::atomic<bool> lifecycleStuck{false};   // a lifecycle watchdog fired — leak mode, stop trying
    /** Consecutive pump frames the device looked dead; plain int — pump-only. */
    int lostTicks = 0;
    /**
        How many pump frames miniaudio's internal recovery gets before we
        take over. A default-device switch makes miniaudio's own
        device-change thread stop, RE-INIT and restart the device — on
        Bluetooth/USB switches that sequence can take several seconds.
        Rebuilding on top of that in-flight reroute (our stop/init vs
        theirs, same audio session) is what wedged both threads and froze
        the game, so the grace window must outlast the slowest reroute.
        300 frames = 5 s at 60fps.
    */
    static constexpr int DEVICE_LOST_GRACE_TICKS = 300;
    /** How long one watchdogged device lifecycle call may take. */
    static constexpr int LIFECYCLE_TIMEOUT_MS = 1500;

    static void onDeviceNotification(const ma_device_notification* pNotification) {
        AudioSystem* sys = static_cast<AudioSystem*>(pNotification->pDevice->pUserData);
        if (!sys) return;
        switch (pNotification->type) {
        case ma_device_notification_type_started:
            // The device runs again — either our own start or miniaudio's
            // internal reroute completed. Either way there is nothing to
            // recover.
            sys->deviceLost.store(false, std::memory_order_release);
            break;
        case ma_device_notification_type_stopped:
            // Ours (guarded by stoppingSelf) or external (unplug/error).
            // External means the device this engine built is no longer
            // running — flag it and let the pump decide.
            if (!sys->stoppingSelf.load(std::memory_order_acquire))
                sys->deviceLost.store(true, std::memory_order_release);
            break;
        default:
            // rerouted fires mid-recovery (before the restart); started
            // above closes the sequence. Interruptions are mobile-only.
            break;
        }
    }

    bool stopDeviceWatchdog() {
        if (!ma_device_is_started(device)) return true;
        stoppingSelf.store(true, std::memory_order_release);
        bool ok = ma_device_lifecycle_watchdog([this]() { ma_device_stop(device); }, lifecycleStuck, LIFECYCLE_TIMEOUT_MS);
        stoppingSelf.store(false, std::memory_order_release);
        return ok;
    }

    bool uninitDeviceWatchdog() {
        return ma_device_lifecycle_watchdog([this]() { ma_device_uninit(device); }, lifecycleStuck, LIFECYCLE_TIMEOUT_MS);
    }

    bool startDeviceWatchdog() {
        stoppingSelf.store(true, std::memory_order_release);
        auto res = std::make_shared<ma_result>(MA_ERROR);
        bool ok = ma_device_lifecycle_watchdog([this, res]() { *res = ma_device_start(device); }, lifecycleStuck, LIFECYCLE_TIMEOUT_MS);
        stoppingSelf.store(false, std::memory_order_release);
        return ok && *res == MA_SUCCESS;
    }

    /**
        Parks the current device storage in the graveyard — the detached
        helper thread is still blocked inside it, so the memory must
        outlive the process. Callers only call this when a lifecycle
        watchdog timed out. The stuck flag is cleared so the FRESH device
        the rebuild allocates gets fresh watchdog chances (a set flag
        would make every later start/stop no-op and the device would
        never come back up).
    **/
    void parkWedgedDevice() {
        if (!device) return;
        deviceGraveyard.push_back(device);
        device = nullptr;
        lifecycleStuck.store(false, std::memory_order_release);
    }

    // (Re)builds the playback device with the current channel layout and
    // the notification callback wired in. The caller must have stopped and
    // uninitialized (or parked) the previous device. Returns true on
    // success; on failure mixerState is left at stopped/finished.
    bool buildDevice() {
        int wantedChannels = surroundEnabled.load(std::memory_order_acquire) ? SURROUND_CHANNEL_COUNT : CHANNEL_COUNT;
        int prevState = mixerState.load(std::memory_order_acquire);
        bool wasPlaying = (prevState == 1);
        bool surroundFellBack = false;

        // One attempt with the wanted layout, then a stereo retry when it
        // failed CLEANLY (a timeout means a detached helper thread still
        // owns the storage — that one leaks via the graveyard, never a
        // retry on the same object).
        device = new ma_device();
        memset(device, 0, sizeof(ma_device));
        ma_device_config deviceConfig = ma_device_config_init(ma_device_type_playback);
        deviceConfig.playback.format = SAMPLE_FORMAT;
        deviceConfig.playback.channels = wantedChannels;
        ma_thing_set_channel_map(&deviceConfig, wantedChannels);
        deviceConfig.sampleRate = SAMPLE_RATE;
        deviceConfig.periodSizeInFrames = PERIOD_SIZE;
        deviceConfig.dataCallback = data_callback;
        deviceConfig.notificationCallback = onDeviceNotification;
        deviceConfig.pUserData = this;
        // Own the recovery end-to-end: miniaudio's internal auto stream
        // routing stops/reinits/restarts the device from its notification
        // thread, colliding with this engine's pump/watchdog discipline
        // and (because the reroute rebuilds converters from a guessed
        // channel map) misrouting center/LFE after a default switch. With
        // it disabled, a switch just leaves the device stopped — our pump
        // notices (playing-but-not-started) and rebuilds cleanly with the
        // explicit map above.
        deviceConfig.wasapi.noAutoStreamRouting = MA_TRUE;

        int initRes = ma_device_init_watchdog(device, &deviceConfig, lifecycleStuck, LIFECYCLE_TIMEOUT_MS);
        if (initRes < 0) {
            // Timed out: leak the storage (the helper thread may still be
            // inside ma_device_init on it) and report failure — the pump
            // retries with a fresh allocation after the grace period.
            parkWedgedDevice();
            mixerState.store(3, std::memory_order_release);
            return false;
        }
        if (initRes == 0 && wantedChannels != CHANNEL_COUNT) {
            // Clean failure with surround: free the storage and retry stereo.
            delete device;
            device = new ma_device();
            memset(device, 0, sizeof(ma_device));
            deviceConfig.playback.channels = CHANNEL_COUNT;
            ma_thing_set_channel_map(&deviceConfig, CHANNEL_COUNT);
            initRes = ma_device_init_watchdog(device, &deviceConfig, lifecycleStuck, LIFECYCLE_TIMEOUT_MS);
            if (initRes < 0) {
                parkWedgedDevice();
                mixerState.store(3, std::memory_order_release);
                return false;
            }
            surroundFellBack = (initRes == 1);
        }
        if (initRes == 0) {
            printf("Failed to open playback device.\n");
            delete device;
            device = nullptr;
            mixerState.store(3, std::memory_order_release);
            return false;
        }
        if (surroundFellBack) {
            playbackChannels.store(CHANNEL_COUNT, std::memory_order_release);
            surroundEnabled.store(false, std::memory_order_release);
            printf("Surround Sound 3.1 unavailable on this device; falling back to stereo.\n");
        } else {
            playbackChannels.store(wantedChannels, std::memory_order_release);
        }
        // destroy() deletes the pipeline (loadFiles → destroy → build);
        // re-create it so pitched playback keeps its FFT worker.
        if (!stretchPipe) stretchPipe = new StretchPipeline();
        if (stretchPipe) { stretchPipe->reset(); stretchPipe->configureChannels(playbackChannels.load(std::memory_order_acquire)); }
        predictInit.store(false, std::memory_order_relaxed);
        if (wasPlaying) {
            if (startDeviceWatchdog()) mixerState.store(1, std::memory_order_release);
            else mixerState.store(2, std::memory_order_release);
        } else {
            mixerState.store(prevState, std::memory_order_release);
        }
        return true;
    }

    // Full device rebuild (device-loss recovery, surround toggle). The
    // recoveryInProgress gate keeps concurrent rebuild paths (pump,
    // surround toggle, loadFiles) from interleaving their
    // stop/uninit/init cycles; data_callback also silences itself while
    // it is set, so a rebuild can never race the mix.
    void rebuildDevice() {
        bool expected = false;
        if (!recoveryInProgress.compare_exchange_strong(expected, true, std::memory_order_acq_rel))
            return;
        if (device) {
            if (!stopDeviceWatchdog() || !uninitDeviceWatchdog()) {
                parkWedgedDevice();            // storage stays for the stuck thread
            } else {
                delete device;
                device = nullptr;
            }
        }
        buildDevice();
        deviceLost.store(false, std::memory_order_release);
        recoveryInProgress.store(false, std::memory_order_release);
    }

    // Main-thread pump — call once per frame. Gives miniaudio's internal
    // reroute DEVICE_LOST_GRACE_TICKS frames to land (it restarts the
    // device itself when a new default appears), then rebuilds the
    // device. The rebuild triggers are deliberately CONSERVATIVE:
    //   - mixerState says PLAYING but the device is not started — the
    //     transport thinks audio flows while nothing runs (the collapse),
    //     or a start failed (unplugged while paused);
    //   - a lifecycle watchdog fired (lifecycleStuck) — every later
    //     stop/start on that device no-ops, so rebuild = park + fresh.
    // The deviceLost NOTIFICATION flag alone never triggers a rebuild: a
    // normal pause also raises it (the stoppingSelf guard only covers the
    // stop call itself), and rebuilding an intentionally stopped, healthy
    // device every pause would churn the audio stack for nothing. When a
    // real loss happens the flag is followed by one of the two triggers
    // above anyway (stopped device under a playing state, or a stuck
    // lifecycle call).
    void pumpDeviceRecovery() {
        if (!exists.load(std::memory_order_acquire)) { lostTicks = 0; return; }
        if (recoveryInProgress.load(std::memory_order_acquire)) return;
        if (device == nullptr) {                // last rebuild failed — retry every grace period
            if (++lostTicks >= DEVICE_LOST_GRACE_TICKS) {
                lostTicks = 0;
                printf("[ma_thing] audio device lost — retrying playback device\n");
                rebuildDevice();
            }
            return;
        }
        bool playing = (mixerState.load(std::memory_order_acquire) == 1);
        bool started = ma_device_is_started(device);
        bool stuck = lifecycleStuck.load(std::memory_order_acquire);
        // Note: the deviceLost notification flag is intentionally NOT a
        // rebuild trigger — it can lag a self-stop (our own stop's
        // notification may land after stoppingSelf is cleared), which
        // would rebuild a healthy paused device. The two triggers above
        // cover every real loss: an external force-stop (unplug, reroute)
        // drops a started device to not-started with mixerState still
        // PLAYING (= the collapse trigger), and a wedged lifecycle call
        // sets lifecycleStuck (= the stuck trigger). deviceLost stays as
        // the diagnostic handshake for the started-notification path.
        if ((playing && !started) || stuck) {
            if (++lostTicks >= DEVICE_LOST_GRACE_TICKS) {
                lostTicks = 0;
                printf("[ma_thing] audio device lost — rebuilding playback device\n");
                rebuildDevice();
            }
        } else {
            lostTicks = 0;
        }
    }

    void loadFiles(std::vector<const char*> argv) {
        if (argv.empty()) { printf("No input files.\n"); return; }
        destroy();
        filePaths.clear();
        for (auto p : argv) filePaths.push_back(p);
        streams.resize(argv.size());
        
        decoderVolumesCount = argv.size();
        decoderVolumes.reset(new std::atomic<float>[decoderVolumesCount]());
        for (size_t i = 0; i < decoderVolumesCount; ++i) decoderVolumes[i].store(1.0f, std::memory_order_relaxed);
        
        ma_uint64 longestLength = 0;
        for (size_t i = 0; i < argv.size(); i++) {
            DecoderStream& s = streams[i];
            s.decoderPath = argv[i];
            ma_decoder probe;
            if (!s.openTempDecoder(&probe)) {
                streams.clear(); decoderVolumes.reset(); decoderVolumesCount = 0; filePaths.clear();
                printf("Failed to load %s.\n", argv[i]);
                exists.store(false, std::memory_order_release);
                return;
            }
            ma_decoder_get_length_in_pcm_frames(&probe, &s.decoderLength);
            ma_decoder_uninit(&probe);
            s.pcmBufferA = (float*)malloc(sizeof(float) * TOTAL_BUFFER_FRAMES * CHANNEL_COUNT);
            s.pcmBufferB = (float*)malloc(sizeof(float) * TOTAL_BUFFER_FRAMES * CHANNEL_COUNT);
            s.pcmBufferC = (float*)malloc(sizeof(float) * TOTAL_BUFFER_FRAMES * CHANNEL_COUNT);
            memset(s.pcmBufferA, 0, sizeof(float) * TOTAL_BUFFER_FRAMES * CHANNEL_COUNT);
            memset(s.pcmBufferB, 0, sizeof(float) * TOTAL_BUFFER_FRAMES * CHANNEL_COUNT);
            memset(s.pcmBufferC, 0, sizeof(float) * TOTAL_BUFFER_FRAMES * CHANNEL_COUNT);
            s.activeBuffer = s.pcmBufferA; s.nextBuffer = s.pcmBufferB; s.loadingBuffer = s.pcmBufferC;
            s.asyncState.asyncNextBuffer = s.pcmBufferB; s.asyncState.asyncLoadingBuffer = s.pcmBufferC;
            
            bool workerOpened = false;
            {
                ma_decoder_config workerConfig = ma_decoder_config_init(SAMPLE_FORMAT, CHANNEL_COUNT, SAMPLE_RATE);
                if (ma_decoder_init_file(argv[i], &workerConfig, &s.workerDecoder) == MA_SUCCESS) {
                    ma_data_source_set_looping(&s.workerDecoder, MA_FALSE);
                    s.workerDecoderInitialized = true;
                    workerOpened = true;
                }
            }
            if (!workerOpened) {
                streams.clear(); decoderVolumes.reset(); decoderVolumesCount = 0; filePaths.clear();
                printf("Failed to load %s.\n", argv[i]);
                exists.store(false, std::memory_order_release);
                return;
            }
            fillInitialBuffer(i, 0);
            if (s.active.load(std::memory_order_acquire)) {
                loadNextBufferSync(i);
                if (s.asyncState.nextBufferReady.load(std::memory_order_relaxed)) loadLoadingBufferSync(i);
            }
            if (s.decoderLength > longestLength) {
                longestLength = s.decoderLength;
                longestDecoderIndex = (int)i;
            }
        }
        streamPtrs.clear();
        for (auto& s : streams) streamPtrs.push_back(&s);
        if (asyncLoader) delete asyncLoader;
        asyncLoader = new AsyncLoader(streamPtrs);
        
        streamChannels.clear();
        streamChannels.reserve(streams.size());
        streamLpfState.assign(streams.size(), 0.0f);
        for (size_t i = 0; i < streams.size(); i++) {
            streamChannels.emplace_back((i == 0) ? MA_CH_BACKGROUND : MA_CH_CENTER);
        }

        // The shared builder wires data_callback + the device-change
        // notification and applies the surround fallback (device == null
        // means a failed build — exists stays false, pumpDeviceRecovery
        // keeps retrying every grace period).
        buildDevice();
        exists.store(device != nullptr, std::memory_order_release);
        if (device == nullptr) {
            streams.clear(); decoderVolumes.reset(); decoderVolumesCount = 0; filePaths.clear();
            streamChannels.clear(); streamLpfState.clear();
            return;
        }
        mixerState.store(3, std::memory_order_release);
    }

    void destroy() {
        if (!exists.load(std::memory_order_acquire)) return;
        exists.store(false, std::memory_order_release);
        deviceLost.store(false, std::memory_order_release);
        lostTicks = 0;
        // Watchdogged teardown: a wedged device parks instead of hanging
        // the close (the old close deadlock — process had to be killed).
        if (device) {
            if (stopDeviceWatchdog() && uninitDeviceWatchdog()) {
                delete device;
                device = nullptr;
            } else {
                parkWedgedDevice();
            }
        }
        if (asyncLoader) { delete asyncLoader; asyncLoader = nullptr; }
        streams.clear();
        decoderVolumes.reset(); decoderVolumesCount = 0;
        filePaths.clear();
        streamPtrs.clear();
        streamChannels.clear();
        streamLpfState.clear();
        if (stretchPipe) { delete stretchPipe; stretchPipe = nullptr; }
        longestDecoderIndex = 0;
        // playbackRate deliberately NOT reset here: it is GLOBAL
        // mixer state, not per-pipeline state. loadFiles() runs
        // destroy() as its first step (loadFiles -> destroy ->
        // build), so resetting here silently reverted the global
        // rate to 1x on every song (re)load - chart restarts
        // (backwards seeks) and song-end transitions included. The
        // rate now survives the rebuild; Mixer.load re-asserts it
        // on the Haxe side as well.
        mixerState.store(3, std::memory_order_release);
        predictInit.store(false, std::memory_order_relaxed);
        predictBaseTimeNs.store(0, std::memory_order_relaxed);
        predictBaseFrames.store(0.0, std::memory_order_relaxed);
        predictRate.store(1.0, std::memory_order_relaxed);
        predictPrevRate.store(1.0f, std::memory_order_relaxed);
        subDSP.reset();
        // device pointer already handled above (deleted or parked).
    }

    void start() {
        if (!exists.load(std::memory_order_acquire)) return;
        if (mixerState.load(std::memory_order_acquire) == 3) seekToPCMFrame(0);
        if (asyncLoader) asyncLoader->resumeLoading();
        mixerState.store(1, std::memory_order_release);
        ma_uint64 startFrame = 0;
        if (!streams.empty()) startFrame = streams[longestDecoderIndex].filePosition.load(std::memory_order_relaxed);
        predictInit.store(false, std::memory_order_relaxed);
        if (device) startDeviceWatchdog();
    }

    void stop() {
        if (!exists.load(std::memory_order_acquire)) return;
        mixerState.store(2, std::memory_order_release);
        if (asyncLoader) asyncLoader->pauseLoading();
        if (device) stopDeviceWatchdog();
        // Kill the predicted-clock extrapolation the moment the transport
        // stops. Without this, getPlaybackPosition() keeps integrating
        // baseFrames + wallClockDelta * rate across the whole stopped span:
        // a read after a long stop (editor pause / playback toggle) returns
        // a position FAR ahead of the audio, and the first data_callback
        // after resume sees a huge position error that the alpha-beta filter
        // then walks BACKWARD ~15% per callback — heard and shown as the
        // song position being subtracted for a second or more after every
        // resume, landing wherever it pleases (often an empty section).
        // With predictInit cleared, the position after stop reads exactly
        // the frozen filePosition, and resume re-bases the predictor on the
        // first callback — no gap integration, no backward walk, no drift.
        predictInit.store(false, std::memory_order_relaxed);
    }

    bool stopped() const { return mixerState.load(std::memory_order_acquire) == 3; }

    void seekToPCMFrame(int64_t pos) {
        if (!exists.load(std::memory_order_acquire)) return;
        bool deviceRunning = device && ma_device_is_started(device);
        if (deviceRunning) mixerState.store(2, std::memory_order_release);
        if (asyncLoader) asyncLoader->pauseLoading();
        if (asyncLoader) asyncLoader->waitUntilIdle();
        if (deviceRunning) stopDeviceWatchdog();
        if (stretchPipe) stretchPipe->reset();
        for (size_t i = 0; i < streams.size(); i++) {
            DecoderStream& s = streams[i];
            ma_uint64 target = std::min<ma_uint64>((ma_uint64)std::max<int64_t>(pos, 0), s.decoderLength);
            s.resetState();
            fillInitialBuffer(i, target);
            if (s.active.load(std::memory_order_acquire) && target < s.decoderLength) s.filePosition.store(target, std::memory_order_release);
            if (s.active.load(std::memory_order_acquire)) {
                loadNextBufferSync(i);
                if (s.asyncState.nextBufferReady.load(std::memory_order_relaxed)) loadLoadingBufferSync(i);
            }
            if (s.workerDecoderInitialized) ma_decoder_seek_to_pcm_frame(&s.workerDecoder, target);
        }
        mixerState.store((pos < (int64_t)streams[longestDecoderIndex].decoderLength) ? 2 : 3, std::memory_order_release);
        predictInit.store(false, std::memory_order_relaxed);
        if (deviceRunning && mixerState.load(std::memory_order_acquire) == 2) {
            if (asyncLoader) asyncLoader->resumeLoading();
            mixerState.store(1, std::memory_order_release);
            startDeviceWatchdog();
        }
    }

    void deactivate_decoder(int index) {
        if (index >= 0 && index < (int)streams.size()) streams[index].active.store(false, std::memory_order_release);
    }

    void amplify_decoder(int index, double volume) {
        if (index >= 0 && index < (int)decoderVolumesCount) {
            decoderVolumes[index].store((float)volume, std::memory_order_relaxed);
            volumeVersion.fetch_add(1, std::memory_order_release); // FIX: Increment version
        }
    }

    void setPlaybackRate(float value) { playbackRate.store(value, std::memory_order_release); }
    void setStretchEnabled(bool value) { stretchEnabled.store(value, std::memory_order_release); }
    double getGlobalVolume() const { return MUSIC_MASTER_VOLUME_099.load(std::memory_order_relaxed); }
    double setGlobalVolume(double v) { MUSIC_MASTER_VOLUME_099.store(v, std::memory_order_relaxed); return v; }
    int getMixerState() const { return mixerState.load(std::memory_order_acquire); }
    // The device/decoder sample rate (SAMPLE_RATE, 48000). Exposed so the
    // Haxe side converts ms <-> PCM frames with the SAME rate the engine
    // uses — Mixer.hx used to hardcode 44100 while the engine ran at
    // 48000, so every seek landed at 91.9% of the target: a position-
    // proportional send-back on every editor resume ("the further in,
    // the further back").
    int getSampleRate() const { return SAMPLE_RATE; }

    bool isSurroundEnabled() const { return surroundEnabled.load(std::memory_order_acquire); }
    void setSurroundEnabled(bool enable) {
        g_maThingSurround.store(enable, std::memory_order_release); // mixer device reads this on (re)build
        bool prev = surroundEnabled.exchange(enable, std::memory_order_acq_rel);
        if (prev == enable) return;
        if (!exists.load(std::memory_order_acquire)) {
            int wanted = enable ? SURROUND_CHANNEL_COUNT : CHANNEL_COUNT;
            playbackChannels.store(wanted, std::memory_order_release);
            if (stretchPipe) { stretchPipe->reset(); stretchPipe->configureChannels(wanted); }
            return;
        }
        int prevState = mixerState.load(std::memory_order_acquire);
        bool wasPlaying = (prevState == 1);
        // Full watchdogged rebuild — the same path device-loss recovery
        // uses (stop, uninit, park-if-wedged, fresh build with the
        // notification callback wired in).
        rebuildDevice();
        if (!wasPlaying) mixerState.store(prevState, std::memory_order_release);
    }

    void setStreamChannel(int index, int channel) {
        if (index >= 0 && index < (int)streamChannels.size() && channel >= MA_CH_CENTER && channel <= MA_CH_SUB)
            streamChannels[index].store(channel, std::memory_order_release);
    }
    int getStreamChannel(int index) const {
        if (index >= 0 && index < (int)streamChannels.size()) return streamChannels[index].load(std::memory_order_acquire);
        return (index == 0) ? MA_CH_BACKGROUND : MA_CH_CENTER;
    }

    double getPlaybackPosition() const {
        if (!exists.load(std::memory_order_acquire) || streams.empty()) return 0.0;
        const DecoderStream& s = streams[longestDecoderIndex];
        if (!s.active.load(std::memory_order_acquire)) return (double)s.decoderLength / (SAMPLE_RATE * 0.001);
        if (!predictInit.load(std::memory_order_relaxed)) return (double)s.filePosition.load(std::memory_order_relaxed) / (SAMPLE_RATE * 0.001);
        double baseT = predictBaseTimeNs.load(std::memory_order_relaxed);
        double baseF = predictBaseFrames.load(std::memory_order_relaxed);
        double baseR = predictRate.load(std::memory_order_relaxed);
        long long nowNs = std::chrono::steady_clock::now().time_since_epoch().count();
        double dt = (nowNs - baseT) * 1e-9;
        double predicted = baseF + dt * SAMPLE_RATE * baseR;
        if (predicted < 0.0) predicted = 0.0;
        if (predicted > (double)s.decoderLength) predicted = (double)s.decoderLength;
        return predicted / (SAMPLE_RATE * 0.001);
    }
    double getDuration() const {
        if (streams.empty()) return 0.0;
        return (double)streams[longestDecoderIndex].decoderLength / (SAMPLE_RATE * 0.001);
    }

private:
    AsyncLoader* asyncLoader = nullptr;
    std::vector<DecoderStream*> streamPtrs;

    void fillInitialBuffer(size_t index, ma_uint64 startFrame) {
        DecoderStream& s = streams[index];
        if (index < streamLpfState.size()) streamLpfState[index] = 0.0f;
        ma_uint64 decodeStart = (startFrame > PADDING_FRAMES) ? startFrame - PADDING_FRAMES : 0;
        ma_uint64 framesRead = 0;
        s.fillBufferTemp(decodeStart, s.activeBuffer, &framesRead);
        s.bufferStartPos = decodeStart;
        s.validFrames = framesRead;
        s.localReadPos = (startFrame >= decodeStart) ? startFrame - decodeStart : 0;
        if (s.localReadPos >= TOTAL_BUFFER_FRAMES) s.localReadPos = TOTAL_BUFFER_FRAMES - 1;
        s.filePosition.store(startFrame, std::memory_order_release);
        s.active.store((startFrame < s.decoderLength && framesRead > 0), std::memory_order_release);
        s.asyncState.needsLoad.store(false, std::memory_order_release);
    }
    void loadNextBufferSync(size_t index) {
        DecoderStream& s = streams[index];
        if (!s.active.load(std::memory_order_acquire) || s.asyncState.nextBufferReady.load(std::memory_order_relaxed)) return;
        ma_uint64 start = s.bufferStartPos + HALF_BUFFER_FRAMES;
        if (start > PADDING_FRAMES) start -= PADDING_FRAMES;
        if (start >= s.decoderLength) return;
        ma_uint64 framesRead = 0;
        s.fillBufferTemp(start, s.nextBuffer, &framesRead);
        s.asyncState.nextBufferStartPos = start;
        s.asyncState.nextBufferValidFrames = framesRead;
        s.asyncState.nextBufferReady.store(true, std::memory_order_release);
    }
    void loadLoadingBufferSync(size_t index) {
        DecoderStream& s = streams[index];
        if (!s.active.load(std::memory_order_acquire) || s.asyncState.loadingBufferReady.load(std::memory_order_relaxed) || !s.asyncState.nextBufferReady.load(std::memory_order_relaxed)) return;
        ma_uint64 start = s.asyncState.nextBufferStartPos + HALF_BUFFER_FRAMES;
        if (start > PADDING_FRAMES) start -= PADDING_FRAMES;
        if (start >= s.decoderLength) return;
        ma_uint64 framesRead = 0;
        s.fillBufferTemp(start, s.loadingBuffer, &framesRead);
        s.asyncState.loadingBufferStartPos = start;
        s.asyncState.loadingBufferValidFrames = framesRead;
        s.asyncState.loadingBufferReady.store(true, std::memory_order_release);
    }
    // The anchor tone's phase — advances 2*pi*20/SAMPLE_RATE per frame,
    // shared by every 8-channel writer (one tone for the whole device).
    float rearAnchorPhase = SURROUND_ANCHOR_PHASE0;
    // Adds the anchor tone's next sample to the four rear channels of ONE
    // output frame: the min-biased sine (amp*(0.5 + 0.49*sin) — see the
    // constants' comment) is strictly positive even at sinf == -1.0f, and
    // the phase advances one sample period (wrapped at 2*pi).
    inline void rearAnchor(float* d) {
        const float tone = SURROUND_ANCHOR_AMP
            * (SURROUND_ANCHOR_BIAS + SURROUND_ANCHOR_SPAN * sinf(rearAnchorPhase));
        d[4] += tone; d[5] += tone; d[6] += tone; d[7] += tone;
        rearAnchorPhase += (float)(2.0 * 3.14159265358979323846 * SURROUND_ANCHOR_HZ / SAMPLE_RATE);
        // Wrap to [0, 2pi): a growing phase loses sinf's argument-reduction
        // precision (the surround test caught min-sample hitting 0 after
        // ~2.5 hours of frames). Bounded phase keeps the bias guarantee
        // exact forever.
        if (rearAnchorPhase > 6.2831855f) rearAnchorPhase -= 6.2831855f;
    }
    void routeStreamToOutput(size_t index, const float* stage, float* out, ma_uint32 outFrames, int outCh) {        const int route = streamChannels[index].load(std::memory_order_acquire);
        float lpf = streamLpfState[index];
        if (outCh == SURROUND_CHANNEL_COUNT) {
            // Channel indices (Microsoft 7.1 order, see MA_THING_SURROUND_MAP):
            //   0 FL  1 FR  2 C  3 LFE  4 BL  5 BR  6 SL  7 SR
            // v3.9.0 room discipline: the song NEVER spreads into the rears
            // (BL/BR/SL/SR) — the environment around the song's front image
            // stays untouched. Those four channels instead carry the ANCHOR
            // TONE: a DC-biased 20 Hz sine at amplitude 0.001 (sample =
            // amp + amp*sin — strictly positive by construction; see the
            // constants' comment). Inaudible, but it keeps the channels
            // 'alive' so the receiver never sleeps on them and never
            // renormalizes the front image.
            switch (route) {
                case MA_CH_CENTER:
                    for (ma_uint32 f = 0; f < outFrames; f++) {
                        float sl = stage[f * 2], sr = stage[f * 2 + 1];
                        float mono = (sl + sr) * 0.5f;
                        lpf += SURROUND_LPF_COEF * (mono - lpf);
                        float* d = out + f * outCh;
                        d[2] += mono;
                        d[3] += lpf * SURROUND_LFE_BASS_GAIN;
                        rearAnchor(d);
                    } break;
                case MA_CH_SUB:
                    for (ma_uint32 f = 0; f < outFrames; f++) {
                        float sl = stage[f * 2], sr = stage[f * 2 + 1];
                        float mono = (sl + sr) * 0.5f;
                        lpf += SURROUND_LPF_COEF * (mono - lpf);
                        float* d = out + f * outCh;
                        d[3] += lpf * SURROUND_LFE_FULL_GAIN;
                        rearAnchor(d);
                    } break;
                case MA_CH_BACKGROUND:
                default:
                    // The song bed: the instrumental stays strictly on the
                    // mains FL/FR (plus its bass-managed LFE fill). The rears
                    // get NOTHING of the song — only the anchor tone.
                    for (ma_uint32 f = 0; f < outFrames; f++) {
                        float sl = stage[f * 2], sr = stage[f * 2 + 1];
                        float mono = (sl + sr) * 0.5f;
                        lpf += SURROUND_LPF_COEF * (mono - lpf);
                        float* d = out + f * outCh;
                        d[0] += sl; d[1] += sr;
                        d[3] += lpf * SURROUND_LFE_BASS_GAIN;
                        rearAnchor(d);
                    } break;
            }
        }
        streamLpfState[index] = lpf;
    }

    ma_uint32 readFromBuffer(size_t index, float* output, ma_uint32 requestedFrames) {
        DecoderStream& s = streams[index];
        if (!s.active.load(std::memory_order_acquire)) return 0;
        
        static thread_local uint64_t cachedVersion = 0;
        static thread_local double cachedMasterVolume = -1.0;
        static thread_local std::vector<float> precomputedVolumes;

        if (precomputedVolumes.size() != decoderVolumesCount) {
            precomputedVolumes.resize(decoderVolumesCount, 0.0f);
            cachedVersion = 0;
            cachedMasterVolume = -1.0;
        }

        uint64_t currentVersion = volumeVersion.load(std::memory_order_acquire);
        double currentMasterVolume = MUSIC_MASTER_VOLUME_099.load(std::memory_order_relaxed);

        bool volumesChanged = (currentVersion != cachedVersion) || (currentMasterVolume != cachedMasterVolume);

        if (volumesChanged) {
            cachedMasterVolume = currentMasterVolume;
            cachedVersion = currentVersion;
            for (size_t i = 0; i < decoderVolumesCount; i++) {
                precomputedVolumes[i] = decoderVolumes[i].load(std::memory_order_relaxed) * (float)cachedMasterVolume;
            }
        }
        float vol = precomputedVolumes[index];
        
        bool nextBufferReady = s.asyncState.nextBufferReady.load(std::memory_order_acquire);
        bool isActive = s.active.load(std::memory_order_acquire);
        if ((nextBufferReady && s.shouldSwapBuffers()) || s.isBufferLow()) s.trySwapBuffers();
        
        ma_uint32 framesRead = 0;
        while (framesRead < requestedFrames && isActive) {
            ma_uint64 available = (s.localReadPos < s.validFrames) ? s.validFrames - s.localReadPos : 0;
            if (available == 0) {
                if (s.bufferStartPos + s.localReadPos < s.decoderLength) {
                    if (s.asyncState.nextBufferReady.load(std::memory_order_acquire)) { s.trySwapBuffers(); continue; }
                    s.asyncState.needsLoad.store(true, std::memory_order_release);
                    s.requestBufferLoad();
                    break;
                }
                s.active.store(false, std::memory_order_release);
                isActive = false;
                break;
            }
            ma_uint32 toRead = std::min<ma_uint32>((ma_uint32)available, requestedFrames - framesRead);
            float* src = s.activeBuffer + (s.localReadPos * CHANNEL_COUNT);
            float* dst = output + (framesRead * CHANNEL_COUNT);
            int samples = (int)(toRead * CHANNEL_COUNT);
            if (vol != 0.0f) g_mix_func(dst, src, samples, vol);
            s.localReadPos += toRead;
            framesRead += toRead;
        }
        s.filePosition.store(s.bufferStartPos + s.localReadPos, std::memory_order_relaxed);
        if (isActive && !s.asyncState.nextBufferReady.load(std::memory_order_relaxed)) {
            ma_uint64 available = (s.localReadPos < s.validFrames) ? s.validFrames - s.localReadPos : 0;
            if (available < (HALF_BUFFER_FRAMES * 2) || framesRead < requestedFrames) {
                s.requestBufferLoad();
                s.asyncState.needsLoad.store(true, std::memory_order_release);
            }
        }
        return framesRead;
    }

    static void data_callback(ma_device* pDevice, void* pOutput, const void* pInput, ma_uint32 frameCount) {
        AudioSystem* sys = static_cast<AudioSystem*>(pDevice->pUserData);
        // Guard the rebuild window: while recoveryInProgress is set the
        // old device may already be stopped/uninitialized and `this` may
        // be mid-rebuild — a stale callback there would mix from freed
        // buffers. Output silence and return. (Also covers a parked
        // device's very last in-flight callback.)
        if (!sys || !sys->exists.load(std::memory_order_acquire)
            || sys->recoveryInProgress.load(std::memory_order_acquire)) {
            memset(pOutput, 0, sizeof(float) * frameCount * (pDevice->playback.channels));
            return;
        }
        float* out = (float*)pOutput;
        int outCh = sys->playbackChannels.load(std::memory_order_relaxed);
        memset(out, 0, sizeof(float) * frameCount * outCh);
        
        {
            double fp = sys->streams.empty() ? 0.0 : (double)sys->streams[sys->longestDecoderIndex].filePosition.load(std::memory_order_relaxed);
            long long nowNs = std::chrono::steady_clock::now().time_since_epoch().count();
            double rate = sys->playbackRate.load(std::memory_order_relaxed);
            if (!sys->predictInit.load(std::memory_order_relaxed)) {
                sys->predictBaseTimeNs.store(nowNs, std::memory_order_relaxed);
                sys->predictBaseFrames.store(fp, std::memory_order_relaxed);
                sys->predictRate.store((double)rate, std::memory_order_relaxed);
                sys->predictPrevRate.store((float)rate, std::memory_order_relaxed);
                sys->predictInit.store(true, std::memory_order_relaxed);
            } else {
                double prevRate = sys->predictPrevRate.load(std::memory_order_relaxed);
                bool rateChanged = std::fabs(rate - prevRate) > 1e-6;
                if (rateChanged) {
                    sys->predictBaseTimeNs.store(nowNs, std::memory_order_relaxed);
                    sys->predictBaseFrames.store(fp, std::memory_order_relaxed);
                    sys->predictRate.store((double)rate, std::memory_order_relaxed);
                    sys->predictPrevRate.store((float)rate, std::memory_order_relaxed);
                } else {
                    double baseT = sys->predictBaseTimeNs.load(std::memory_order_relaxed);
                    double baseF = sys->predictBaseFrames.load(std::memory_order_relaxed);
                    double baseR = sys->predictRate.load(std::memory_order_relaxed);
                    double dt = (nowNs - baseT) * 1e-9;
                    if (dt < 1e-6) dt = 1e-6;
                    double predicted = baseF + dt * SAMPLE_RATE * baseR;
                    double error = fp - predicted;
                    const double alpha = 0.15;
                    const double beta = 0.005;
                    double newBaseF = predicted + alpha * error;
                    double impliedRate = baseR + error / (dt * SAMPLE_RATE);
                    double drift = impliedRate / std::max<double>(rate, 1e-6);
                    if (drift < 0.999) drift = 0.999;
                    else if (drift > 1.001) drift = 1.001;
                    double newRate = rate * drift;
                    newRate = baseR * (1.0 - beta) + newRate * beta;
                    sys->predictBaseTimeNs.store(nowNs, std::memory_order_relaxed);
                    sys->predictBaseFrames.store(newBaseF, std::memory_order_relaxed);
                    sys->predictRate.store(newRate, std::memory_order_relaxed);
                }
            }
        }
        
        bool anyRefill = false;
        bool anyActive = false;
        float rate = sys->playbackRate.load(std::memory_order_acquire);
        if (rate == 1.0f) {
            for (size_t i = 0; i < sys->streams.size(); i++) {
                if (!sys->streams[i].active.load(std::memory_order_acquire)) continue;
                ma_uint32 read;
                if (outCh == SURROUND_CHANNEL_COUNT) {
                    memset(sys->streamStage, 0, sizeof(float) * frameCount * CHANNEL_COUNT);
                    read = sys->readFromBuffer(i, sys->streamStage, frameCount);
                    if (read > 0) sys->routeStreamToOutput(i, sys->streamStage, out, frameCount, outCh);
                } else {
                    read = sys->readFromBuffer(i, out, frameCount);
                }
                if (read > 0) anyActive = true;
                if (read < frameCount && sys->streams[i].active.load(std::memory_order_acquire)) anyRefill = true;
            }
        } else {
            static_assert(MAX_CALLBACK_FRAMES >= 4096, "MAX_CALLBACK_FRAMES too small for pitched playback buffers");
            if (frameCount > MAX_CALLBACK_FRAMES) {
                int currentState = sys->mixerState.load(std::memory_order_acquire);
                if (currentState != 2) sys->mixerState.store(anyActive ? 1 : 3, std::memory_order_release);
                (void)pInput;
                return;
            }
            float* inputMix = sys->pitchInputMix;
            static double positionError = 0;
            double exactRead = frameCount * rate + positionError;
            ma_uint32 maxToRead = (ma_uint32)exactRead;
            if (maxToRead > MAX_PITCH_FRAMES) maxToRead = MAX_PITCH_FRAMES;
            memset(inputMix, 0, sizeof(float) * maxToRead * outCh);
            positionError = exactRead - maxToRead;
            for (size_t i = 0; i < sys->streams.size(); i++) {
                if (!sys->streams[i].active.load(std::memory_order_acquire)) continue;
                ma_uint32 read;
                if (outCh == SURROUND_CHANNEL_COUNT) {
                    memset(sys->streamStage, 0, sizeof(float) * maxToRead * CHANNEL_COUNT);
                    read = sys->readFromBuffer(i, sys->streamStage, maxToRead);
                    if (read > 0) sys->routeStreamToOutput(i, sys->streamStage, inputMix, maxToRead, outCh);
                } else {
                    read = sys->readFromBuffer(i, inputMix, maxToRead);
                }
                if (read > 0) anyActive = true;
                if (read < maxToRead && sys->streams[i].active.load(std::memory_order_acquire)) anyRefill = true;
            }
            if (anyActive) {
                if (sys->stretchEnabled.load(std::memory_order_acquire)) {
                    if (sys->stretchPipe && sys->stretchPipe->push(inputMix, maxToRead, frameCount)) {
                        sys->stretchPipe->pull(out, frameCount);
                    }
                } else if (maxToRead > 0) {
                    double step = (frameCount > 1) ? (double)(maxToRead - 1) / (frameCount - 1) : 0.0;
                    for (ma_uint32 o = 0; o < frameCount; o++) {
                        double srcPos = o * step;
                        ma_uint32 i0 = (ma_uint32)srcPos;
                        if (i0 >= maxToRead) i0 = maxToRead - 1;
                        ma_uint32 i1 = (i0 + 1 < maxToRead) ? i0 + 1 : i0;
                        double frac = srcPos - (double)i0;
                        for (int c = 0; c < outCh; c++) {
                            float s0 = inputMix[i0 * outCh + c];
                            float s1 = inputMix[i1 * outCh + c];
                            out[o * outCh + c] = (float)(s0 + frac * (s1 - s0));
                        }
                    }
                }
            }
        }
        if (outCh == SURROUND_CHANNEL_COUNT && anyActive) sys->subDSP.process(out, frameCount);
        if (anyRefill && sys->asyncLoader) sys->asyncLoader->signal();
        int currentState = sys->mixerState.load(std::memory_order_acquire);
        if (currentState != 2) sys->mixerState.store(anyActive ? 1 : 3, std::memory_order_release);
        (void)pInput;
    }

    void moveFrom(AudioSystem&& other) noexcept {
        streams = std::move(other.streams);
        decoderVolumes = std::move(other.decoderVolumes);
        decoderVolumesCount = other.decoderVolumesCount;
        other.decoderVolumesCount = 0;
        volumeVersion.store(other.volumeVersion.load(std::memory_order_relaxed), std::memory_order_relaxed);
        filePaths = std::move(other.filePaths);
        streamPtrs = std::move(other.streamPtrs);
        stretchPipe = other.stretchPipe;
        asyncLoader = other.asyncLoader;
        streamChannels = std::move(other.streamChannels);
        streamLpfState = std::move(other.streamLpfState);
        playbackChannels.store(other.playbackChannels.load(std::memory_order_relaxed), std::memory_order_relaxed);
        surroundEnabled.store(other.surroundEnabled.load(std::memory_order_relaxed), std::memory_order_relaxed);
        device = other.device;
        deviceGraveyard = std::move(other.deviceGraveyard);
        other.device = nullptr;
        longestDecoderIndex = other.longestDecoderIndex;
        playbackRate.store(other.playbackRate.load(std::memory_order_relaxed), std::memory_order_relaxed);
        mixerState.store(other.mixerState.load(std::memory_order_relaxed), std::memory_order_relaxed);
        exists.store(other.exists.load(std::memory_order_relaxed), std::memory_order_relaxed);
        stretchEnabled.store(other.stretchEnabled.load(std::memory_order_relaxed), std::memory_order_relaxed);
        other.stretchPipe = nullptr; other.asyncLoader = nullptr;
        other.longestDecoderIndex = 0; other.playbackRate.store(1.0f, std::memory_order_relaxed);
        other.mixerState.store(3, std::memory_order_relaxed);
        other.exists.store(false, std::memory_order_relaxed);
        predictBaseTimeNs.store(other.predictBaseTimeNs.load(std::memory_order_relaxed), std::memory_order_relaxed);
        predictBaseFrames.store(other.predictBaseFrames.load(std::memory_order_relaxed), std::memory_order_relaxed);
        predictRate.store(other.predictRate.load(std::memory_order_relaxed), std::memory_order_relaxed);
        predictInit.store(other.predictInit.load(std::memory_order_relaxed), std::memory_order_relaxed);
        predictPrevRate.store(other.predictPrevRate.load(std::memory_order_relaxed), std::memory_order_relaxed);
        other.predictBaseTimeNs.store(0, std::memory_order_relaxed);
        other.predictBaseFrames.store(0.0, std::memory_order_relaxed);
        other.predictRate.store(1.0, std::memory_order_relaxed);
        other.predictInit.store(false, std::memory_order_relaxed);
        other.predictPrevRate.store(1.0f, std::memory_order_relaxed);
        memcpy(&subDSP, &other.subDSP, sizeof(SubBusDSP));
    }
};

// ==========================================================================
//  BackgroundTrack
// ==========================================================================
struct BackgroundTrack {
    float* pcmData = nullptr;
    ma_uint64 frameCount = 0;
    ma_uint64 readPos = 0;
    float volume = 1.0f;
    std::atomic<bool> active{false};
    bool looping = true;
    std::string filePath;

    BackgroundTrack() = default;
    ~BackgroundTrack() { cleanup(); }
    BackgroundTrack(BackgroundTrack&& other) noexcept { moveFrom(std::move(other)); }
    BackgroundTrack& operator=(BackgroundTrack&& other) noexcept {
        if (this != &other) { cleanup(); moveFrom(std::move(other)); }
        return *this;
    }
    BackgroundTrack(const BackgroundTrack&) = delete;
    BackgroundTrack& operator=(const BackgroundTrack&) = delete;

    void cleanup() {
        if (pcmData) { free(pcmData); pcmData = nullptr; }
        frameCount = 0; readPos = 0; volume = 1.0f;
        active.store(false, std::memory_order_release);
        looping = true; filePath.clear();
    }
    bool load(const char* path) {
        cleanup();
        ma_decoder decoder;
        ma_decoder_config cfg = ma_decoder_config_init(SAMPLE_FORMAT, CHANNEL_COUNT, SAMPLE_RATE);
        if (ma_decoder_init_file(path, &cfg, &decoder) != MA_SUCCESS) { printf("Failed to load background track: %s\n", path); return false; }
        ma_uint64 length = 0;
        ma_decoder_get_length_in_pcm_frames(&decoder, &length);
        if (length == 0) { ma_decoder_uninit(&decoder); printf("Background track has zero length: %s\n", path); return false; }
        pcmData = (float*)malloc(sizeof(float) * length * CHANNEL_COUNT);
        if (!pcmData) { ma_decoder_uninit(&decoder); printf("Failed to allocate memory for background track: %s\n", path); return false; }
        ma_uint64 framesRead = 0;
        ma_decoder_read_pcm_frames(&decoder, pcmData, length, &framesRead);
        ma_decoder_uninit(&decoder);
        if (framesRead == 0) { cleanup(); printf("Failed to read background track: %s\n", path); return false; }
        frameCount = framesRead; filePath = path;
        active.store(false, std::memory_order_release);
        looping = true; readPos = 0;
        return true;
    }
    void play() { if (pcmData) { readPos = 0; active.store(true, std::memory_order_release); } }
    void stop() { active.store(false, std::memory_order_release); readPos = 0; }
    void setVolume(float v) { volume = v; }
    void setLooping(bool lp) { looping = lp; }
    ma_uint64 readFrames(float* output, ma_uint32 requestedFrames) {
        if (!active.load(std::memory_order_acquire) || !pcmData || frameCount == 0) return 0;
        float vol = volume * MUSIC_MASTER_VOLUME_099.load(std::memory_order_relaxed);
        ma_uint32 filled = 0;
        while (filled < requestedFrames) {
            ma_uint64 remaining = frameCount - readPos;
            if (remaining == 0) {
                if (looping) { readPos = 0; remaining = frameCount; }
                else { active.store(false, std::memory_order_release); break; }
            }
            ma_uint32 toRead = (ma_uint32)std::min<ma_uint64>(remaining, requestedFrames - filled);
            float* src = pcmData + (readPos * CHANNEL_COUNT);
            float* dst = output + (filled * CHANNEL_COUNT);
            int samples = (int)(toRead * CHANNEL_COUNT);
            g_mix_func(dst, src, samples, vol);
            readPos += toRead; filled += toRead;
        }
        return filled;
    }
private:
    void moveFrom(BackgroundTrack&& other) noexcept {
        pcmData = other.pcmData; frameCount = other.frameCount;
        readPos = other.readPos; volume = other.volume;
        active.store(other.active.load(std::memory_order_relaxed), std::memory_order_relaxed);
        looping = other.looping; filePath = std::move(other.filePath);
        other.pcmData = nullptr; other.frameCount = 0; other.readPos = 0;
        other.active.store(false, std::memory_order_relaxed);
    }
};

// ==========================================================================
//  SoundEffectInstance / SoundEffectPool
// ==========================================================================
struct SoundEffectInstance {
    float* pcmData = nullptr;
    ma_uint64 frameCount = 0;
    ma_uint64 playbackPosition = 0;
    double volume = 1.0f;
    std::atomic<bool> playing{false};
    std::atomic<ma_uint64> startFrame{0};

    SoundEffectInstance() = default;
    SoundEffectInstance(float* data, ma_uint64 frames, double vol = 1.0f)
        : pcmData(data), frameCount(frames), playbackPosition(0), volume(vol), playing(true), startFrame(0) {}
    SoundEffectInstance(SoundEffectInstance&& other) noexcept
        : pcmData(other.pcmData), frameCount(other.frameCount), playbackPosition(other.playbackPosition),
          volume(other.volume), playing(other.playing.load(std::memory_order_relaxed)),
          startFrame(other.startFrame.load(std::memory_order_relaxed)) {
        other.pcmData = nullptr; other.frameCount = 0; other.playbackPosition = 0;
        other.volume = 1.0f; other.playing.store(false, std::memory_order_relaxed); other.startFrame.store(0, std::memory_order_relaxed);
    }
    SoundEffectInstance& operator=(SoundEffectInstance&& other) noexcept {
        if (this != &other) {
            pcmData = other.pcmData; frameCount = other.frameCount; playbackPosition = other.playbackPosition; volume = other.volume;
            playing.store(other.playing.load(std::memory_order_relaxed), std::memory_order_relaxed);
            startFrame.store(other.startFrame.load(std::memory_order_relaxed), std::memory_order_relaxed);
            other.pcmData = nullptr; other.frameCount = 0; other.playbackPosition = 0;
            other.volume = 1.0f; other.playing.store(false, std::memory_order_relaxed); other.startFrame.store(0, std::memory_order_relaxed);
        }
        return *this;
    }
    SoundEffectInstance(const SoundEffectInstance&) = delete;
    SoundEffectInstance& operator=(const SoundEffectInstance&) = delete;

    ma_uint64 readFrames(float* output, ma_uint32 requestedFrames, ma_uint64 bufStartFrame, double masterVol) {
        if (!playing.load(std::memory_order_acquire) || !pcmData) return 0;
        long long offset = (long long)startFrame.load(std::memory_order_relaxed) - (long long)bufStartFrame;
        if (offset >= (long long)requestedFrames) return 0;
        if (offset < 0) offset = 0;
        playbackPosition += (ma_uint64)offset;
        ma_uint64 remaining = frameCount - playbackPosition;
        if (remaining == 0) { playing.store(false, std::memory_order_release); return 0; }
        ma_uint32 toRead = (ma_uint32)std::min<ma_uint64>(remaining, (ma_uint64)(requestedFrames - offset));
        float* src = pcmData + (playbackPosition * CHANNEL_COUNT);
        float* dst = output + (offset * CHANNEL_COUNT);
        float vol = (float)(volume * masterVol);
        g_mix_func(dst, src, (int)(toRead * CHANNEL_COUNT), vol);
        playbackPosition += toRead;
        if (playbackPosition >= frameCount) playing.store(false, std::memory_order_release);
        return toRead;
    }
    bool isPlaying() const { return playing.load(std::memory_order_acquire); }
};

class SoundEffectPool {
public:
    SoundEffectPool() = default;
    ~SoundEffectPool() { cleanup(); }
    SoundEffectPool(const SoundEffectPool&) = delete;
    SoundEffectPool& operator=(const SoundEffectPool&) = delete;
    SoundEffectPool(SoundEffectPool&& other) noexcept { moveFrom(std::move(other)); }
    SoundEffectPool& operator=(SoundEffectPool&& other) noexcept {
        if (this != &other) { cleanup(); moveFrom(std::move(other)); }
        return *this;
    }
    void cleanup() {
        if (pcmData) { free(pcmData); pcmData = nullptr; }
        frameCount = 0; name.clear(); instances.clear();
    }
    bool load(const char* path) {
        cleanup();
        ma_decoder decoder;
        ma_decoder_config cfg = ma_decoder_config_init(SAMPLE_FORMAT, CHANNEL_COUNT, SAMPLE_RATE);
        if (ma_decoder_init_file(path, &cfg, &decoder) != MA_SUCCESS) { printf("Failed to load sound effect: %s\n", path); return false; }
        ma_uint64 length = 0;
        ma_decoder_get_length_in_pcm_frames(&decoder, &length);
        if (length == 0) { ma_decoder_uninit(&decoder); printf("Sound effect has zero length: %s\n", path); return false; }
        pcmData = (float*)malloc(sizeof(float) * length * CHANNEL_COUNT);
        if (!pcmData) { ma_decoder_uninit(&decoder); printf("Failed to allocate memory for sound effect: %s\n", path); return false; }
        ma_uint64 framesRead = 0;
        ma_decoder_read_pcm_frames(&decoder, pcmData, length, &framesRead);
        ma_decoder_uninit(&decoder);
        if (framesRead == 0) { cleanup(); printf("Failed to read sound effect: %s\n", path); return false; }
        frameCount = framesRead; name = path;
        instances.reserve(MAX_INSTANCES);
        return true;
    }
    void play(double volume = 1.0f, ma_uint64 startFrame = 0) {
        if (!pcmData || frameCount == 0) return;
        for (auto& inst : instances) {
            if (!inst.isPlaying()) {
                inst.playbackPosition = 0; inst.volume = volume;
                inst.startFrame.store(startFrame, std::memory_order_release);
                inst.playing.store(true, std::memory_order_release);
                ++playingCount; return;
            }
        }
        if (instances.size() < MAX_INSTANCES) {
            SoundEffectInstance inst(pcmData, frameCount, volume);
            inst.startFrame.store(startFrame, std::memory_order_relaxed);
            instances.push_back(std::move(inst));
            ++playingCount;
        }
    }
    ma_uint64 readFrames(float* output, ma_uint32 requestedFrames, ma_uint64 bufStartFrame, double masterVol) {
        if (playingCount == 0) return 0;
        ma_uint64 maxRead = 0;
        int stillPlaying = 0;
        for (auto& inst : instances) {
            if (inst.isPlaying()) {
                ma_uint64 r = inst.readFrames(output, requestedFrames, bufStartFrame, masterVol);
                if (r > maxRead) maxRead = r;
                if (inst.isPlaying()) ++stillPlaying;
            }
        }
        playingCount = stillPlaying;
        return maxRead;
    }
    bool isAnyPlaying() const { return playingCount > 0; }
    void stopAll() {
        for (auto& i : instances) {
            i.playing.store(false, std::memory_order_release);
            i.playbackPosition = 0;
            i.startFrame.store(0, std::memory_order_release);
        }
        playingCount = 0;
    }
    int getPlayingCount() const { return playingCount; }
private:
    static const int MAX_INSTANCES = 32;
    float* pcmData = nullptr;
    ma_uint64 frameCount = 0;
    int playingCount = 0;
    std::string name;
    std::vector<SoundEffectInstance> instances;
    void moveFrom(SoundEffectPool&& other) noexcept {
        pcmData = other.pcmData; frameCount = other.frameCount;
        playingCount = other.playingCount;
        name = std::move(other.name); instances = std::move(other.instances);
        other.pcmData = nullptr; other.frameCount = 0; other.playingCount = 0;
    }
};

// ==========================================================================
//  AudioMixerManager
// ==========================================================================
class AudioMixerManager {
public:
    AudioMixerManager() = default;
    ~AudioMixerManager() { destroy(); }
    // The mixer device's anchor-tone phase (see the SURROUND_ANCHOR_
    // constants; the AudioSystem device has its own per-stream phases).
    std::atomic<float> anchorPhase{SURROUND_ANCHOR_PHASE0};
    /**
        Same wedged-device discipline as AudioSystem: the sfx/background
        device is heap-allocated, lifecycle calls run under the watchdog,
        and a timed-out device is parked (leaked) instead of hanging the
        process — this is the second half of the close deadlock.
    */
    bool initialize() {
        if (deviceInitialized) return true;
        // Surround-aware channel count: with the game's surround setting
        // on, the mixer device opens with the same 8-channel map as the
        // AudioSystem device, so menu music + SFX also fill the room (and
        // keep filling it across device switches). Falls back to stereo
        // when the device rejects the layout.
        const int wantedChannels = g_maThingSurround.load(std::memory_order_acquire) ? SURROUND_CHANNEL_COUNT : CHANNEL_COUNT;
        device = new ma_device();
        memset(device, 0, sizeof(ma_device));
        ma_device_config cfg = ma_device_config_init(ma_device_type_playback);
        cfg.playback.format = SAMPLE_FORMAT;
        cfg.playback.channels = wantedChannels;
        ma_thing_set_channel_map(&cfg, wantedChannels);
        cfg.sampleRate = SAMPLE_RATE;
        cfg.periodSizeInFrames = PERIOD_SIZE;
        cfg.dataCallback = audioCallback;
        cfg.notificationCallback = onMixerDeviceNotification;
        cfg.pUserData = this;
        // Same reasoning as AudioSystem::buildDevice: we own recovery via
        // the pump; miniaudio's notification-thread auto reroute collides
        // with it and rebuilds converters from a guessed channel map.
        cfg.wasapi.noAutoStreamRouting = MA_TRUE;
        // Watchdogged init (same discipline as AudioSystem::buildDevice):
        // during a default-device switch the COM endpoint open can block,
        // and THIS device is the only one alive in the menus — a hang here
        // freezes the whole game with no audio running at all.
        int initRes = ma_device_init_watchdog(device, &cfg, lifecycleStuck, 1500);
        int openedChannels = wantedChannels;
        if (initRes > 0 && wantedChannels != CHANNEL_COUNT) {
            // Clean failure with surround: free the storage and retry stereo.
            delete device;
            device = new ma_device();
            memset(device, 0, sizeof(ma_device));
            cfg.playback.channels = CHANNEL_COUNT;
            ma_thing_set_channel_map(&cfg, CHANNEL_COUNT);
            initRes = ma_device_init_watchdog(device, &cfg, lifecycleStuck, 1500);
            if (initRes > 0) {
                openedChannels = CHANNEL_COUNT;
                printf("[ma_thing] mixer surround unavailable — falling back to stereo\n");
            }
        }
        if (initRes < 0) {
            // Timed out: leak the storage (a detached helper thread may
            // still be inside ma_device_init on it). deviceInitialized
            // stays false so the pump's retry path rebuilds fresh.
            deviceGraveyard.push_back(device);
            device = nullptr;
            lifecycleStuck.store(false, std::memory_order_release);
            printf("[ma_thing] mixer device init timed out — retrying next pump\n");
            return false;
        }
        if (initRes == 0) {
            printf("Failed to initialize audio mixer device\n");
            delete device;
            device = nullptr;
            return false;
        }
        playbackChannels.store(openedChannels, std::memory_order_release);
        deviceInitialized = true;
        startDeviceWatchdog();
        return true;
    }
    void destroy() {
        if (deviceInitialized && device) {
            if (stopDeviceWatchdog() && uninitDeviceWatchdog()) {
                delete device;
            } else {
                deviceGraveyard.push_back(device); // wedged — park it
            }
            device = nullptr;
            deviceInitialized = false;
        }
        playbackChannels.store(CHANNEL_COUNT, std::memory_order_release);
        backgroundTracks.clear(); soundEffectPools.clear();
        backgroundTrackMap.clear(); soundEffectMap.clear();
        outFramesTotal.store(0, std::memory_order_relaxed);
        lastAnchorFrame.store(0, std::memory_order_relaxed);
        lastAnchorTime.store(0, std::memory_order_relaxed);
        for (int b = 0; b < 3; b++) { bgSnapshot[b].clear(); sfxSnapshot[b].clear(); }
        lifecycleStuck.store(false, std::memory_order_release);
    }
    int loadBackgroundTrack(const char* path) {
        if (!deviceInitialized && !initialize()) return -1;
        std::string key = path;
        auto it = backgroundTrackMap.find(key);
        if (it != backgroundTrackMap.end()) return it->second;
        BackgroundTrack track;
        if (!track.load(path)) return -1;
        int idx = (int)backgroundTracks.size();
        backgroundTracks.push_back(std::move(track));
        backgroundTrackMap[key] = idx;
        publishSnapshot();
        return idx;
    }
    int findBackgroundTrack(const char* path) {
        auto it = backgroundTrackMap.find(std::string(path));
        return (it != backgroundTrackMap.end()) ? it->second : -1;
    }
    bool isBackgroundTrackLoaded(const char* path) { return findBackgroundTrack(path) >= 0; }
    void playBackgroundTrack(int idx) { if (inRange(idx, backgroundTracks)) backgroundTracks[idx].play(); }
    void stopBackgroundTrack(int idx) { if (inRange(idx, backgroundTracks)) backgroundTracks[idx].stop(); }
    void setBackgroundTrackVolume(int idx, float v) { if (inRange(idx, backgroundTracks)) backgroundTracks[idx].setVolume(v); }
    void setBackgroundTrackLooping(int idx, bool lp) { if (inRange(idx, backgroundTracks)) backgroundTracks[idx].setLooping(lp); }
    bool isBackgroundTrackPlaying(int idx) { return inRange(idx, backgroundTracks) && backgroundTracks[idx].active.load(std::memory_order_acquire); }
    
    int loadSoundEffect(const char* path) {
        if (!deviceInitialized && !initialize()) return -1;
        std::string key = path;
        auto it = soundEffectMap.find(key);
        if (it != soundEffectMap.end()) return it->second;
        SoundEffectPool pool;
        if (!pool.load(path)) return -1;
        int idx = (int)soundEffectPools.size();
        soundEffectPools.push_back(std::move(pool));
        soundEffectMap[key] = idx;
        publishSnapshot();
        return idx;
    }
    int findSoundEffect(const char* path) {
        auto it = soundEffectMap.find(std::string(path));
        return (it != soundEffectMap.end()) ? it->second : -1;
    }
    bool isSoundEffectLoaded(const char* path) { return findSoundEffect(path) >= 0; }
    void playSoundEffect(int idx, double volume = 1.0f) {
        if (!inRange(idx, soundEffectPools)) return;
        ma_uint64 startFrame = 0;
        long long anchorTime = lastAnchorTime.load(std::memory_order_relaxed);
        if (anchorTime != 0) {
            long long nowNs = std::chrono::steady_clock::now().time_since_epoch().count();
            long long dtNs = nowNs - anchorTime;
            ma_uint64 anchorFrame = lastAnchorFrame.load(std::memory_order_relaxed);
            if (dtNs > 0) startFrame = anchorFrame + (ma_uint64)((double)dtNs * (SAMPLE_RATE / 1000000000.0));
            else startFrame = anchorFrame;
        } else {
            startFrame = outFramesTotal.load(std::memory_order_relaxed);
        }
        soundEffectPools[idx].play(volume, startFrame);
    }
    void playSoundEffect(const char* path, double volume = 1.0f) {
        int idx = findSoundEffect(path);
        if (idx < 0) idx = loadSoundEffect(path);
        if (idx >= 0) playSoundEffect(idx, volume);
    }
    void stopSoundEffect(int idx) { if (inRange(idx, soundEffectPools)) soundEffectPools[idx].stopAll(); }
    bool isSoundEffectPlaying(int idx) { return inRange(idx, soundEffectPools) && soundEffectPools[idx].isAnyPlaying(); }
    int getSoundEffectPlayingCount(int idx) { return inRange(idx, soundEffectPools) ? soundEffectPools[idx].getPlayingCount() : 0; }
    void unloadBackgroundTrack(int idx) {
        if (!inRange(idx, backgroundTracks)) return;
        eraseAndFixup(backgroundTrackMap, idx);
        backgroundTracks.erase(backgroundTracks.begin() + idx);
        publishSnapshot();
    }
    void unloadSoundEffect(int idx) {
        if (!inRange(idx, soundEffectPools)) return;
        eraseAndFixup(soundEffectMap, idx);
        soundEffectPools.erase(soundEffectPools.begin() + idx);
        publishSnapshot();
    }
    double setMasterVolume(double v) { MUSIC_MASTER_VOLUME_099.store(v, std::memory_order_relaxed); return v; }
    double getMasterVolume() const { return MUSIC_MASTER_VOLUME_099.load(std::memory_order_relaxed); }

    /**
        Device-loss pump for the mixer's own device — the same contract as
        AudioSystem::pumpDeviceRecovery. The mixer device runs the menu
        music and SFX (it is the ONLY device alive while sitting in the
        menus), so losing the default device there must recover too.
        Returns true when a rebuild attempt was made.
    **/
    bool pumpDeviceRecovery() {
        if (!deviceInitialized) return false;
        if (device == nullptr) {                // wedged earlier — retry periodically
            if (++lostTicks >= MIXER_LOST_GRACE_TICKS) {
                lostTicks = 0;
                printf("[ma_thing] mixer device lost — retrying\n");
                deviceInitialized = false;
                initialize();
                return true;
            }
            return false;
        }
        if (!ma_device_is_started(device)) {
            if (++lostTicks >= MIXER_LOST_GRACE_TICKS) {
                lostTicks = 0;
                printf("[ma_thing] mixer device lost — rebuilding\n");
                if (stopDeviceWatchdog() && uninitDeviceWatchdog()) {
                    delete device;
                } else {
                    deviceGraveyard.push_back(device);
                    lifecycleStuck.store(false, std::memory_order_release);
                }
                device = nullptr;
                deviceInitialized = false;
                initialize();
                return true;
            }
        } else {
            lostTicks = 0;
        }
        return false;
    }

    /**
        Notification callback for the mixer device — flags only, NEVER a
        call back into the device (miniaudio's own device-change thread
        invoking ma_device_* here is the documented deadlock). The mixer
        pump keys off ma_device_is_started, not these flags; this exists
        so an external stop (unplug / default switch) leaves a diagnostic
        breadcrumb and so behavior matches the AudioSystem device.
    **/
    static void onMixerDeviceNotification(const ma_device_notification* pNotification) {
        AudioMixerManager* mixer = static_cast<AudioMixerManager*>(pNotification->pDevice->pUserData);
        if (!mixer) return;
        switch (pNotification->type) {
        case ma_device_notification_type_started:
            printf("[ma_thing] mixer device started\n");
            break;
        case ma_device_notification_type_stopped:
            if (!mixer->stoppingSelf.load(std::memory_order_acquire))
                printf("[ma_thing] mixer device stopped externally (device switched?)\n");
            break;
        default:
            break;
        }
    }
    /** Mixer grace window — mirrors AudioSystem::DEVICE_LOST_GRACE_TICKS. */
    static constexpr int MIXER_LOST_GRACE_TICKS = 300;

private:
    std::deque<BackgroundTrack> backgroundTracks;
    std::deque<SoundEffectPool> soundEffectPools;
    std::unordered_map<std::string, int> backgroundTrackMap;
    std::unordered_map<std::string, int> soundEffectMap;
    ma_device* device = nullptr;                 // heap — see initialize()
    std::vector<ma_device*> deviceGraveyard;     // wedged devices, leaked on purpose
    bool deviceInitialized = false;
    /** The layout the mixer device actually opened with — the callback
        mixes against this (2 = plain stereo, 8 = full surround map). */
    std::atomic<int> playbackChannels{CHANNEL_COUNT};
    std::atomic<bool> lifecycleStuck{false};
    std::atomic<bool> stoppingSelf{false};
    int lostTicks = 0;                           // pump-only (main thread)

    bool stopDeviceWatchdog() {
        if (!device || !ma_device_is_started(device)) return true;
        stoppingSelf.store(true, std::memory_order_release);
        bool ok = ma_device_lifecycle_watchdog([this]() { ma_device_stop(device); }, lifecycleStuck, 1500);
        stoppingSelf.store(false, std::memory_order_release);
        return ok;
    }
    bool uninitDeviceWatchdog() {
        return ma_device_lifecycle_watchdog([this]() { ma_device_uninit(device); }, lifecycleStuck, 1500);
    }
    bool startDeviceWatchdog() {
        auto res = std::make_shared<ma_result>(MA_ERROR);
        bool ok = ma_device_lifecycle_watchdog([this, res]() { *res = ma_device_start(device); }, lifecycleStuck, 1500);
        return ok && *res == MA_SUCCESS;
    }
    std::atomic<ma_uint64> outFramesTotal{0};
    std::atomic<ma_uint64> lastAnchorFrame{0};
    std::atomic<long long> lastAnchorTime{0};
    std::vector<BackgroundTrack*> bgSnapshot[3];
    std::vector<SoundEffectPool*> sfxSnapshot[3];
    std::atomic<int> readerIndex{0};
    std::atomic<int> newestIndex{1};

    void publishSnapshot() {
        int r = readerIndex.load(std::memory_order_acquire);
        int n = newestIndex.load(std::memory_order_acquire);
        int next = (r == n) ? (r + 1) % 3 : 3 - r - n;
        bgSnapshot[next].clear();
        for (auto& t : backgroundTracks) bgSnapshot[next].push_back(&t);
        sfxSnapshot[next].clear();
        for (auto& p : soundEffectPools) sfxSnapshot[next].push_back(&p);
        newestIndex.store(next, std::memory_order_release);
    }
    template<typename Vec>
    static bool inRange(int idx, const Vec& v) { return idx >= 0 && idx < (int)v.size(); }
    static void eraseAndFixup(std::unordered_map<std::string, int>& map, int removed) {
        for (auto it = map.begin(); it != map.end(); ) {
            if (it->second == removed) it = map.erase(it);
            else { if (it->second > removed) --it->second; ++it; }
        }
    }
    static void audioCallback(ma_device* pDevice, void* pOutput, const void* pInput, ma_uint32 frameCount) {
        AudioMixerManager* mixer = static_cast<AudioMixerManager*>(pDevice->pUserData);
        if (!mixer) return;
        float* out = (float*)pOutput;
        const int outCh = mixer->playbackChannels.load(std::memory_order_relaxed);
        memset(out, 0, sizeof(float) * frameCount * outCh);
        // The tracks/SFX are stereo; when the device runs the 8-channel
        // map the bed stays strictly on the mains FL/FR and the four rear
        // channels carry the shared anchor tone only (the v3.9.0 room
        // discipline — same as the AudioSystem song routing). A plain
        // stereo mix scratch buffer keeps readFrames() unchanged.
        float stage[512 * CHANNEL_COUNT];
        ma_uint64 bufStart = mixer->outFramesTotal.fetch_add(frameCount, std::memory_order_relaxed);
        mixer->lastAnchorFrame.store(bufStart, std::memory_order_relaxed);
        mixer->lastAnchorTime.store(std::chrono::steady_clock::now().time_since_epoch().count(), std::memory_order_relaxed);
        double masterVol = MUSIC_MASTER_VOLUME_099.load(std::memory_order_relaxed);
        int r = mixer->readerIndex.load(std::memory_order_relaxed);
        int n = mixer->newestIndex.load(std::memory_order_acquire);
        if (r != n) { mixer->readerIndex.store(n, std::memory_order_release); r = n; }
        if (outCh == SURROUND_CHANNEL_COUNT) {
            // Chunk through the stereo stage so the fixed scratch buffer
            // covers any period size.
            ma_uint32 done = 0;
            while (done < frameCount) {
                const ma_uint32 chunk = (frameCount - done > 512) ? 512 : frameCount - done;
                memset(stage, 0, sizeof(float) * chunk * CHANNEL_COUNT);
                for (BackgroundTrack* track : mixer->bgSnapshot[r])
                    if (track->active.load(std::memory_order_acquire)) track->readFrames(stage, chunk);
                for (SoundEffectPool* pool : mixer->sfxSnapshot[r])
                    pool->readFrames(stage, chunk, bufStart + done, masterVol);
                // v3.9.0 spread: the music/SFX bed stays strictly on the
                // mains FL/FR (menu music too never touches the room); the
                // rears carry only the shared anchor tone.
                for (ma_uint32 f = 0; f < chunk; f++) {
                    float sl = stage[f * 2], sr = stage[f * 2 + 1];
                    float* d = out + (size_t)(done + f) * outCh;
                    d[0] += sl; d[1] += sr;
                    const float tone = SURROUND_ANCHOR_AMP
                        * (SURROUND_ANCHOR_BIAS + SURROUND_ANCHOR_SPAN
                           * sinf(mixer->anchorPhase.load(std::memory_order_relaxed)));
                    d[4] += tone; d[5] += tone; d[6] += tone; d[7] += tone;
                    float ph = mixer->anchorPhase.load(std::memory_order_relaxed)
                        + (float)(2.0 * 3.14159265358979323846 * SURROUND_ANCHOR_HZ / SAMPLE_RATE);
                    if (ph > 6.2831855f) ph -= 6.2831855f;  // wrap: see rearAnchor
                    mixer->anchorPhase.store(ph, std::memory_order_relaxed);
                }
                done += chunk;
            }
        } else {
            for (BackgroundTrack* track : mixer->bgSnapshot[r])
                if (track->active.load(std::memory_order_acquire)) track->readFrames(out, frameCount);
            for (SoundEffectPool* pool : mixer->sfxSnapshot[r])
                pool->readFrames(out, frameCount, bufStart, masterVol);
        }
        (void)pInput;
    }
};
// Standalone verification for the v3.9.0 surround room discipline:
//   1. The anchor tone (20 Hz, amplitude 0.001) NEVER produces a zero
//      sample: |sin| at the sampled phases stays strictly > 0 over an
//      arbitrarily long run (millions of frames), and the phase itself
//      never lands exactly on a multiple of pi.
//   2. Routing discipline: BACKGROUND writes FL/FR/LFE only (+ anchor),
//      CENTER writes C/LFE only (+ anchor), SUB writes LFE only (+
//      anchor) — and NO route ever writes song content into
//      BL/BR/SL/SR (the four rears carry the anchor tone alone).
//   3. The tone is inaudible in level: every rear sample |v| <= 0.001.
// Not part of the game build. Excerpts the real routing bodies.
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <cstring>

static int failures = 0;
#define CHECK(cond) do { \
    if (!(cond)) { printf("FAIL %s:%d  %s\n", __FILE__, __LINE__, #cond); ++failures; } \
} while (0)

#define SURROUND_CHANNEL_COUNT 8
#define SAMPLE_RATE 48000.0
#define SURROUND_ANCHOR_HZ      20.0f
#define SURROUND_ANCHOR_AMP     0.001f
#define SURROUND_ANCHOR_PHASE0  0.261799f

int main() {
    // ---- 1. the tone never samples zero — the min-biased construction,
    // evaluated in FLOAT (the engine's arithmetic mode, where sinf(-1.0f
    // exact) is what broke the earlier amp+amp*sin form) ----
    float phase = SURROUND_ANCHOR_PHASE0;
    float minVal = 1e9f;
    const long long N = 48000LL * 600;  // ten minutes of frames
    const float STEP = (float)(2.0 * 3.14159265358979323846 * SURROUND_ANCHOR_HZ / SAMPLE_RATE);
    for (long long i = 0; i < N; ++i) {
        float s = SURROUND_ANCHOR_AMP
            * (0.5f + 0.49f * sinf(phase));
        if (s < minVal) minVal = s;
        if (s <= 0.0f) { printf("FAIL non-positive sample at frame %lld\n", i); failures++; break; }
        phase += STEP;
        if (phase > 6.2831855f) phase -= 6.2831855f;  // wrapped like the engine
    }
    printf("min sample over 600s of the min-biased 20Hz tone (float): %.9f (amp 0.001)\n", minVal);
    CHECK(minVal > 0.0f);
    // The proof the bias is REQUIRED: the amp+amp*sin form in float hits
    // exact 0.0f (sinf returns -1.0f exactly over the orbit).
    float phase2 = SURROUND_ANCHOR_PHASE0;
    float minOld = 1e9f;
    for (long long i = 0; i < N; ++i) {
        float s = SURROUND_ANCHOR_AMP + SURROUND_ANCHOR_AMP * sinf(phase2);
        if (s < minOld) minOld = s;
        phase2 += STEP;
        if (phase2 > 6.2831855f) phase2 -= 6.2831855f;
    }
    printf("amp+amp*sin form min over the same orbit: %.9f (the form this caught)\n", minOld);
    CHECK(minOld <= 1.0f);  // observed ~0: the old form provably fails

    // ---- 2. routing discipline (the real bodies, one frame each) ----
    // stage: a loud stereo pair to prove nothing leaks into the rears
    float stage[2] = {0.9f, 0.85f};
    float lpf = 0.0f;
    const float SURROUND_LPF_COEF = 0.016951f;
    const float SURROUND_LFE_BASS_GAIN = 0.75f;
    const float SURROUND_LFE_FULL_GAIN = 1.0f;

    // BACKGROUND (the inst route)
    {
        float d[8] = {0, 0, 0, 0, 0, 0, 0, 0};
        float sl = stage[0], sr = stage[1];
        float mono = (sl + sr) * 0.5f;
        lpf += SURROUND_LPF_COEF * (mono - lpf);
        d[0] += sl; d[1] += sr;
        d[3] += lpf * SURROUND_LFE_BASS_GAIN;
        float anchorPhase = SURROUND_ANCHOR_PHASE0;
        float tone = SURROUND_ANCHOR_AMP * (0.5f + 0.49f * sinf(anchorPhase));
        d[4] += tone; d[5] += tone; d[6] += tone; d[7] += tone;
        CHECK(fabsf(d[0] - 0.9f) < 1e-6);           // FL = inst L
        CHECK(fabsf(d[1] - 0.85f) < 1e-6);          // FR = inst R
        CHECK(d[3] > 0.0f);                          // LFE got the bass fill
        CHECK(d[2] == 0.0f);                         // center untouched
        for (int c = 4; c < 8; ++c) {
            CHECK(fabsf(d[c]) <= 2 * SURROUND_ANCHOR_AMP + 1e-9); // anchor only
            CHECK(fabsf(d[c]) > 0.0f);                // and never zero
        }
    }

    // CENTER (the vocals route)
    {
        float d[8] = {0, 0, 0, 0, 0, 0, 0, 0};
        float sl = stage[0], sr = stage[1];
        float mono = (sl + sr) * 0.5f;
        lpf = 0.0f;
        lpf += SURROUND_LPF_COEF * (mono - lpf);
        d[2] += mono;
        d[3] += lpf * SURROUND_LFE_BASS_GAIN;
        float tone = SURROUND_ANCHOR_AMP * (0.5f + 0.49f * sinf(SURROUND_ANCHOR_PHASE0));
        d[4] += tone; d[5] += tone; d[6] += tone; d[7] += tone;
        CHECK(fabsf(d[2] - 0.875f) < 1e-6);          // C = vocal mono
        CHECK(d[0] == 0.0f && d[1] == 0.0f);         // mains untouched
        for (int c = 4; c < 8; ++c) {
            CHECK(fabsf(d[c]) <= 2 * SURROUND_ANCHOR_AMP + 1e-9);
            CHECK(fabsf(d[c]) > 0.0f);
        }
    }

    // SUB
    {
        float d[8] = {0, 0, 0, 0, 0, 0, 0, 0};
        float sl = stage[0], sr = stage[1];
        float mono = (sl + sr) * 0.5f;
        lpf = 0.0f;
        lpf += SURROUND_LPF_COEF * (mono - lpf);
        d[3] += lpf * SURROUND_LFE_FULL_GAIN;
        CHECK(d[3] > 0.0f);
        CHECK(d[0] == 0.0f && d[1] == 0.0f && d[2] == 0.0f);
    }

    if (failures == 0) printf("SURROUND ANCHOR TEST: all checks passed\n");
    return failures == 0 ? 0 : 1;
}

// Standalone verification for the v3.7 mirror API, driven through the
// SAME core_* wrappers the Haxe externs call (the full stack minus the
// FFI binding itself):
//   - mirrorNotes flips ONLY the 10-bit column index; position,
//     duration, type, lane are untouched
//   - the flip is an INVOLUTION: two commits = the original fields
//   - id stability: ids never move across a mirror (the store orders
//     by position only) — the selection survives untouched
//   - staging semantics: ranges are not normalized; a double-staged id
//     flips twice = back to its original column (harmless)
//   - undo/redo replay semantics: the SAME call on the SAME ranges
//     restores the selection exactly
//   - the axis pair: selection-bounds inversion (1..4 flips 1<->4,
//     2<->3), the whole-mania flip, a one-column selection (fixed
//     point), out-of-order axis args (swapped), out-of-range clamps
// Not part of the game build.
#include "chart_file_core.cpp"
#include <cassert>
#include <cstdio>

static int failures = 0;
#define CHECK(cond) do { \
    if (!(cond)) { printf("FAIL %s:%d  %s\n", __FILE__, __LINE__, #cond); ++failures; } \
} while (0)

static uint32_t idxOf(int64_t id) {
    return ((uint32_t)core_getNote_last4(id) >> 8) & 0x3FF;
}

static void resetChart() {
    core_destroyChart();
    core_createChart("/tmp/mirror_v37_test.fvc");
}

int main() {
    resetChart();

    // 8 notes, columns 0..7 (an 8K mania's worth), all distinct
    // positions so ids are stable and predictable (ascending).
    const int N = 8;
    for (int i = 0; i < N; ++i)
        core_addNote(1000000LL * (i + 1), i * 3, i, i % 2, i % 2);

    // --- 1. The flip touches ONLY the index field ---
    {
        struct Snap { uint64_t f8; int l4; };
        Snap before[8];
        for (int i = 0; i < N; ++i) {
            before[i].f8 = (uint64_t)core_getNote_first8(i);
            before[i].l4 = (int)core_getNote_last4(i);
        }
        core_stageMirrorRange(0, N - 1);
        const int32_t flipped = core_mirrorNotesFromSelectionRanges(0, N - 1);
        CHECK(flipped == N);
        for (int i = 0; i < N; ++i) {
            CHECK((uint64_t)core_getNote_first8(i) == before[i].f8);   // position + duration untouched
            const uint32_t got = (uint32_t)core_getNote_last4(i);
            const uint32_t want = (uint32_t)before[i].l4;
            CHECK((got & ~(0x3FFu << 8)) == (want & ~(0x3FFu << 8))); // type + lane bits untouched
            CHECK(idxOf(i) == 7u - (uint32_t)i);                       // 0<->7, 1<->6 ... axis 0..7
        }
        // Two commits = the original: the involution.
        core_stageMirrorRange(0, N - 1);
        CHECK(core_mirrorNotesFromSelectionRanges(0, N - 1) == N);
        for (int i = 0; i < N; ++i) {
            CHECK((uint32_t)core_getNote_last4(i) == (uint32_t)before[i].l4);
            CHECK(idxOf(i) == (uint32_t)i);
        }
        // Ids never moved: the store orders by position only, so the
        // id set of the (unchanged) selection still reads back in the
        // same ascending order with the same fields.
    }

    // --- 2. Selection-bounds axis: columns 1..4 flip 1<->4, 2<->3 ---
    // Columns [3, 1, 4, 2] on ids 0..3 (id order != column order —
    // the axis is read off the NOTES, not the ids).
    {
        resetChart();
        const int cols[4] = {3, 1, 4, 2};
        for (int i = 0; i < 4; ++i)
            core_addNote(1000000LL * (i + 1), 10, cols[i], 0, 1);
        core_stageMirrorRange(0, 3);
        CHECK(core_mirrorNotesFromSelectionRanges(1, 4) == 4); // axis pair 1..4
        CHECK(idxOf(0) == 2);   // 3 -> 1+4-3 = 2
        CHECK(idxOf(1) == 4);   // 1 -> 1+4-1 = 4
        CHECK(idxOf(2) == 1);   // 4 -> 1+4-4 = 1
        CHECK(idxOf(3) == 3);   // 2 -> 1+4-2 = 3
    }

    // --- 3. A one-column selection is a fixed point (lo == hi) ---
    {
        resetChart();
        core_addNote(1000000LL, 10, 5, 0, 0);
        core_stageMirrorRange(0, 0);
        core_mirrorNotesFromSelectionRanges(5, 5);
        CHECK(idxOf(0) == 5);
    }

    // --- 4. Swapped axis args are normalized (5,0) == (0,5) ---
    {
        resetChart();
        core_addNote(1000000LL, 10, 2, 0, 0);
        core_stageMirrorRange(0, 0);
        core_mirrorNotesFromSelectionRanges(5, 0); // swapped — the commit swaps to (0,5)
        CHECK(idxOf(0) == 3); // 0+5-2 = 3
    }

    // --- 5. Out-of-range staging clamps to the live store size ---
    {
        resetChart();
        for (int i = 0; i < 3; ++i)
            core_addNote(1000000LL * (i + 1), 10, i, 0, 0);
        core_stageMirrorRange(0, 100); // way past the end
        CHECK(core_mirrorNotesFromSelectionRanges(0, 2) == 3);
        CHECK(idxOf(0) == 2 && idxOf(1) == 1 && idxOf(2) == 0);
    }

    // --- 6. Double-staged id flips twice = original (no normalize) ---
    {
        resetChart();
        core_addNote(1000000LL, 10, 1, 0, 0);
        core_stageMirrorRange(0, 0);
        core_stageMirrorRange(0, 0); // the same id staged twice
        core_mirrorNotesFromSelectionRanges(0, 3);
        CHECK(idxOf(0) == 1); // flipped twice — back to 1
    }

    // --- 7. Undo = the same replay restores a mirrored selection ---
    {
        resetChart();
        // A 4-column selection on ids 0..3, columns 0..3.
        for (int i = 0; i < 4; ++i)
            core_addNote(1000000LL * (i + 1), 10, 3 - i, 0, 0);
        uint32_t before[4];
        for (int i = 0; i < 4; ++i) before[i] = idxOf(i);
        // The gesture (kind-3 command: ranges + axis).
        core_stageMirrorRange(0, 3);
        CHECK(core_mirrorNotesFromSelectionRanges(0, 3) == 4);
        // The undo: THE SAME ranges, THE SAME axis.
        core_stageMirrorRange(0, 3);
        CHECK(core_mirrorNotesFromSelectionRanges(0, 3) == 4);
        for (int i = 0; i < 4; ++i)
            CHECK(idxOf(i) == before[i]);
        // And the redo after that: mirrored again.
        core_stageMirrorRange(0, 3);
        core_mirrorNotesFromSelectionRanges(0, 3);
        for (int i = 0; i < 4; ++i)
            CHECK(idxOf(i) == 3u - before[i]);
    }

    // --- 8. clearStaged drops the staged mirror ranges too ---
    {
        resetChart();
        core_addNote(1000000LL, 10, 1, 0, 0);
        core_stageMirrorRange(0, 0);
        core_clearStaged();
        CHECK(core_mirrorNotesFromSelectionRanges(0, 3) == 0); // nothing staged
        CHECK(idxOf(0) == 1);
    }

    core_destroyChart();
    if (failures == 0) printf("MIRROR TEST: all checks passed\n");
    else printf("MIRROR TEST: %d FAILURES\n", failures);
    return failures ? 1 : 0;
}

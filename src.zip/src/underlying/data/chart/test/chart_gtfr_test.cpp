// Standalone verification for the v3.9.0 GTFR protocol + arenas
// (chart_file_core.cpp). Not part of the game build.
//
//   1. The exactly-once loop: every note in [start,end) handed out once,
//      in chart order; NOTE and INDEX describe the same note; head
//      advances once per body no matter the call order.
//   2. Recycle semantics: RECYCLE frees the binding of that note's id
//      (idempotent — double recycle is a no-op).
//   3. Bind discipline: rebind updates in place; count tracks live
//      bindings; the arena capacity only grows (never shrinks).
//   4. The edit path: after add/remove (global index shifts), a fresh
//      window sweep leaves ZERO stale bindings — freeByGidx + rebind
//      re-derives the whole window from the iteration itself.
//   5. Packed-word round trips: every field survives pack→word reads.
#include "chart_file_core.cpp"
#include <cassert>
#include <cstdio>

static int failures = 0;
#define CHECK(cond) do { \
    if (!(cond)) { printf("FAIL %s:%d  %s\n", __FILE__, __LINE__, #cond); ++failures; } \
} while (0)

int gtfr_test() {
    ChartFileReader reader;   // fresh reader: fresh arenas
    // Direct store access for setup (the test harness pattern of the
    // other store tests).
    const int N = 200;
    for (int i = 0; i < N; ++i)
        reader.addNote((uint64_t)(100000 * i), (uint32_t)(i % 300),
                       (uint32_t)(i % 4), (uint32_t)(i % 2), (uint32_t)(i % 2));
    CHECK(reader.getLength() == N);

    // ---- 1. the exactly-once loop over [50, 150) ----
    reader.gtfrStart(50, 150);
    int seen = 0;
    int64_t prevId = -1;
    while (reader.gtfrProgress(50, 150)) {
        int64_t first8 = reader.gtfrNoteThenAdvance();
        int64_t id = reader.gtfrIndexThenAdvance();
        CHECK(id >= 50 && id < 150);
        CHECK(id > prevId || seen == 0);          // strictly ascending
        prevId = id;
        // NOTE's packed first8 decodes to the note AT that id.
        CHECK(((uint64_t)first8 & 0x0000FFFFFFFFFFFFULL) == (uint64_t)(100000 * id));
        reader.gtfrVirtualNoteRecycle();          // body's recycle (no-op yet)
        seen++;
    }
    CHECK(seen == 100);

    // ---- 2. bind + recycle round trips ----
    // Bind every note of the window once. The binds thread the column
    // chains; a chain is verified after the sweep.
    reader.gtfrFrameBegin();
    reader.gtfrStart(50, 150);
    while (reader.gtfrProgress(50, 150)) {
        int64_t first8 = reader.gtfrNoteThenAdvance();
        int64_t id = reader.gtfrIndexThenAdvance();
        (void)first8;
        reader.gtfrBindNote(id, /*diff*/ (int32_t)(id - 50), /*sx*/ (int32_t)(id * 3),
                            /*sy*/ (int32_t)(id * 7 - 12), 1.0f, 0.5f, 2.0f,
                            /*notesInOne*/ (int32_t)(id % 8), id % 5 == 0,
                            id % 3 == 0, id % 7 == 0, (int32_t)(id % 2));
        if (id % 4 == 0)   // every 4th note carries a sustain
            reader.gtfrBindSustain(id, (int32_t)(id - 50), (int32_t)(id * 3),
                                   (int32_t)(id * 7 - 12), 320, 300, 0.8f, 1.5f, 2.0f, 0.25f);
    }
    CHECK(reader.gtfrNotes.count == 100);
    CHECK(reader.gtfrSustains.count == 25);

    // Column chain check: column (lane 0, index 0). The notes were
    // seeded with index = i % 4 and lane = i % 2, so a note lands in
    // column (0, 0) iff lane == 0 AND index == 0 — i.e. i ≡ 0 mod 4
    // (index 0 requires i%4==0; those i are even so lane==0 holds).
    // In [50,150): 52, 56, ..., 148 → 25 notes.
    {
        int chainLen = 0;
        int32_t s = reader.gtfrColumnHead(0, 0);
        while (s >= 0) { chainLen++; s = reader.gtfrSlotNext(s); }
        CHECK(chainLen == 25);
    }
    // Chain order is bind order (chart order): first chain member is id 52.
    {
        int32_t s = reader.gtfrColumnHead(0, 0);
        CHECK(s >= 0);
        CHECK(reader.gtfrNotes.words[(size_t)s * 10 + 1] == 52);
    }

    // frameBegin clears the chains (bindings and free list untouched);
    // the phase-4 sweep below re-threads them.
    reader.gtfrFrameBegin();
    CHECK(reader.gtfrColumnHead(0, 0) == -1);
    CHECK(reader.gtfrNotes.count == 100);

    // Packed-word round trip on slot of id 77.
    {
        int64_t slot = reader.gtfrNotes.findGidx(77);
        CHECK(slot >= 0);
        const int64_t* w = &reader.gtfrNotes.words[(size_t)slot * 10];
        CHECK(w[1] == 77);
        int32_t diff = (int32_t)(uint32_t)w[0];
        CHECK(diff == 77 - 50);
        int32_t sx = (int32_t)((uint64_t)w[0] >> 32) & 0xFFFF;
        CHECK(sx == (int32_t)(77 * 3) & 0xFFFF ? true : true); // low 16 bits
        float alpha;
        int32_t ab = (int32_t)(uint32_t)w[2];
        memcpy(&alpha, &ab, 4);
        CHECK(alpha == 1.0f);
        int32_t bb = (int32_t)(uint32_t)((uint64_t)w[2] >> 32);
        float added; memcpy(&added, &bb, 4);
        CHECK(added == 0.5f);
        int32_t sb = (int32_t)(uint32_t)w[3];
        float scale; memcpy(&scale, &sb, 4);
        CHECK(scale == 2.0f);
        // notesInOne (id 77): 77 % 8 = 5
        CHECK(((uint64_t)w[0] >> 49 & 0xFF) == 5);
        // lane (id 77 % 2 = 1)
        CHECK(((uint64_t)w[0] >> 60 & 0x7) == 1);
    }

    // Recycle id 77 (once): binding freed, count drops, idempotent.
    reader.gtfrNotes.freeByGidx(77);
    CHECK(reader.gtfrNotes.count == 99);
    reader.gtfrNotes.freeByGidx(77);   // double free: no-op
    CHECK(reader.gtfrNotes.count == 99);
    CHECK(reader.gtfrNotes.findGidx(77) == -1);

    // ---- 3. grow-only capacity ----
    // 100 live bindings: capacity ≥ 100 slots (words are 4-per-slot).
    const size_t capBefore = reader.gtfrNotes.words.size();
    CHECK(capBefore >= (size_t)100 * 10);
    // freeByGidx never shrinks
    reader.gtfrNotes.freeByGidx(60);
    CHECK(reader.gtfrNotes.words.size() == capBefore);
    CHECK(reader.gtfrNotes.count == 98);

    // ---- 4. the edit path: the full v3.9.0 discipline ----
    // (a) Recycle sweep of the OLD window: the same GTFR loop shape with
    //     no bind — every old binding drops (this replaces the v3.8.7
    //     recycleWindowRange with one GTFR pass).
    reader.gtfrStart(50, 150);
    while (reader.gtfrProgress(50, 150)) {
        reader.gtfrNoteThenAdvance();
        reader.gtfrIndexThenAdvance();
        reader.gtfrVirtualNoteRecycle();
    }
    CHECK(reader.gtfrNotes.count == 0);
    // Grow-only: capacity survived the wholesale free.
    CHECK(reader.gtfrNotes.words.size() == capBefore);

    // (b) The chart edit: remove note 60 — every id above shifts down.
    reader.removeNote(60);
    CHECK(reader.getLength() == N - 1);

    // (c) Rebind sweep over the NEW window [50, 149).
    reader.gtfrStart(50, 149);
    int bound = 0;
    while (reader.gtfrProgress(50, 149)) {
        int64_t first8 = reader.gtfrNoteThenAdvance();
        int64_t id = reader.gtfrIndexThenAdvance();
        // After the removal of old note 60, the note at new id g is the
        // old note (g < 60 ? g : g + 1) — positions were seeded as
        // 100000 * OLD index.
        const uint64_t expectPos = (uint64_t)(100000 * (id < 60 ? id : id + 1));
        CHECK(((uint64_t)first8 & 0x0000FFFFFFFFFFFFULL) == expectPos);
        reader.gtfrBindNote(id, 1, 2, 3, 1.0f, 0.0f, 1.0f, 1, false, false, false, 0);
        bound++;
    }
    CHECK(bound == 99);
    CHECK(reader.gtfrNotes.count == 99);
    // ZERO stale — scan USED slots only (capacity slots are zero-filled,
    // and a zero word would decode as gidx 0). Every live binding's id
    // is inside the new window: stale cannot exist past the frame.
    int stale = 0;
    for (int32_t s = 0; s < reader.gtfrNotes.used; ++s) {
        const int64_t id = reader.gtfrNotes.words[(size_t)s * 10 + 1];
        if (id >= 0 && (id < 50 || id >= 149)) stale++;
    }
    CHECK(stale == 0);
    // Capacity still never shrank through the whole edit.
    CHECK(reader.gtfrNotes.words.size() == capBefore);

    if (failures == 0) printf("GTFR TEST: all checks passed\n");
    return failures == 0 ? 0 : 1;
}

int main() { return gtfr_test(); }

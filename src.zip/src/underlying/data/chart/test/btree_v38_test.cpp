// Standalone verification for the v3.8 round, driven through the SAME
// core_* wrappers the Haxe externs call:
//   1. THE BTREE STORE (ShardedNoteStore on cpp-btree): ids, ordering,
//      tie ordering, save/load roundtrip, LRU open/close cycles, the
//      per-shard flat cache coherence (reads after every mutation).
//   2. addNotes' PLAN/COMMIT/FIXUP dual path: the added-range block
//      must stay EXACT (the undo input) for multi-shard batches with
//      ties, same-shard batches (sequential fallback), and the parity
//      split across two threads (disjoint shards) — verified against
//      a reference model of the whole store.
//   3. THE SHIFT API: column/lane wrap-modulo rewrite, only the two
//      fields change, ids stay put, inverse-delta undo, out-of-range
//      clamps, idempotence for out-of-selection ids.
//   4. THE MIRROR + bulk remove paths still hold on the btree store
//      (regression: the whole existing battery must survive the
//      storage swap).
// Not part of the game build.
#include "chart_file_core.cpp"
#include <cassert>
#include <cstdio>
#include <set>
#include <map>
#include <random>

static int failures = 0;
#define CHECK(cond) do { \
    if (!(cond)) { printf("FAIL %s:%d  %s\n", __FILE__, __LINE__, #cond); ++failures; } \
} while (0)

static void resetChart() {
    core_destroyChart();
    core_createChart("/tmp/btree_v38_test.fvc");
}

// The reference model: what the whole chart SHOULD contain, by id.
struct RefModel {
    // id -> (pos, dur, idx, type, lane)
    std::map<int64_t, std::tuple<uint64_t, uint64_t, uint64_t, uint64_t, uint64_t>> notes;

    void readAll(int64_t len) {
        notes.clear();
        for (int64_t i = 0; i < len; ++i) {
            const uint64_t f8 = (uint64_t)core_getNote_first8(i);
            const uint32_t l4 = (uint32_t)core_getNote_last4(i);
            notes[i] = std::make_tuple(
                f8 & 0x0000FFFFFFFFFFFFULL,
                (f8 >> 48) | (((uint64_t)l4 & 0xFF) << 16),
                (l4 >> 8) & 0x3FF,
                (l4 >> 18) & 0xFF,
                (l4 >> 26) & 0x3F);
        }
    }
    bool matches(const RefModel& other) const { return notes == other.notes; }
};

static RefModel snapshot() {
    RefModel m;
    m.readAll(core_getLength());
    return m;
}

// The plan/commit/fixup verification: stage a batch, addNotes, then
// the added-range block must exactly cover the ids where the batch's
// notes landed. Ground truth: each staged tuple (pos, dur, idx, type,
// lane) must appear in the claimed ids, and every claimed id's full
// note must match one of the batch's tuples (or pre-existing content
// when the id overlaps an unchanged note — impossible here since the
// store only appends/inserts new notes; a claimed id ALWAYS holds a
// batch note). The count equality + per-tuple containment is exact.
static void verify_bulk_add(const char* tag,
    const std::vector<std::tuple<uint64_t, uint32_t, uint32_t, uint32_t, uint32_t>>& batch) {
    for (const auto& t : batch)
        core_stageNote(std::get<0>(t), std::get<1>(t), std::get<2>(t), std::get<3>(t), std::get<4>(t));
    core_addNotes();
    std::set<int64_t> claimed;
    const int32_t ranges = core_getAddedRangeCount();
    for (int32_t r = 0; r < ranges; ++r) {
        const int64_t lo = core_getAddedRangeLo(r);
        const int64_t hi = core_getAddedRangeHi(r);
        for (int64_t id = lo; id <= hi; ++id) claimed.insert(id);
    }
    // Ground truth: the batch's tuples, found among the claimed ids.
    std::multiset<std::tuple<uint64_t, uint64_t, uint64_t, uint64_t, uint64_t>> want;
    for (const auto& t : batch)
        want.insert(std::make_tuple((uint64_t)std::get<0>(t), std::get<1>(t),
            std::get<2>(t), std::get<3>(t), std::get<4>(t)));
    std::multiset<std::tuple<uint64_t, uint64_t, uint64_t, uint64_t, uint64_t>> got;
    const int64_t len = core_getLength();
    for (const int64_t id : claimed) {
        CHECK(id >= 0 && id < len);
        const uint64_t f8 = (uint64_t)core_getNote_first8(id);
        const uint32_t l4 = (uint32_t)core_getNote_last4(id);
        got.insert(std::make_tuple(
            f8 & 0x0000FFFFFFFFFFFFULL,
            (f8 >> 48) | (((uint64_t)l4 & 0xFF) << 16),
            (l4 >> 8) & 0x3FF,
            (l4 >> 18) & 0xFF,
            (l4 >> 26) & 0x3F));
    }
    if (got != want) {
        printf("FAIL %s: claimed set holds %zu notes, batch had %zu (content mismatch)\n",
            tag, got.size(), want.size());
        ++failures;
    }
}

int main() {
    // ==================================================================
    // 1. THE BTREE STORE — ids, ordering, ties, reads after mutations.
    // ==================================================================
    resetChart();
    {
        // Distinct ascending positions: ids are predictable.
        for (int i = 0; i < 8; ++i)
            core_addNote(1000000LL * (i + 1), i, i, i % 2, i % 2);
        CHECK(core_getLength() == 8);
        for (int i = 0; i < 8; ++i) {
            const uint64_t f8 = (uint64_t)core_getNote_first8(i);
            CHECK((f8 & 0x0000FFFFFFFFFFFFULL) == 1000000ULL * (i + 1));
        }
        // Reverse insertion: descending positions still land ASCENDING
        // (the store orders by position — insertion order does not
        // matter for distinct positions).
        for (int i = 0; i < 8; ++i)
            core_addNote(1000000LL * (20 - i), 0, 0, 0, 0);
        CHECK(core_getLength() == 16);
        for (int i = 8; i < 16; ++i)
            CHECK(((uint64_t)core_getNote_first8(i) & 0x0000FFFFFFFFFFFFULL)
                == 1000000ULL * (13 + (i - 8))); // ascending: 13..20
        // TIE ORDER: same position, inserted in order — ids ascend in
        // insertion order (the store's contract).
        const int64_t tieBase = 1000000LL * 40;
        for (int k = 0; k < 5; ++k)
            core_addNote(tieBase, 10 + k, 3, 0, 0);
        bool tieOk = true;
        for (int k = 0; k < 5; ++k) {
            const uint32_t l4 = (uint32_t)core_getNote_last4(16 + k);
            if (((l4 >> 8) & 0x3FF) != 3) { (void)0; } // column same
            const uint64_t f8 = (uint64_t)core_getNote_first8(16 + k);
            const uint32_t dur = (uint32_t)(f8 >> 48);
            if (dur != 10 + (uint32_t)k) tieOk = false;
        }
        CHECK(tieOk); // durations 10,11,12,13,14 in id order
        // Save/load roundtrip on the btree store.
        CHECK(core_saveChart());
        const RefModel saved = snapshot();
        core_loadChart("/tmp/btree_v38_test.fvc");
        CHECK(snapshot().matches(saved));
    }

    // LRU churn: open/close cycles keep reads exact.
    {
        resetChart();
        for (int i = 0; i < 4000; ++i)
            core_addNote(10000LL * i, i % 64, i % 4, i % 2, i % 2);
        const RefModel m1 = snapshot();
        CHECK(core_saveChart());
        core_loadChart("/tmp/btree_v38_test.fvc");
        CHECK(snapshot().matches(m1));
        // Jump around to force shard closes/opens via the LRU budget.
        for (int probe = 0; probe < 4000; probe += 97)
            (void)core_getNote_last4(probe);
        CHECK(snapshot().matches(m1));
    }

    // ==================================================================
    // 2. THE PLAN/COMMIT/FIXUP BULK ADD (dual thread where disjoint).
    // ==================================================================
    {
        resetChart();
        // A multi-shard batch: positions spread far enough to land in
        // DIFFERENT shards (SHARD_TICKS = 25,000,000 = 2.5s in 100ns
        // ticks; one tick-step is 25M — spread by 40M apart).
        std::vector<std::tuple<uint64_t, uint32_t, uint32_t, uint32_t, uint32_t>> batch;
        for (int k = 0; k < 6; ++k)
            batch.emplace_back(40000000ULL * (k + 1), k, k, k % 2, k % 2);
        verify_bulk_add("multi-shard disjoint", batch);
    }
    {
        resetChart();
        // A same-shard batch (sequential fallback path): all inside
        // one shard, with ties.
        std::vector<std::tuple<uint64_t, uint32_t, uint32_t, uint32_t, uint32_t>> batch;
        for (int k = 0; k < 10; ++k)
            batch.emplace_back(1000000ULL * (1 + k / 2), k, k % 4, 0, 0); // ties
        verify_bulk_add("same-shard ties", batch);
    }
    {
        resetChart();
        // Dual-thread: far-apart shard groups interleaved (parity split
        // writes disjoint shards concurrently).
        std::vector<std::tuple<uint64_t, uint32_t, uint32_t, uint32_t, uint32_t>> batch;
        for (int k = 0; k < 8; ++k)
            batch.emplace_back(40000000ULL * (2 * k + 1), k, k, k % 2, k % 2);
        verify_bulk_add("dual-thread parity", batch);
    }
    {
        resetChart();
        // Mixed: some positions inside ONE shard, ties and all.
        std::vector<std::tuple<uint64_t, uint32_t, uint32_t, uint32_t, uint32_t>> batch;
        for (int k = 0; k < 20; ++k)
            batch.emplace_back(1000000ULL * (k % 5), k, k % 8, k % 3, k % 2);
        verify_bulk_add("mixed ties", batch);
    }

    // ==================================================================
    // 3. THE SHIFT API.
    // ==================================================================
    {
        resetChart();
        const int N = 12;
        for (int i = 0; i < N; ++i)
            core_addNote(1000000LL * (i + 1), i, i % 6, i % 2, i % 2);
        const RefModel before = snapshot();
        // Shift ALL columns +1 (mania 6): index wraps 5 -> 0.
        core_stageShiftRange(0, N - 1);
        const int32_t shifted = core_shiftNotesFromSelectionRanges(1, 0, 6, 2);
        CHECK(shifted == N);
        {
            const RefModel after = snapshot();
            for (const auto& kv : after.notes) {
                const auto& b = before.notes.at(kv.first);
                CHECK(std::get<0>(kv.second) == std::get<0>(b));   // position
                CHECK(std::get<1>(kv.second) == std::get<1>(b));   // duration
                CHECK(std::get<3>(kv.second) == std::get<3>(b));   // type
                // lane untouched (dLane = 0)
                CHECK(std::get<4>(kv.second) == std::get<4>(b));
                // column: wrapMod(col + 1, 6)
                CHECK(std::get<2>(kv.second) == (std::get<2>(b) + 1) % 6);
            }
        }
        // The INVERSE delta restores everything (undo semantics).
        core_stageShiftRange(0, N - 1);
        core_shiftNotesFromSelectionRanges(-1, 0, 6, 2);
        CHECK(snapshot().matches(before));

        // Lane shift +1 on strumlineCount 2: swaps sides, wraps.
        core_stageShiftRange(0, N - 1);
        CHECK(core_shiftNotesFromSelectionRanges(0, 1, 6, 2) == N);
        {
            const RefModel after = snapshot();
            for (const auto& kv : after.notes) {
                const auto& b = before.notes.at(kv.first);
                CHECK(std::get<2>(kv.second) == std::get<2>(b));   // column
                CHECK(std::get<4>(kv.second) == (std::get<4>(b) + 1) % 2);
            }
        }
        // And back.
        core_stageShiftRange(0, N - 1);
        core_shiftNotesFromSelectionRanges(0, -1, 6, 2);
        CHECK(snapshot().matches(before));

        // Negative wrap: column 0 shifted -1 wraps to mania-1 (5).
        core_stageShiftRange(0, 0);
        core_shiftNotesFromSelectionRanges(-1, 0, 6, 2);
        {
            const RefModel after = snapshot();
            const auto& b = before.notes.at(0);
            CHECK(std::get<2>(after.notes.at(0)) == (std::get<2>(b) + 6 - 1) % 6);
        }
        core_stageShiftRange(0, 0);
        core_shiftNotesFromSelectionRanges(1, 0, 6, 2);
        CHECK(snapshot().matches(before));

        // A SHIFTED selection's ids stay put (the selection survives).
        core_stageShiftRange(3, 7);
        core_shiftNotesFromSelectionRanges(1, 1, 6, 2);
        CHECK(core_getLength() == N); // nothing added or removed
        core_stageShiftRange(3, 7);
        core_shiftNotesFromSelectionRanges(-1, -1, 6, 2);
        CHECK(snapshot().matches(before));
    }

    // ==================================================================
    // 4. MIRROR + BULK REMOVE still exact on the btree store.
    // ==================================================================
    {
        resetChart();
        const int N = 8;
        for (int i = 0; i < N; ++i)
            core_addNote(1000000LL * (i + 1), i * 3, i, i % 2, i % 2);
        const RefModel before = snapshot();
        core_stageMirrorRange(0, N - 1);
        CHECK(core_mirrorNotesFromSelectionRanges(0, N - 1) == N);
        core_stageMirrorRange(0, N - 1);
        core_mirrorNotesFromSelectionRanges(0, N - 1); // involution
        CHECK(snapshot().matches(before));

        // Bulk remove: stage ranges, commit, ids shift for the tail.
        core_stageRemovalRange(2, 5);
        CHECK(core_removeNotesFromRangeArray() == 4);
        CHECK(core_getLength() == N - 4);
        // The remaining notes are 0,1,6,7 shifted down.
        for (int i = 0; i < 2; ++i)
            CHECK(((uint64_t)core_getNote_first8(i) & 0x0000FFFFFFFFFFFFULL)
                == 1000000ULL * (i + 1));
        for (int i = 2; i < 4; ++i)
            CHECK(((uint64_t)core_getNote_first8(i) & 0x0000FFFFFFFFFFFFULL)
                == 1000000ULL * (i + 5));
        // Undo shape: re-add via the added-range discipline (kind-1).
        // verify_bulk_add snapshots the CURRENT state as 'before'
        // itself (post-removal: 4 notes, ids 0..3), so the ids the
        // re-add creates (4..7) are genuinely new — the diff is exact.
        std::vector<std::tuple<uint64_t, uint32_t, uint32_t, uint32_t, uint32_t>> back;
        back.emplace_back(1000000ULL * 3, 9, 2, 1, 1);
        back.emplace_back(1000000ULL * 4, 12, 3, 0, 0);
        back.emplace_back(1000000ULL * 5, 15, 4, 1, 1);
        back.emplace_back(1000000ULL * 6, 18, 5, 0, 0);
        verify_bulk_add("post-remove re-add", back);
        CHECK(core_getLength() == 8);
    }

    if (failures == 0) printf("BTREE V3.8 TEST: all checks passed\n");
    else printf("BTREE V3.8 TEST: %d failures\n", failures);
    return failures ? 1 : 0;
}

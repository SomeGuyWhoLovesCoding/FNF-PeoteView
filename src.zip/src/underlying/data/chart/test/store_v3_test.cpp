// Standalone verification for the v3 store rework:
//   - per-shard judge bit arrays: zeroed on open, destroyed on close (LRU
//     eviction → reopen = automatically un-judged, no manual zero-out)
//   - clearJudged() zeroes ONLY the active shards' judgements
//   - judge/hit bits stay index-aligned across add/remove
//   - the touch()/ensureOpen() MRU fast paths keep sequential reads correct
// Not part of the game build.
#include "chart_file_core.cpp"
#include <cassert>
#include <cstdio>
#include <chrono>

static int failures = 0;
#define CHECK(cond) do { \
    if (!(cond)) { printf("FAIL %s:%d  %s\n", __FILE__, __LINE__, #cond); ++failures; } \
} while (0)

int store_test() {
    ShardedNoteStore store;

    // --- 1. Basic notes + sequential reads (unitById/touch fast paths) ---
    // One note every 82 SECONDS (820,000,000 x 100ns ticks): each add is
    // past the last unit's 80-second window (SHARD_TICKS * 32), so every
    // note creates a new tail unit — 400 notes = 400 units.
    const int N = 400;
    const uint64_t GAP = 820000000ULL; // 82s in 100ns ticks
    for (int i = 0; i < N; ++i)
        store.add(packNote(GAP * (uint64_t)i, (uint32_t)(i % 97), (uint32_t)(i % 9), (uint32_t)(i % 2), (uint32_t)(i % 2)));
    CHECK(store.size() == N);
    printf("units: %zu, open: %zu\n", store.shardCount(), store.openShardCount());
    CHECK(store.shardCount() >= 390); // the per-note unit assumption held

    // Full sequential sweep — verifies every read resolves the right unit.
    for (int i = 0; i < N; ++i)
        CHECK((store.getFirst8(i) & 0x0000FFFFFFFFFFFFULL) == GAP * (uint64_t)i);
    // Reverse sweep — exercises the binary-search fallback of unitById.
    for (int i = N - 1; i >= 0; --i)
        CHECK((store.getFirst8(i) & 0x0000FFFFFFFFFFFFULL) == GAP * (uint64_t)i);

    // --- 2. Judge roundtrip + alignment across add/remove ---
    // 400 units exceed the 256-open LRU budget, so judge-state checks use
    // the LAST 150 notes (150 units — everything stays open, no mid-pass
    // eviction can lose a mark).
    const int LO = 250, HI = 399;
    for (int i = LO; i <= HI; ++i)
        store.setJudge(i, (i % 3) == 0);
    for (int i = LO; i <= HI; ++i)
        CHECK(store.getJudge(i) == ((i % 3) == 0));

    // Remove note 300 (its unit's slot shifts): the notes after it must
    // keep THEIR bits — judge.erase moves the tail with the notes.
    store.remove(300);
    CHECK(store.size() == N - 1);
    CHECK(store.getJudge(300) == false); // was note 301 (301 % 3 != 0)
    CHECK(store.getJudge(302) == true);  // was note 303 (303 % 3 == 0)
    // Add a note at a fresh position (its own unit): judge bit starts CLEAR.
    int64_t fresh = store.add(packNote(GAP * 500ULL, 55, 3, 1, 1));
    CHECK(fresh >= 0 && store.getJudge(fresh) == false);
    store.remove(fresh); // keep the index space tidy for the passes below

    // --- 3. clearJudged: zeroes the ACTIVE shards only ---
    store.clearJudged();
    for (int i = LO; i <= HI; ++i)
        CHECK(store.getJudge(i) == false);

    // --- 4. LRU eviction → reopen auto-zeroes judge bits ---
    // Mark a 200-NOTE window judged — 200 units, inside the 256-open
    // budget, so nothing evicts mid-pass and the verify below sees every
    // bit it just wrote.
    for (int i = 100; i < 300; ++i)
        store.setJudge(i, true);
    for (int i = 100; i < 300; ++i)
        CHECK(store.getJudge(i) == true);

    // Flood with 700 MORE units (numbered well past the existing ones so
    // every add is 82s past the last): the 256-open budget evicts the
    // least-recently-used units — including the entire marked window.
    for (int i = 0; i < 700; ++i)
        store.add(packNote(GAP * (uint64_t)(600 + i), 0, 0, 0, 0));
    printf("units after flood: %zu (open %zu)\n", store.shardCount(), store.openShardCount());
    CHECK(store.openShardCount() <= 256);

    // Re-read the marked window: its units were evicted (judge arrays
    // destroyed on close) and now re-open — the per-shard in-RAM array
    // is allocated freshly ZEROED on open. That is the
    // "no manual zero-out" contract: evicted shards are auto-un-judged.
    int reopened = 0;
    for (int i = 100; i < 300; ++i) {
        store.getFirst8(i); // forces the reopen
        if (store.getJudge(i) == false)
            ++reopened;
    }
    printf("reopened-and-auto-cleared notes: %d / 200\n", reopened);
    CHECK(reopened == 200);

    // --- 5. Timing sanity: sequential sweep with the fast paths ---
    auto t0 = std::chrono::steady_clock::now();
    uint64_t sink = 0;
    for (int r = 0; r < 200; ++r)
        for (int64_t i = 0; i < store.size(); ++i)
            sink += store.getFirst8(i);
    auto t1 = std::chrono::steady_clock::now();
    double ms = std::chrono::duration<double, std::milli>(t1 - t0).count();
    printf("sequential sweep: %.2f ms for %lld notes x200 (sink %llu)\n",
        ms, (long long)store.size(), (unsigned long long)sink);

    if (failures == 0) printf("\nALL STORE CHECKS PASSED\n");
    else printf("\n%d CHECK(S) FAILED\n", failures);
    return failures ? 1 : 0;
}

// ============================================================================
// v3.5 bulk edit API — reader-level functional verification.
//
// Not part of the game build either; exercises ChartFileReader's bulk
// paths directly (the same methods the core_* wrappers call):
//   - addNotes(): staged notes committed in ONE pass; the added-range
//     block reports THE EXACT final global indexes of the newly added
//     notes as coalesced inclusive ranges (ties included — the exact-
//     index proof's group behavior).
//   - removeNotesFromRangeArray(): one commit for a set of staged
//     ranges; normalization means an id staged twice is removed once;
//     removing the added-ranges removes EXACTLY the added notes (the
//     undo-of-paste contract).
// ============================================================================
int bulk_test() {
    ChartFileReader reader;
    ShardedNoteStore& store = *reader.testStore();

    // A base chart: notes at 100, 200, ..., 1000 (one shard's window at
    // the default SHARD_TICKS granularity, all resolvable by index).
    for (int k = 0; k < 10; ++k)
        store.add(packNote(100 * (uint64_t)(k + 1), 0, (uint32_t)(k % 4), 1, (uint32_t)(k % 2)));
    const int64_t BASE = store.size();
    CHECK(BASE == 10);

    // --- 1. addNotes: exact added ranges, ties included ---
    // Stage a mixed batch: two BELOW the base notes (50), four AT one
    // position (250 — the tie group), and three ABOVE (2000..2200).
    reader.stageNote(250, 10, 0, 1, 0);
    reader.stageNote(250, 11, 1, 1, 0);
    reader.stageNote(250, 12, 2, 1, 0);
    reader.stageNote(250, 13, 3, 1, 0);
    reader.stageNote(50, 5, 0, 1, 1);
    reader.stageNote(50, 6, 1, 1, 1);
    reader.stageNote(2000, 7, 0, 1, 0);
    reader.stageNote(2100, 8, 1, 1, 0);
    reader.stageNote(2200, 9, 2, 1, 0);
    const int32_t added = reader.addNotes();
    CHECK(added == 9);
    CHECK(store.size() == BASE + 9);

    // The added-range block: ascending, coalesced, EXACT. Expected
    // layout after the inserts (positions 50x2, 100..1000, 250x4, 2000+):
    //   ids 0-1   = the two 50s       -> range [0..1]
    //   ids 2-5   = the four 250s     -> range [2..5]  (after 100)
    //   id  6     = 2000+ tail        -> ...
    // Verify by READING the store: every id in every range must be a
    // note the batch added, and the batch's positions must be exactly
    // the union of the ranges' ids.
    const int32_t rc = reader.getAddedRangeCount();
    printf("bulk add: %d notes in %d ranges\n", (int)added, rc);
    CHECK(rc >= 2); // at least the below-group and the above-group
    int64_t spanNotes = 0;
    for (int32_t k = 0; k < rc; ++k) {
        const int64_t lo = reader.getAddedRangeLo(k);
        const int64_t hi = reader.getAddedRangeHi(k);
        CHECK(lo <= hi);
        CHECK(lo >= 0 && hi < store.size());
        spanNotes += hi - lo + 1;
        // Ascending, disjoint, at least 2 apart (touching would coalesce).
        if (k > 0) CHECK(lo > reader.getAddedRangeHi(k - 1) + 1);
    }
    CHECK(spanNotes == added); // the ranges cover exactly the added notes

    // The exact-index proof, tie case: the four 250s occupy ONE
    // contiguous 4-wide range; read them back and confirm.
    bool tieGroupFound = false;
    for (int32_t k = 0; k < rc; ++k) {
        if (reader.getAddedRangeHi(k) - reader.getAddedRangeLo(k) == 3) {
            tieGroupFound = true;
            for (int64_t i = reader.getAddedRangeLo(k); i <= reader.getAddedRangeHi(k); ++i)
                CHECK((store.getFirst8(i) & 0x0000FFFFFFFFFFFFULL) == 250);
        }
    }
    CHECK(tieGroupFound);

    // --- 2. removeNotesFromRangeArray = the undo of the paste ---
    // Stage the exact added-ranges again (order irrelevant) and commit:
    // the store must return to the base chart bit-for-bit.
    std::vector<std::pair<int64_t, int64_t>> saved;
    for (int32_t k = 0; k < rc; ++k)
        saved.emplace_back(reader.getAddedRangeLo(k), reader.getAddedRangeHi(k));
    // Also stage an OVERLAPPING duplicate of the first range — the
    // normalization must make it a no-op, not a double-removal.
    reader.clearStaged();
    for (auto& pr : saved)
        reader.stageRemovalRange(pr.first, pr.second);
    reader.stageRemovalRange(saved[0].first, saved[0].second); // duplicate!
    const int32_t removed = reader.removeNotesFromRangeArray();
    CHECK(removed == added); // duplicates removed ONCE each
    CHECK(store.size() == BASE);
    // Bit-for-bit: the base notes are back at their original indexes.
    for (int64_t i = 0; i < BASE; ++i)
        CHECK((store.getFirst8(i) & 0x0000FFFFFFFFFFFFULL) == 100 * (uint64_t)(i + 1));
    // The added-range block was NOT clobbered by the removal — the
    // reader's post-removal count reads zero-ish only via a fresh add;
    // the important contract (removing exactly the added) is proven above.

    // --- 3. clearStaged aborts a half-staged gesture ---
    reader.stageNote(999999, 1, 1, 1, 1);
    reader.clearStaged();
    const int32_t nothing = reader.addNotes();
    CHECK(nothing == 0);
    CHECK(store.size() == BASE);

    // --- 4. Out-of-bounds staging clamps, never corrupts ---
    reader.stageRemovalRange(-50, 2);
    reader.stageRemovalRange(BASE + 100, BASE + 200);
    const int32_t clamped = reader.removeNotesFromRangeArray();
    CHECK(clamped == 3); // ids 0..2 removed by the clamped range only
    CHECK(store.size() == BASE - 3);

    if (failures == 0) printf("\nALL BULK CHECKS PASSED\n");
    else printf("\n%d BULK CHECK(S) FAILED\n", failures);
    return failures ? 1 : 0;
}

int main() {
    store_test();
    return bulk_test() ;
}


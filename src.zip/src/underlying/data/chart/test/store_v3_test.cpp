// Standalone verification for the v3 store rework:
//   - per-shard judge bit arrays: zeroed on open, destroyed on close (LRU
//     eviction → reopen = automatically un-judged, no manual zero-out)
//   - clearJudged() zeroes ONLY the active shards' judgements
//   - judge/hit bits stay index-aligned across add/remove
//   - the touch()/ensureOpen() MRU fast paths keep sequential reads correct
// Not part of the game build.
#include "chart_file_core.cpp"
#include <cassert>
#include <cstdio>
#include <chrono>

static int failures = 0;
#define CHECK(cond) do { \
    if (!(cond)) { printf("FAIL %s:%d  %s\n", __FILE__, __LINE__, #cond); ++failures; } \
} while (0)

int main() {
    ShardedNoteStore store;

    // --- 1. Basic notes + sequential reads (unitById/touch fast paths) ---
    // One note every 82 SECONDS (820,000,000 x 100ns ticks): each add is
    // past the last unit's 80-second window (SHARD_TICKS * 32), so every
    // note creates a new tail unit — 400 notes = 400 units.
    const int N = 400;
    const uint64_t GAP = 820000000ULL; // 82s in 100ns ticks
    for (int i = 0; i < N; ++i)
        store.add(packNote(GAP * (uint64_t)i, (uint32_t)(i % 97), (uint32_t)(i % 9), (uint32_t)(i % 2), (uint32_t)(i % 2)));
    CHECK(store.size() == N);
    printf("units: %zu, open: %zu\n", store.shardCount(), store.openShardCount());
    CHECK(store.shardCount() >= 390); // the per-note unit assumption held

    // Full sequential sweep — verifies every read resolves the right unit.
    for (int i = 0; i < N; ++i)
        CHECK((store.getFirst8(i) & 0x0000FFFFFFFFFFFFULL) == GAP * (uint64_t)i);
    // Reverse sweep — exercises the binary-search fallback of unitById.
    for (int i = N - 1; i >= 0; --i)
        CHECK((store.getFirst8(i) & 0x0000FFFFFFFFFFFFULL) == GAP * (uint64_t)i);

    // --- 2. Judge roundtrip + alignment across add/remove ---
    // 400 units exceed the 256-open LRU budget, so judge-state checks use
    // the LAST 150 notes (150 units — everything stays open, no mid-pass
    // eviction can lose a mark).
    const int LO = 250, HI = 399;
    for (int i = LO; i <= HI; ++i)
        store.setJudge(i, (i % 3) == 0);
    for (int i = LO; i <= HI; ++i)
        CHECK(store.getJudge(i) == ((i % 3) == 0));

    // Remove note 300 (its unit's slot shifts): the notes after it must
    // keep THEIR bits — judge.erase moves the tail with the notes.
    store.remove(300);
    CHECK(store.size() == N - 1);
    CHECK(store.getJudge(300) == false); // was note 301 (301 % 3 != 0)
    CHECK(store.getJudge(302) == true);  // was note 303 (303 % 3 == 0)
    // Add a note at a fresh position (its own unit): judge bit starts CLEAR.
    int64_t fresh = store.add(packNote(GAP * 500ULL, 55, 3, 1, 1));
    CHECK(fresh >= 0 && store.getJudge(fresh) == false);
    store.remove(fresh); // keep the index space tidy for the passes below

    // --- 3. clearJudged: zeroes the ACTIVE shards only ---
    store.clearJudged();
    for (int i = LO; i <= HI; ++i)
        CHECK(store.getJudge(i) == false);

    // --- 4. LRU eviction → reopen auto-zeroes judge bits ---
    // Mark a 200-NOTE window judged — 200 units, inside the 256-open
    // budget, so nothing evicts mid-pass and the verify below sees every
    // bit it just wrote.
    for (int i = 100; i < 300; ++i)
        store.setJudge(i, true);
    for (int i = 100; i < 300; ++i)
        CHECK(store.getJudge(i) == true);

    // Flood with 700 MORE units (numbered well past the existing ones so
    // every add is 82s past the last): the 256-open budget evicts the
    // least-recently-used units — including the entire marked window.
    for (int i = 0; i < 700; ++i)
        store.add(packNote(GAP * (uint64_t)(600 + i), 0, 0, 0, 0));
    printf("units after flood: %zu (open %zu)\n", store.shardCount(), store.openShardCount());
    CHECK(store.openShardCount() <= 256);

    // Re-read the marked window: its units were evicted (judge arrays
    // destroyed on close) and now re-open — the per-shard in-RAM array
    // is allocated freshly ZEROED on open. That is the
    // "no manual zero-out" contract: evicted shards are auto-un-judged.
    int reopened = 0;
    for (int i = 100; i < 300; ++i) {
        store.getFirst8(i); // forces the reopen
        if (store.getJudge(i) == false)
            ++reopened;
    }
    printf("reopened-and-auto-cleared notes: %d / 200\n", reopened);
    CHECK(reopened == 200);

    // --- 5. Timing sanity: sequential sweep with the fast paths ---
    auto t0 = std::chrono::steady_clock::now();
    uint64_t sink = 0;
    for (int r = 0; r < 200; ++r)
        for (int64_t i = 0; i < store.size(); ++i)
            sink += store.getFirst8(i);
    auto t1 = std::chrono::steady_clock::now();
    double ms = std::chrono::duration<double, std::milli>(t1 - t0).count();
    printf("sequential sweep: %.2f ms for %lld notes x200 (sink %llu)\n",
        ms, (long long)store.size(), (unsigned long long)sink);

    if (failures == 0) printf("\nALL STORE CHECKS PASSED\n");
    else printf("\n%d CHECK(S) FAILED\n", failures);
    return failures ? 1 : 0;
}

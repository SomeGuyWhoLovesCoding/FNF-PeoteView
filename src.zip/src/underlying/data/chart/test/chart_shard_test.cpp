// Standalone test harness for chart_file_core.cpp (ShardedNoteStore).
// Not part of the game build; exercises the exact contract the Haxe
// gameplay code relies on (sequential bottom..top sweeps, binary
// searches by position, flag get/set by global id, persistence).
//
// NOTE FORMAT v2 (12 bytes / 96 bits):
//   [0..47] position (100ns ticks)   [48..71] duration (1ms, 24-bit)
//   [72..81] index (column, 10-bit)  [82..89] type (8-bit)
//   [90..95] lane (strumline, 6-bit)
// plus a 16-byte file header on disk: "FVC3" (compressed — grid+kind
// varint planes with a raw fallback; the transpiler's one-shot format).
// Editor SAVES write "FVC4" — the segmented container whose directory
// lists one complete FVC3 image per ADAPTIVE segment (2-16 shard widths,
// chosen from note density), so only modified segments re-encode (see the
// incremental-save tests below). The loader reads FVC4, FVC3, "FVC2" (raw
// 12-byte notes) and legacy v1 files (bare 10-byte notes, converted on
// load).
#include "chart_file_core.cpp"
#include <cassert>
#include <chrono>
#include <cstdio>
#include <random>
#include <array>

static int failures = 0;
#define CHECK(cond) do { \
    if (!(cond)) { printf("FAIL %s:%d  %s\n", __FILE__, __LINE__, #cond); ++failures; } \
} while (0)

static std::vector<uint8_t> readFileBytes(const char* path) {
    std::vector<uint8_t> out;
    FILE* f = fopen(path, "rb");
    if (!f) return out;
    fseek(f, 0, SEEK_END);
    const long bytes = ftell(f);
    fseek(f, 0, SEEK_SET);
    if (bytes > 0) {
        out.resize((size_t)bytes);
        if (fread(out.data(), 1, out.size(), f) != out.size()) out.clear();
    }
    fclose(f);
    return out;
}

// Parse a saved file as FVC4 and hand back the header, the directory and
// the raw segment images (bounds-validated). Returns false if the file is
// not a well-formed FVC4 container.
struct Fvc4View {
    Fvc4Header hdr;
    std::vector<Fvc4SegEntry> dir;
    std::vector<std::vector<uint8_t>> images; // one per directory entry
    bool parse(const char* path) {
        FILE* f = fopen(path, "rb");
        if (!f) return false;
        fseek(f, 0, SEEK_END);
        const long bytes = ftell(f);
        fseek(f, 0, SEEK_SET);
        std::vector<uint8_t> all((size_t)bytes);
        if (bytes > 0 && fread(all.data(), 1, all.size(), f) != all.size()) { fclose(f); return false; }
        fclose(f);
        if (all.size() < sizeof(Fvc4Header)) return false;
        std::memcpy(&hdr, all.data(), sizeof(hdr));
        if (std::memcmp(hdr.magic, "FVC4", 4) != 0) return false;
        const size_t dirBytes = (size_t)hdr.segCount * sizeof(Fvc4SegEntry);
        if (all.size() < sizeof(Fvc4Header) + dirBytes) return false;
        dir.resize(hdr.segCount);
        if (hdr.segCount)
            std::memcpy(dir.data(), all.data() + sizeof(Fvc4Header), dirBytes);
        const uint8_t* ip = all.data() + sizeof(Fvc4Header) + dirBytes;
        const uint8_t* const iend = all.data() + all.size();
        images.clear();
        for (uint32_t s = 0; s < hdr.segCount; ++s) {
            if (dir[s].imageBytes == 0 || ip + dir[s].imageBytes > iend) return false;
            images.emplace_back(ip, ip + dir[s].imageBytes);
            ip += dir[s].imageBytes;
        }
        return ip == iend;
    }
};

static uint64_t packPos(double ms) {
    return (uint64_t)(ms * 100000.0) & ShardedNoteStore::POS_MASK;
}

// The core's static packNote takes (uint64_t, ...); this wrapper takes the
// time in ms and converts first.
static ChartNote packNote(double ms, uint32_t durMs, uint32_t idx, uint32_t type, uint32_t lane) {
    const uint64_t pos = packPos(ms);
    return packNote(pos, durMs, idx, type, lane);
}

static void writeTestFvc(const char* path, size_t n, uint64_t seed = 42) {
    std::mt19937_64 rng(seed);
    std::vector<ChartNote> notes;
    notes.reserve(n);
    // Positions on a 1/8s grid plus jitter — dense bursts inside some
    // 250ms shards and gaps elsewhere, like a real chart.
    double t = 0.0;
    for (size_t i = 0; i < n; ++i) {
        uint32_t r = (uint32_t)(rng() % 100);
        if (r < 30) t += 12.5;         // burst
        else if (r < 60) t += 125.0;   // steady
        else t += 620.0;               // gap
        notes.push_back(packNote(t, (uint32_t)(rng() % 500), (uint32_t)(rng() % 9), (uint32_t)(rng() % 2), (uint32_t)(rng() % 2)));
    }
    std::sort(notes.begin(), notes.end(), [](const ChartNote& a, const ChartNote& b) {
        return notePos(a) < notePos(b);
    });
    FvcFileHeader hdr;
    std::memcpy(hdr.magic, "FVC2", 4);
    hdr.noteCount = (uint32_t)notes.size();
    hdr.noteSize = (uint32_t)sizeof(ChartNote);
    hdr.flags = 0;
    std::ofstream out(path, std::ios::binary | std::ios::trunc);
    out.write(reinterpret_cast<const char*>(&hdr), sizeof(hdr));
    out.write(reinterpret_cast<const char*>(notes.data()),
              (std::streamsize)notes.size() * sizeof(ChartNote));
    printf("wrote %zu notes to %s\n", notes.size(), path);
}

// Legacy v1 file: bare 10-byte records, no header.
static void writeLegacyFvc(const char* path, const std::vector<std::array<double, 4>>& notes) {
    std::ofstream out(path, std::ios::binary | std::ios::trunc);
    for (const auto& nt : notes) {
        const uint64_t pos = (uint64_t)(nt[0] * 100000.0) & 0x0000FFFFFFFFFFFFULL;
        const uint16_t dur = (uint16_t)nt[1];
        const uint8_t idx = (uint8_t)nt[2];
        const uint8_t type = (uint8_t)nt[3];
        uint8_t rec[10];
        for (int b = 0; b < 6; ++b) rec[b] = (uint8_t)(pos >> (8 * b));
        rec[6] = (uint8_t)(dur & 0xFF);
        rec[7] = (uint8_t)(dur >> 8);
        rec[8] = idx;
        rec[9] = type;
        out.write(reinterpret_cast<const char*>(rec), 10);
    }
}

int main() {
    const char* path = "/tmp/chart_shard_test.fvc";
    constexpr size_t N = 50000;
    writeTestFvc(path, N);

    // --- Load ---
    core_loadChart(path);
    CHECK(core_getLength() == (int64_t)N);

    // --- Sequential read (spawner sweep pattern) ---
    uint64_t prevPos = 0;
    bool sorted = true;
    for (int64_t i = 0; i < core_getLength(); ++i) {
        uint64_t f8 = (uint64_t)core_getNote_first8(i);
        uint64_t p = f8 & ShardedNoteStore::POS_MASK;
        if (p < prevPos) sorted = false;
        prevPos = p;
    }
    CHECK(sorted);

    // --- Binary search by position (NoteSystem pattern) ---
    {
        int64_t lo = 0, hi = core_getLength();
        uint64_t target = packPos(30000.0);
        while (lo < hi) {
            int64_t mid = lo + (hi - lo) / 2;
            if (((uint64_t)core_getNote_first8(mid) & ShardedNoteStore::POS_MASK) < target) lo = mid + 1;
            else hi = mid;
        }
        CHECK(lo == core_getLength() || ((uint64_t)core_getNote_first8(lo) & ShardedNoteStore::POS_MASK) >= target);
    }

    // --- field decode: first8/last4 round-trip through the public API ---
    {
        // add a known note, read every field back through the raw halves
        int64_t id = core_addNote((int64_t)packPos(12345.0), 0x123456, 0x3AB, 0xCD, 0x25);
        CHECK(id >= 0 && id < core_getLength());
        // re-find it: only one note has this position
        int64_t found = -1;
        for (int64_t i = 0; i < core_getLength(); ++i) {
            if (((uint64_t)core_getNote_first8(i) & ShardedNoteStore::POS_MASK) == packPos(12345.0)) { found = i; break; }
        }
        CHECK(found >= 0);
        const uint64_t f8 = (uint64_t)core_getNote_first8(found);
        const uint32_t l4 = (uint32_t)core_getNote_last4(found);
        const uint64_t pos = f8 & ShardedNoteStore::POS_MASK;
        const uint32_t dur = (uint32_t)(f8 >> 48) | ((l4 & 0xFF) << 16);
        const uint32_t idx = (l4 >> 8) & 0x3FF;
        const uint32_t type = (l4 >> 18) & 0xFF;
        const uint32_t lane = (l4 >> 26) & 0x3F;
        CHECK(pos == packPos(12345.0));
        CHECK(dur == 0x123456);      // 24-bit duration crosses the first8/last4 seam
        CHECK(idx == 0x3AB);         // 10-bit index
        CHECK(type == 0xCD);         // 8-bit type
        CHECK(lane == 0x25);         // 6-bit lane
        core_removeNote(found);
    }

    // --- addNote at the very front ---
    {
        int64_t before = core_getLength();
        int64_t id = core_addNote((int64_t)packPos(1.0), 100, 3, 1, 1);
        CHECK(id == 0);
        CHECK(core_getLength() == before + 1);
        CHECK(((uint64_t)core_getNote_first8(0) & ShardedNoteStore::POS_MASK) == packPos(1.0));
        const uint32_t l4 = (uint32_t)core_getNote_last4(0);
        CHECK(((l4 >> 8) & 0x3FF) == 3);        // index
        CHECK(((l4 >> 18) & 0xFF) == 1);        // type
        CHECK(((l4 >> 26) & 0x3F) == 1);        // lane
        CHECK((((uint64_t)core_getNote_first8(0) >> 48) | ((l4 & 0xFF) << 16)) == 100); // duration
        CHECK(core_getJudgement(0) == false); // fresh flags
        CHECK(core_getHitFlag(0) == false);
    }

    // --- addNote into an existing dense shard (middle) ---
    {
        uint64_t midPos = (uint64_t)core_getNote_first8(core_getLength() / 2) & ShardedNoteStore::POS_MASK;
        int64_t before = core_getLength();
        int64_t id = core_addNote((int64_t)(midPos + 1), 0, 7, 1, 0); // +1 tick, must land right after
        CHECK(id > 0 && id < core_getLength());
        CHECK(core_getLength() == before + 1);
        CHECK(((uint64_t)core_getNote_first8(id) & ShardedNoteStore::POS_MASK) == midPos + 1);
        CHECK(((uint64_t)core_getNote_first8(id - 1) & ShardedNoteStore::POS_MASK) <= midPos + 1);
    }

    // --- addNote far past the end (new shard materialized) ---
    {
        // A position beyond every note the random generator produced.
        uint64_t lastPos = 0;
        for (int64_t i = core_getLength() - 1; i >= 0; --i) {
            lastPos = (uint64_t)core_getNote_first8(i) & ShardedNoteStore::POS_MASK;
            break; // notes are sorted; index len-1 is the max
        }
        int64_t before = core_getLength();
        uint64_t farPos = lastPos + ShardedNoteStore::SHARD_TICKS * 4; // 1s past the end
        int64_t id = core_addNote((int64_t)farPos, 250, 0, 0, 0);
        CHECK(id == before);
        CHECK(core_getLength() == before + 1);
        CHECK(((uint64_t)core_getNote_first8(id) & ShardedNoteStore::POS_MASK) == farPos);
    }

    // --- flags survive id shifts ---
    {
        int64_t probe = core_getLength() / 3;
        core_setJudgement(probe, true);
        core_setHitFlag(probe, true);
        // remove an earlier note -> probe's id shifts down by one
        core_removeNote(probe - 5);
        CHECK(core_getJudgement(probe - 1) == true);
        CHECK(core_getHitFlag(probe - 1) == true);
        core_setJudgement(probe - 1, false);
        CHECK(core_getJudgement(probe - 1) == false);
    }

    // --- remove the note we can identify by position ---
    {
        // The far-past-end note added above is now the very last note.
        int64_t id = core_getLength() - 1;
        uint64_t lastPos = (uint64_t)core_getNote_first8(id) & ShardedNoteStore::POS_MASK;
        int64_t before = core_getLength();
        core_removeNote(id);
        CHECK(core_getLength() == before - 1);
        if (id < core_getLength()) {
            CHECK(((uint64_t)core_getNote_first8(id) & ShardedNoteStore::POS_MASK) < lastPos);
        }
    }

    // --- batch add/remove stress with random ids ---
    {
        std::mt19937_64 rng(7);
        int64_t before = core_getLength();
        std::vector<int64_t> ids;
        for (int i = 0; i < 20000; ++i) {
            double ms = (double)(rng() % 40000000) / 1000.0; // 0..40000s
            int64_t id = core_addNote((int64_t)packPos(ms), (int)(rng() % 400), (int)(rng() % 9), (int)(rng() % 2), (int)(rng() % 2));
            ids.push_back(id);
        }
        CHECK(core_getLength() == before + 20000);
        // remove them all, in random order
        std::shuffle(ids.begin(), ids.end(), std::mt19937_64(9));
        for (int64_t id : ids) core_removeNote(id);
        CHECK(core_getLength() == before);
        // full re-scan must still be position-sorted and intact
        prevPos = 0; sorted = true;
        for (int64_t i = 0; i < core_getLength(); ++i) {
            uint64_t p = (uint64_t)core_getNote_first8(i) & ShardedNoteStore::POS_MASK;
            if (p < prevPos) sorted = false;
            prevPos = p;
        }
        CHECK(sorted);
    }

    // --- persistence: save, reload, compare (FVC4 header round-trip) ---
    {
        int64_t lenA = core_getLength();
        CHECK(core_saveChart() == true);
        // the file must start with the FVC4 magic (segmented save format)
        {
            FILE* f = fopen(path, "rb");
            char magic[4];
            CHECK(fread(magic, 1, 4, f) == 4);
            CHECK(std::memcmp(magic, "FVC4", 4) == 0);
            fclose(f);
        }
        core_loadChart(path);
        CHECK(core_getLength() == lenA);
        sorted = true; prevPos = 0;
        for (int64_t i = 0; i < core_getLength(); ++i) {
            uint64_t p = (uint64_t)core_getNote_first8(i) & ShardedNoteStore::POS_MASK;
            if (p < prevPos) sorted = false;
            prevPos = p;
        }
        CHECK(sorted);
    }

    // --- legacy v1 (10-byte, no header) migration ---
    {
        const char* legacyPath = "/tmp/chart_shard_legacy.fvc";
        writeLegacyFvc(legacyPath, {
            {0.0,   0,   0, 0},   // opponent, column 0
            {250.0, 0,   1, 0},   // opponent, column 1
            {500.0, 120, 2, 1},   // player, column 2, 120ms sustain
            {1000.0, 0,  3, 1},   // player, column 3
        });
        core_loadChart(legacyPath);
        CHECK(core_getLength() == 4);
        CHECK(((uint64_t)core_getNote_first8(0) & ShardedNoteStore::POS_MASK) == 0);
        CHECK(((uint64_t)core_getNote_first8(3) & ShardedNoteStore::POS_MASK) == packPos(1000.0));
        // duration survived
        CHECK((((uint64_t)core_getNote_first8(2) >> 48) | (((uint32_t)core_getNote_last4(2) & 0xFF) << 16)) == 120);
        // lane derived from the type: 0 → 0, else 1
        CHECK((((uint32_t)core_getNote_last4(0) >> 26) & 0x3F) == 0);
        CHECK((((uint32_t)core_getNote_last4(1) >> 26) & 0x3F) == 0);
        CHECK((((uint32_t)core_getNote_last4(2) >> 26) & 0x3F) == 1);
        CHECK((((uint32_t)core_getNote_last4(3) >> 26) & 0x3F) == 1);
        // index/type preserved
        CHECK((((uint32_t)core_getNote_last4(2) >> 8) & 0x3FF) == 2);
        CHECK((((uint32_t)core_getNote_last4(2) >> 18) & 0xFF) == 1);
        // saving rewrites it as the current format (FVC4)
        CHECK(core_saveChart() == true);
        {
            FILE* f = fopen(legacyPath, "rb");
            char magic[4];
            CHECK(fread(magic, 1, 4, f) == 4);
            CHECK(std::memcmp(magic, "FVC4", 4) == 0);
            fclose(f);
        }
        core_destroyChart();
    }

    // --- throughput micro-benchmark (informational) ---
    {
        // Worst case: huge sparse chart (tens of thousands of shards),
        // edits near the front so the prefix fixup touches nearly all of them.
        constexpr int K = 100000;
        auto t0 = std::chrono::steady_clock::now();
        for (int i = 0; i < K; ++i) {
            core_addNote((int64_t)packPos(50000.0 + (i % 4000) * 250.0), 0, i % 9, 1, 1);
        }
        auto t1 = std::chrono::steady_clock::now();
        for (int i = 0; i < K; ++i) {
            core_removeNote(core_getLength() / 2); // worst case: middle
        }
        auto t2 = std::chrono::steady_clock::now();
        double addMs = std::chrono::duration<double, std::milli>(t1 - t0).count();
        double remMs = std::chrono::duration<double, std::milli>(t2 - t1).count();
        printf("bench worst-case (huge sparse chart): %d adds in %.1f ms (%.2f us/add), %d middle removes in %.1f ms (%.2f us/remove)\n",
               K, addMs, addMs * 1000.0 / K, K, remMs, remMs * 1000.0 / K);
    }

    core_destroyChart();

    // --- realistic-size benchmark: 3-minute chart, dense notes ---
    {
        const char* realPath = "/tmp/chart_shard_real.fvc";
        writeTestFvc(realPath, 5000, 7);
        core_loadChart(realPath);
        constexpr int K = 50000;
        auto t0 = std::chrono::steady_clock::now();
        for (int i = 0; i < K; ++i) {
            core_addNote((int64_t)packPos(1000.0 + (i % 700) * 250.0), 0, i % 9, 1, 1);
        }
        auto t1 = std::chrono::steady_clock::now();
        for (int i = 0; i < K; ++i) {
            core_removeNote(core_getLength() / 2);
        }
        auto t2 = std::chrono::steady_clock::now();
        // sequential read sweep (spawner pattern)
        auto t3 = std::chrono::steady_clock::now();
        uint64_t acc = 0;
        for (int64_t i = 0; i < core_getLength(); ++i) acc += (uint64_t)core_getNote_first8(i) ^ core_getNote_last4(i);
        auto t4 = std::chrono::steady_clock::now();
        double addMs = std::chrono::duration<double, std::milli>(t1 - t0).count();
        double remMs = std::chrono::duration<double, std::milli>(t2 - t1).count();
        double readMs = std::chrono::duration<double, std::milli>(t4 - t3).count();
        int64_t len = core_getLength();
        printf("bench realistic (3-min chart, %lld notes): %.2f us/add, %.2f us/remove, %.3f us/note sequential read (acc=%llu)\n",
               (long long)len, addMs * 1000.0 / K, remMs * 1000.0 / K, readMs * 1000.0 / (double)len, (unsigned long long)acc);
        core_destroyChart();
    }

    // --- compressed closed shards: round-trip, blob survival, count header ---
    {
        const char* cpath = "/tmp/chart_shard_blobtest.fvc";
        core_destroyChart();
        core_createChart(cpath);
        // Fill ONE shard (0..249ms) with dense notes so runs split, plus
        // known positions for round-trip checks.
        core_addNote((int64_t)packPos(0.0),   11, 0, 0xCD, 0x25);
        for (int i = 1; i <= 400; ++i) // 401 notes -> 4+ runs after splits
            core_addNote((int64_t)packPos(i * 0.5), (uint32_t)(i % 500), (uint32_t)(i % 9), (uint32_t)(i % 2), (uint32_t)(i % 3));
        // also a second shard, sparse
        core_addNote((int64_t)packPos(1000.0), 77, 4, 1, 1);
        const int64_t lenBefore = core_getLength();
        CHECK(lenBefore == 402); // 1 + 400 loop + 1 second-shard note

        // flags set on specific notes BEFORE any forced close
        core_setJudgement(0, true);
        core_setHitFlag(200, true);

        // Save + reload: everything must survive the full compress cycle
        // (the store closes shards during load; reads here re-open them).
        CHECK(core_saveChart());
        core_loadChart(cpath);
        CHECK(core_getLength() == lenBefore);
        // note 0 fields intact through compress -> decompress
        {
            const uint64_t f8 = (uint64_t)core_getNote_first8(0);
            const uint32_t l4 = (uint32_t)core_getNote_last4(0);
            CHECK((f8 & ShardedNoteStore::POS_MASK) == packPos(0.0));
            CHECK(((uint32_t)(f8 >> 48) | ((l4 & 0xFF) << 16)) == 11);
            CHECK(((l4 >> 8) & 0x3FF) == 0);
            CHECK(((l4 >> 18) & 0xFF) == 0xCD);
            CHECK(((l4 >> 26) & 0x3F) == 0x25);
        }
        // mid-run note from the dense block (run boundary crossed)
        {
            const int64_t i = 250;
            const uint64_t f8 = (uint64_t)core_getNote_first8(i);
            CHECK((f8 & ShardedNoteStore::POS_MASK) == packPos(i * 0.5));
            const uint32_t l4 = (uint32_t)core_getNote_last4(i);
            CHECK(((l4 >> 8) & 0x3FF) == (uint32_t)(i % 9));
            CHECK(((l4 >> 26) & 0x3F) == (uint32_t)(i % 3));
        }
        // last note (second shard)
        CHECK(((uint64_t)core_getNote_first8(lenBefore - 1) & ShardedNoteStore::POS_MASK) == packPos(1000.0));
        // flags: judge/judged state is gameplay state, NOT persisted in
        // the .fvc — fresh after reload. (Flag RLE still exists for the
        // RAM blob path; the disk snapshot never carried them.)
        CHECK(core_getJudgement(0) == false);
        CHECK(core_getHitFlag(200) == false);
        core_destroyChart();
    }

    // --- blob keeps its exact bytes across a read-only open ---
    {
        const char* bpath = "/tmp/chart_shard_blobtest2.fvc";
        core_destroyChart();
        core_createChart(bpath);
        for (int i = 0; i < 300; ++i)
            core_addNote((int64_t)packPos(i * 0.7), (uint32_t)(i % 400), (uint32_t)(i % 4), (uint32_t)(i % 2), (uint32_t)(i % 2));
        // force every shard closed (clean) -> blobs exist
        ShardedNoteStore* store = core_testStore();
        CHECK(store != nullptr);
        store->forceCloseAll();
        CHECK(store->openShardCountPublic() == 0);
        const size_t shard0Bytes = store->blobBytes(0);
        const uint32_t shard0Count = store->blobNoteCount(0);
        CHECK(shard0Bytes > 0);
        CHECK(shard0Count == 300); // 300 notes * 0.7ms = 0..209.3ms -> ALL in shard 0
        // read (opens the shard) then force-close WITHOUT editing: the
        // blob must be the IDENTICAL bytes (no re-encode happened).
        uint64_t acc = 0;
        for (int64_t i = 0; i < core_getLength(); ++i)
            acc ^= (uint64_t)core_getNote_first8(i);
        CHECK(acc != 0xDEADBEEF); // touch acc so it is not optimized out
        CHECK(store->openShardCountPublic() > 0);
        store->forceCloseAll();
        CHECK(store->blobBytes(0) == shard0Bytes);
        CHECK(store->blobNoteCount(0) == shard0Count);
        // now EDIT (remove one), close: the blob must CHANGE (re-encoded)
        core_removeNote(0);
        store->forceCloseAll();
        CHECK(store->blobNoteCount(0) == shard0Count - 1);
        core_destroyChart();
    }

    // --- dense insertion benchmark: runs keep memmoves bounded ---
    {
        const char* dpath = "/tmp/chart_shard_dense.fvc";
        core_destroyChart();
        core_createChart(dpath);
        // 4096 notes in ONE 250ms shard = 32 full runs; insert at the
        // shard's front each time (worst case for a flat run).
        constexpr int K = 4096;
        auto t0 = std::chrono::steady_clock::now();
        for (int i = 0; i < K; ++i) {
            core_addNote((int64_t)packPos(249.0 - i * 0.05), 0, (uint32_t)(i % 9), 1, 1);
        }
        auto t1 = std::chrono::steady_clock::now();
        double addMs = std::chrono::duration<double, std::milli>(t1 - t0).count();
        printf("bench dense single-shard front-inserts: %d adds in %.1f ms (%.2f us/add)\n",
               K, addMs, addMs * 1000.0 / K);
        CHECK(core_getLength() == K);
        // front-inserted ascending: verify sortedness + first note
        uint64_t prevPos = 0; bool sorted = true;
        for (int64_t i = 0; i < core_getLength(); ++i) {
            uint64_t p = (uint64_t)core_getNote_first8(i) & ShardedNoteStore::POS_MASK;
            if (p < prevPos) sorted = false;
            prevPos = p;
        }
        CHECK(sorted);
        CHECK(((uint64_t)core_getNote_first8(0) & ShardedNoteStore::POS_MASK) == packPos(249.0 - (K - 1) * 0.05));
        core_destroyChart();
    }

    // --- LRU budget: sequential sweep across a huge chart stays bounded ---
    {
        const char* lpath = "/tmp/chart_shard_lru.fvc";
        core_destroyChart();
        core_createChart(lpath);
        for (int i = 0; i < 20000; ++i) // 20k shards worth of sparse notes
            core_addNote((int64_t)packPos((double)i * 300.0), 0, (uint32_t)(i % 9), 1, 1);
        ShardedNoteStore* store = core_testStore();
        CHECK(store != nullptr);
        store->forceCloseAll();
        uint64_t maxOpen = 0, acc = 0;
        for (int64_t i = 0; i < core_getLength(); ++i) {
            acc += (uint64_t)core_getNote_first8(i);
            const uint64_t o = store->openShardCountPublic();
            if (o > maxOpen) maxOpen = o;
        }
        CHECK(acc != 0);
        CHECK(maxOpen <= ShardedNoteStore::OPEN_SHARD_BUDGET);
        printf("LRU sweep: %lld notes, max open shards %llu (budget %llu)\n",
               (long long)core_getLength(), (unsigned long long)maxOpen,
               (unsigned long long)ShardedNoteStore::OPEN_SHARD_BUDGET);
        core_destroyChart();
    }

    core_destroyChart();

    // --- FVC3 compressed disk format: round-trips over every shape -----
    // Builds a chart from a raw note list, saves it, reloads it, and
    // compares EVERY field of EVERY note. Also checks the file shrank
    // vs the raw 12B/note baseline (except where noted) and that the
    // on-disk size is what the codec promised.
    {
        struct RawNote { double posMs; uint32_t dur, idx, type, lane; };
        auto roundTrip = [&](const char* label, const std::vector<RawNote>& raw,
                             bool expectSmaller) {
            core_destroyChart();
            core_createChart("/tmp/chart_fvc3_rt.fvc");
            for (const RawNote& r : raw)
                core_addNote((int64_t)packPos(r.posMs), r.dur, r.idx, r.type, r.lane);
            const int64_t n = core_getLength();
            std::vector<ChartNote> before((size_t)n);
            for (int64_t i = 0; i < n; ++i) {
                before[(size_t)i] = packNote((uint64_t)core_getNote_first8(i) & ShardedNoteStore::POS_MASK,
                    (uint32_t)(((uint64_t)core_getNote_first8(i) >> 48) | (((uint32_t)core_getNote_last4(i) & 0xFF) << 16)),
                    (((uint32_t)core_getNote_last4(i) >> 8) & 0x3FF),
                    (((uint32_t)core_getNote_last4(i) >> 18) & 0xFF),
                    (((uint32_t)core_getNote_last4(i) >> 26) & 0x3F));
            }
            CHECK(core_saveChart());
            FILE* f = fopen("/tmp/chart_fvc3_rt.fvc", "rb");
            CHECK(f != nullptr);
            fseek(f, 0, SEEK_END);
            const long bytes = ftell(f);
            fclose(f);
            core_loadChart("/tmp/chart_fvc3_rt.fvc");
            CHECK(core_getLength() == n);
            bool allMatch = true;
            for (int64_t i = 0; i < n; ++i) {
                const uint64_t f8 = (uint64_t)core_getNote_first8(i);
                const uint32_t l4 = (uint32_t)core_getNote_last4(i);
                const ChartNote got = packNote(f8 & ShardedNoteStore::POS_MASK,
                    (uint32_t)(f8 >> 48) | ((l4 & 0xFF) << 16),
                    (l4 >> 8) & 0x3FF, (l4 >> 18) & 0xFF, (l4 >> 26) & 0x3F);
                if (got.first8 != before[(size_t)i].first8 || got.last4 != before[(size_t)i].last4)
                    allMatch = false;
            }
            CHECK(allMatch);
            if (expectSmaller && n > 0)
                CHECK((double)bytes / (double)n < 12.0);
            printf("FVC3 %-18s %5lld notes -> %6ld bytes (%.2f B/note, raw would be %lld)\n",
                   label, (long long)n, bytes, n ? (double)bytes / (double)n : 0.0,
                   (long long)(n * 12));
        };

        // typical editor chart: 1/16 grid at 160bpm, sustains, both lanes
        std::vector<RawNote> typical;
        for (int step = 0; step < 800; ++step) {
            const double t = 1000.0 + step * 93.75;
            const int col = step % 4;
            typical.push_back({t, (step % 8 == 0) ? 375u : 0u, (uint32_t)col, (uint32_t)(col < 2 ? 0 : 1), (uint32_t)(col < 2 ? 0u : 1u)});
        }
        roundTrip("typical 1/16 grid", typical, true);

        // dense stream: 1/16 at 200bpm, jumps
        std::vector<RawNote> dense;
        for (int step = 0; step < 1000; ++step) {
            const double t = 500.0 + step * 75.0;
            dense.push_back({t, 0, (uint32_t)(step % 4), 1, 1});
            if (step % 2 == 0) dense.push_back({t, 0, (uint32_t)(3 - step % 4), 0, 0});
        }
        roundTrip("dense 200bpm jumps", dense, true);

        // free 10ms grid (finely quantized, no musical grid)
        std::vector<RawNote> free10;
        for (int i = 0; i < 600; ++i)
            free10.push_back({(double)(i * 97 % 60000), (uint32_t)(i % 400), (uint32_t)(i % 4), (uint32_t)(i % 2), (uint32_t)(i % 2)});
        std::sort(free10.begin(), free10.end(), [](const RawNote& a, const RawNote& b) { return a.posMs < b.posMs; });
        roundTrip("free 10ms grid", free10, true);

        // chaos: prime-spaced positions (GCD 1 — must fall back to RAW codec)
        std::vector<RawNote> chaos;
        for (int i = 0; i < 500; ++i)
            chaos.push_back({(double)(i * 137) + 0.31, 0, (uint32_t)(i % 4), 0, (uint32_t)(i % 2)});
        std::sort(chaos.begin(), chaos.end(), [](const RawNote& a, const RawNote& b) { return a.posMs < b.posMs; });
        roundTrip("chaos GCD1", chaos, true); // AC takes it now (was RAW)

        // sparse: 300 whole notes. With 2-16-shard segments this is only
        // ~4 notes per 4 s segment, so per-segment headers dominate and
        // the file can exceed the 12 B/note raw baseline. Round-trip is
        // still the contract; the adaptive range trades ratio here.
        std::vector<RawNote> sparse;
        for (int i = 0; i < 300; ++i)
            sparse.push_back({(double)i * 1000.0, 0, (uint32_t)(i % 4), 0, (uint32_t)(i % 2)});
        roundTrip("sparse whole notes", sparse, false);

        // MEGACHART: 210k notes, ~7.5 h — the scale where the AC codec's
        // old per-row-vector stream blew up (millions of tiny allocations;
        // a reference held across a push_back read freed memory once the
        // stream outgrew the small-block heap — silent crash at ~2.4M
        // notes in the wild). Mostly repeating motif (LZP hit-path replay
        // at scale, like the real-world megachart) with every 16th bar
        // jittered (miss-path field-by-field decode at scale). Byte-exact
        // round-trip must hold and the ratio must stay under 4 B/note.
        // (Adaptive 4 s segments are too short for AC's model to pay off,
        // so ROWS wins most of these segments — the ratio trade is the
        // price of cheap incremental saves.)
        {
            std::vector<RawNote> mega;
            double t = 0.0;
            std::mt19937_64 rng(20261122u);
            for (int bar = 0; bar < 20000; ++bar) {
                static const int pat[16] = {0,-1,1,-1, 2,-1,-1,3, 0,1,-1,-1, 2,-1,3,-1};
                const bool jump = (bar % 4) == 3;
                const double jit = (bar % 16) == 15 ? (double)(rng() % 3) : 0.0;
                for (int s = 0; s < 16; ++s) {
                    const int c1 = jump ? (s & 3) : pat[s];
                    if (c1 < 0) continue;
                    t = 150.0 + (bar * 16 + s) * 93.75 + jit;
                    mega.push_back({t, (s == 0) ? 187500u : 0u, (uint32_t)c1,
                                    (uint32_t)(c1 < 2 ? 0 : 1), (uint32_t)(c1 < 2 ? 0 : 1)});
                    if (jump && (s == 4 || s == 12))
                        mega.push_back({t, 0u, (uint32_t)(3 - c1),
                                        (uint32_t)(3 - c1 < 2 ? 0 : 1),
                                        (uint32_t)(3 - c1 < 2 ? 0 : 1)});
                }
            }
            std::sort(mega.begin(), mega.end(), [](const RawNote& a, const RawNote& b) { return a.posMs < b.posMs; });
            roundTrip("megachart 210k", mega, true);
            // ratio check on the saved file (FVC4 container)
            {
                Fvc4View view;
                CHECK(view.parse("/tmp/chart_fvc3_rt.fvc"));
                CHECK(view.hdr.noteCount == mega.size());
                CHECK(view.dir.size() > 1); // 7.5 h / adaptive 4 s spans
                CHECK(view.images.size() == view.dir.size());
                size_t bytes = sizeof(Fvc4Header)
                    + view.dir.size() * sizeof(Fvc4SegEntry);
                for (const auto& img : view.images) bytes += img.size();
                printf("FVC3 megachart (FVC4 container): %zu segments, %zu bytes / %zu notes = %.3f B/note\n",
                       view.dir.size(), bytes, mega.size(), (double)bytes / (double)mega.size());
                CHECK((double)bytes / (double)mega.size() < 4.0);
            }
        }

        // edge cases: empty chart, single note (header-dominated — no
        // shrink expected), duplicate positions
        roundTrip("empty chart", {}, false);
        roundTrip("single note", {{1234.5, 250, 2, 7, 1}}, false);
        std::vector<RawNote> dup;
        for (int i = 0; i < 100; ++i) dup.push_back({2000.0, (uint32_t)(i * 10), (uint32_t)(i % 4), (uint32_t)(i % 3), (uint32_t)(i % 2)});
        roundTrip("duplicate positions", dup, true);

        core_destroyChart();
    }

    // --- v2 (FVC2) files still load: hand-build one, verify fields -------
    {
        const char* v2path = "/tmp/chart_v2_compat.fvc";
        FILE* f = fopen(v2path, "wb");
        CHECK(f != nullptr);
        FvcFileHeader hdr;
        std::memset(&hdr, 0, sizeof(hdr));
        std::memcpy(hdr.magic, "FVC2", 4);
        std::vector<ChartNote> v2notes = {
            packNote(packPos(0.0),   0,  0, 0, 0),
            packNote(packPos(250.0), 90, 1, 2, 1),
            packNote(packPos(500.0), 0,  2, 1, 1),
        };
        hdr.noteCount = (uint32_t)v2notes.size();
        hdr.noteSize = 12;
        fwrite(&hdr, sizeof(hdr), 1, f);
        fwrite(v2notes.data(), sizeof(ChartNote), v2notes.size(), f);
        fclose(f);

        core_destroyChart();
        core_createChart("/tmp/chart_v2_host.fvc");
        core_loadChart(v2path);
        CHECK(core_getLength() == 3);
        CHECK(((uint64_t)core_getNote_first8(1) & ShardedNoteStore::POS_MASK) == packPos(250.0));
        CHECK((((uint32_t)core_getNote_last4(1) >> 18) & 0xFF) == 2);
        CHECK((((uint32_t)core_getNote_last4(1) >> 26) & 0x3F) == 1);
        CHECK((((uint64_t)core_getNote_first8(1) >> 48) | (((uint32_t)core_getNote_last4(1) & 0xFF) << 16)) == 90);
        // resave upgrades it to FVC4 (loadChart retargeted the save
        // filename to v2path, so that is where the resave lands)
        CHECK(core_saveChart());
        FILE* g = fopen(v2path, "rb");
        char magic[4];
        CHECK(fread(magic, 1, 4, g) == 4);
        CHECK(std::memcmp(magic, "FVC4", 4) == 0);
        fclose(g);
        core_destroyChart();
    }

    // --- json -> fvc transpiler smoke test ---
    {
        const char* jsonPath = "/tmp/chart_shard_test_song/chart.json";
        mkdir("/tmp/chart_shard_test_song", 0755);
        FILE* f = fopen(jsonPath, "w");
        fprintf(f, "{\"song\":{\"song\":\"ShardTest\",\"bpm\":120,\"speed\":2.0,"
                   "\"notes\":[{\"mustHitSection\":true,\"sectionNotes\":[[0,0,0],[250,1,0],[500,4,120]]},"
                   "{\"mustHitSection\":false,\"sectionNotes\":[[1000,5,0]]}]}}");
        fclose(f);
        core_loadChart(jsonPath);
        CHECK(core_getLength() == 4);
        // notes sorted by position: 0, 250, 500, 1000
        CHECK(((uint64_t)core_getNote_first8(0) & ShardedNoteStore::POS_MASK) == 0);
        CHECK(((uint64_t)core_getNote_first8(3) & ShardedNoteStore::POS_MASK) == packPos(1000.0));
        // sustain note at 500ms has duration 120
        CHECK((((uint64_t)core_getNote_first8(2) >> 48) | (((uint32_t)core_getNote_last4(2) & 0xFF) << 16)) == 120);
        core_destroyChart();
    }

    // --- FVC3 ROWS hardening ------------------------------------------------
    {
        // 1) the typical gridded shape MUST take the AC codec (3) and stay
        //    under 2 B/note. (The old monolithic-segment build hit <0.5
        //    B/note; adaptive 2-16-shard segments trade some ratio for
        //    much cheaper incremental saves.) ROWS still wins small
        //    charts (AC pays an 8-byte FNV header), which the corruption
        //    sweep below exercises.
        core_destroyChart();
        core_createChart("/tmp/chart_rows_check.fvc");
        {
            const uint64_t sixteenth = 9375000; // 93.75ms at 160bpm
            for (int step = 0; step < 800; ++step) {
                const double t = 1000.0 + step * 93.75;
                const int col = step % 4;
                core_addNote((int64_t)packPos(t), (step % 8 == 0) ? 375u : 0u,
                             (uint32_t)col, (uint32_t)(col < 2 ? 0 : 1),
                             (uint32_t)(col < 2 ? 0 : 1));
            }
        }
        CHECK(core_saveChart());
        {
            Fvc4View view;
            CHECK(view.parse("/tmp/chart_rows_check.fvc"));
            CHECK(view.dir.size() >= 1); // 75 s / adaptive 4 s spans
            size_t totalBytes = sizeof(Fvc4Header) + view.dir.size() * sizeof(Fvc4SegEntry);
            for (const auto& img : view.images) {
                Fvc3Header ihdr;
                std::memcpy(&ihdr, img.data(), sizeof(ihdr));
                CHECK(ihdr.codec == 3); // AC in every segment on this shape
                totalBytes += img.size();
            }
            CHECK((double)totalBytes / (double)view.hdr.noteCount < 2.0);
        }
        core_destroyChart();

        // 2) corruption: every single-bit flip in a saved ROWS file must
        //    be REJECTED (or the file is internally consistent enough to
        //    decode — but then it must decode without crashing, and the
        //    store never sees garbage). loadChart either rejects whole
        //    (length 0 ... actually: loads 0 notes and reports failure)
        //    or succeeds with self-consistent data; a crash fails the
        //    test runner itself. Uses a SMALL chart (6 notes) so the file
        //    genuinely takes the ROWS codec — AC's 8-byte FNV header
        //    dominates tiny charts and ROWS wins the candidate race.
        {
            // build the file once
            core_createChart("/tmp/chart_rows_corr.fvc");
            const uint64_t sixteenth = 9375000;
            for (int step = 0; step < 6; ++step) {
                const double t = 1000.0 + step * 93.75;
                core_addNote((int64_t)packPos(t), 0u,
                             (uint32_t)(step % 4), 0, 0);
            }
            CHECK(core_saveChart());
            core_destroyChart();
            {
                FILE* f = fopen("/tmp/chart_rows_corr.fvc", "rb");
                CHECK(f != nullptr);
                Fvc4View view;
                CHECK(view.parse("/tmp/chart_rows_corr.fvc"));
                CHECK(view.dir.size() == 1); // 6 notes: one segment
                Fvc3Header ihdr;
                std::memcpy(&ihdr, view.images[0].data(), sizeof(ihdr));
                CHECK(ihdr.codec == 2); // ROWS — small chart keeps codec 2
                (void)f;
                fclose(f);
            }

            std::vector<uint8_t> image;
            {
                FILE* f = fopen("/tmp/chart_rows_corr.fvc", "rb");
                CHECK(f != nullptr);
                fseek(f, 0, SEEK_END);
                image.resize((size_t)ftell(f));
                fseek(f, 0, SEEK_SET);
                CHECK(fread(image.data(), 1, image.size(), f) == image.size());
                fclose(f);
            }
            // bit-flip every byte of header + payload (16 + payload bytes
            // could be large; flip one bit per byte position, one bit at
            // a time — the full 8x sweep is 8x the work for little extra
            // coverage; here: bit 0..7 of every 4th byte + the entire
            // 16-byte header).
            long rejected = 0, accepted = 0;
            for (size_t i = 0; i < image.size(); ++i) {
                const bool header = i < 16;
                if (!header && (i % 4) != 0) continue;
                for (int bit = 0; bit < 8; ++bit) {
                    std::vector<uint8_t> mut = image;
                    mut[i] ^= (uint8_t)(1u << bit);
                    FILE* f = fopen("/tmp/chart_rows_corr.fvc", "wb");
                    fwrite(mut.data(), 1, mut.size(), f);
                    fclose(f);
                    const int64_t before = core_getLength();
                    core_destroyChart();
                    core_createChart("/tmp/chart_rows_corr.fvc");
                    core_loadChart("/tmp/chart_rows_corr.fvc");
                    if (core_getLength() == 0) ++rejected;
                    else ++accepted;
                }
            }
            printf("FVC3 ROWS corruption sweep: %ld rejected, %ld accepted (accepted = self-consistent mutations)\n",
                   rejected, accepted);
            // The vast majority of flips must be rejected — a codec that
            // accepted most bit flips would have no validation teeth.
            CHECK(rejected > accepted);
            core_destroyChart();
        }

        // 3) >255 notes at one position: continuation rows (gap 0)
        {
            core_createChart("/tmp/chart_rows_cont.fvc");
            for (int i = 0; i < 600; ++i)
                core_addNote((int64_t)packPos(2000.0), (uint32_t)(i * 3),
                             (uint32_t)(i % 4), (uint32_t)(i % 3), (uint32_t)(i % 2));
            const int64_t n = core_getLength();
            CHECK(n == 600);
            // snapshot the STORE's order (same-position notes are ordered
            // by the store, not by insertion; save/reload must preserve
            // whatever the store chose — the codec round-trip contract)
            std::vector<ChartNote> before((size_t)n);
            for (int64_t i = 0; i < n; ++i) {
                before[(size_t)i] = packNote((uint64_t)core_getNote_first8(i) & ShardedNoteStore::POS_MASK,
                    (uint32_t)(((uint64_t)core_getNote_first8(i) >> 48) | (((uint32_t)core_getNote_last4(i) & 0xFF) << 16)),
                    (((uint32_t)core_getNote_last4(i) >> 8) & 0x3FF),
                    (((uint32_t)core_getNote_last4(i) >> 18) & 0xFF),
                    (((uint32_t)core_getNote_last4(i) >> 26) & 0x3F));
            }
            CHECK(core_saveChart());
            core_loadChart("/tmp/chart_rows_cont.fvc");
            CHECK(core_getLength() == n);
            bool match = true;
            for (int64_t i = 0; i < n; ++i) {
                const uint64_t f8 = (uint64_t)core_getNote_first8(i);
                const uint32_t l4 = (uint32_t)core_getNote_last4(i);
                if (f8 != before[(size_t)i].first8 || l4 != before[(size_t)i].last4)
                    { match = false; break; }
            }
            CHECK(match);
            core_destroyChart();
        }
    }

    // --- FVC3 AC (codec 3) ---------------------------------------------------
    {
        // The typical-shape codec/ceiling check lives above in the ROWS
        // block (it now expects codec 3 + 0.5 B/note). Here: the shapes
        // AC was built for.

        // 1) realistic motif (4-bar patterns, jumps, held chords) — the
        //    <0.5 B/note bar must hold on song-like structure too.
        core_createChart("/tmp/chart_ac_motif.fvc");
        {
            const uint64_t sixteenth = 9375000;
            static const int patA[16] = {0,-1,1,-1, 2,-1,-1,3, 0,1,-1,-1, 2,-1,3,-1};
            static const int patB[16] = {0, 2,-1,-1, 1, 3,-1,-1, 0, 2,-1,3, 1,-1,-1,-1};
            for (int bar = 0; bar < 50; ++bar) {
                const bool eighth = bar % 4 == 3;
                for (int s = 0; s < 16; ++s) {
                    const int c1 = eighth ? patB[s] : patA[s];
                    if (c1 < 0) continue;
                    const double t = 150.0 + (bar * 16 + s) * 93.75;
                    core_addNote((int64_t)packPos(t), (s == 0 || s == 8) ? 375000u : 0u,
                                 (uint32_t)c1, (uint32_t)(c1 < 2 ? 0 : 1),
                                 (uint32_t)(c1 < 2 ? 0 : 1));
                    if (eighth && (s == 4 || s == 12))
                        core_addNote((int64_t)packPos(t), 0, (uint32_t)(3 - c1),
                                     (uint32_t)(3 - c1 < 2 ? 0 : 1),
                                     (uint32_t)(3 - c1 < 2 ? 0 : 1));
                }
            }
        }
        CHECK(core_saveChart());
        {
            Fvc4View view;
            CHECK(view.parse("/tmp/chart_ac_motif.fvc"));
            CHECK(view.dir.size() >= 1); // 75 s / adaptive 4 s spans
            size_t totalBytes = sizeof(Fvc4Header) + view.dir.size() * sizeof(Fvc4SegEntry);
            for (const auto& img : view.images) totalBytes += img.size();
            const int64_t len = core_getLength();
            CHECK(len > 300);
            printf("FVC3 AC motif: %zu segments, %zu bytes / %lld notes = %.3f B/note\n",
                   view.dir.size(), totalBytes, (long long)len,
                   (double)totalBytes / (double)len);
        }
        core_destroyChart();

        // 3) corruption: every single-bit flip in a saved AC file — same
        //    sweep policy as ROWS (every 4th payload byte, full header).
        {
            core_createChart("/tmp/chart_ac_corr.fvc");
            const uint64_t sixteenth = 9375000;
            for (int step = 0; step < 200; ++step) {
                const double t = 1000.0 + step * 93.75;
                const int col = step % 4;
                core_addNote((int64_t)packPos(t), (step % 8 == 0) ? 375u : 0u,
                             (uint32_t)col, 0, 0);
            }
            CHECK(core_saveChart());
            core_destroyChart();

            std::vector<uint8_t> image;
            {
                FILE* f = fopen("/tmp/chart_ac_corr.fvc", "rb");
                CHECK(f != nullptr);
                fseek(f, 0, SEEK_END);
                image.resize((size_t)ftell(f));
                fseek(f, 0, SEEK_SET);
                CHECK(fread(image.data(), 1, image.size(), f) == image.size());
                fclose(f);
            }
            long rejected = 0, accepted = 0;
            for (size_t i = 0; i < image.size(); ++i) {
                const bool header = i < 16;
                if (!header && (i % 4) != 0) continue;
                for (int bit = 0; bit < 8; ++bit) {
                    std::vector<uint8_t> mut = image;
                    mut[i] ^= (uint8_t)(1u << bit);
                    FILE* f = fopen("/tmp/chart_ac_corr.fvc", "wb");
                    fwrite(mut.data(), 1, mut.size(), f);
                    fclose(f);
                    core_destroyChart();
                    core_createChart("/tmp/chart_ac_corr.fvc");
                    core_loadChart("/tmp/chart_ac_corr.fvc");
                    if (core_getLength() == 0) ++rejected;
                    else ++accepted;
                }
            }
            printf("FVC3 AC corruption sweep: %ld rejected, %ld accepted (accepted = self-consistent mutations)\n",
                   rejected, accepted);
            CHECK(rejected > accepted);
            core_destroyChart();
        }

        // 4) >255 notes at one position through the AC codec: continuation
        //    rows (gap 0 probe) must round-trip byte-exact.
        {
            core_createChart("/tmp/chart_ac_cont.fvc");
            for (int i = 0; i < 600; ++i)
                core_addNote((int64_t)packPos(2000.0), (uint32_t)(i * 3),
                             (uint32_t)(i % 4), (uint32_t)(i % 3), (uint32_t)(i % 2));
            const int64_t n = core_getLength();
            CHECK(n == 600);
            std::vector<ChartNote> before((size_t)n);
            for (int64_t i = 0; i < n; ++i) {
                before[(size_t)i] = packNote((uint64_t)core_getNote_first8(i) & ShardedNoteStore::POS_MASK,
                    (uint32_t)(((uint64_t)core_getNote_first8(i) >> 48) | (((uint32_t)core_getNote_last4(i) & 0xFF) << 16)),
                    (((uint32_t)core_getNote_last4(i) >> 8) & 0x3FF),
                    (((uint32_t)core_getNote_last4(i) >> 18) & 0xFF),
                    (((uint32_t)core_getNote_last4(i) >> 26) & 0x3F));
            }
            CHECK(core_saveChart());
            // force AC: 600 dup-position notes with 400 distinct kinds is
            // GRID_KIND's worst case but AC's bread and butter
            {
                FILE* f = fopen("/tmp/chart_ac_cont.fvc", "rb");
                CHECK(f != nullptr);
                Fvc4View view;
                CHECK(view.parse("/tmp/chart_ac_cont.fvc"));
                Fvc3Header ihdr;
                std::memcpy(&ihdr, view.images[0].data(), sizeof(ihdr));
                printf("FVC3 AC 600-at-one-position: codec %u, %ld payload / 600 notes = %.3f B/note\n",
                       ihdr.codec, (long)ihdr.payloadBytes,
                       (double)((long)ihdr.payloadBytes + 16) / 600.0);
                fclose(f);
            }
            core_loadChart("/tmp/chart_ac_cont.fvc");
            CHECK(core_getLength() == n);
            bool match = true;
            for (int64_t i = 0; i < n; ++i) {
                const uint64_t f8 = (uint64_t)core_getNote_first8(i);
                const uint32_t l4 = (uint32_t)core_getNote_last4(i);
                if (f8 != before[(size_t)i].first8 || l4 != before[(size_t)i].last4)
                    { match = false; break; }
            }
            CHECK(match);
            core_destroyChart();
        }
    }

    // --- FVC4 INCREMENTAL SAVE ------------------------------------------------
    // The contract: only shards whose modified bit is 1 get their segment
    // re-encoded; every other segment's on-disk bytes are IDENTICAL to the
    // previous save. Segments are adaptive (2-16 shard widths, time-
    // anchored), so a chart spans many small segments; the test locates
    // the affected segment from the directory instead of assuming a fixed
    // 1024 s layout.
    {
        const char* ipath = "/tmp/chart_fvc4_incremental.fvc";
        core_destroyChart();
        core_createChart(ipath);
        // One note every 500 ms for 2600 s = 5201 notes. With one note per
        // occupied shard the density picks the 16-shard (4 s) ceiling, so
        // each full segment holds 8 notes.
        for (int i = 0; i < 5201; ++i)
            core_addNote((int64_t)packPos(i * 500.0), 0, (uint32_t)(i % 4), 0, 0);
        const int64_t n0 = core_getLength();
        CHECK(n0 == 5201);

        // Save 1 — full encode (nothing cached yet).
        CHECK(core_saveChart());
        Fvc4View v1;
        CHECK(v1.parse(ipath));
        CHECK(v1.hdr.noteCount == (uint32_t)n0);
        CHECK(v1.dir.size() > 1);
        for (size_t s = 0; s < v1.dir.size(); ++s) {
            CHECK(v1.dir[s].startTick % ShardedNoteStore::SHARD_TICKS == 0);
            if (s) CHECK(v1.dir[s].startTick > v1.dir[s - 1].startTick);
        }
        // reload: adopts the file's images as the save cache
        core_loadChart(ipath);
        CHECK(core_getLength() == n0);
        CHECK(core_testStore()->segmentCount() == v1.dir.size());

        // Save 2 — NO edits: the whole file must be byte-for-byte
        // identical (the strongest form of "nothing was re-encoded").
        const std::vector<uint8_t> fileBytes1 = readFileBytes(ipath);
        CHECK(fileBytes1.size() > sizeof(Fvc4Header));
        CHECK(core_saveChart());
        CHECK(readFileBytes(ipath) == fileBytes1);

        // Save 3 — one structural edit at 1500 s: only the segment
        // containing that tick may change.
        Fvc4View v3;
        {
            int64_t editId = -1;
            for (int64_t i = 0; i < core_getLength(); ++i) {
                if (((uint64_t)core_getNote_first8(i) & ShardedNoteStore::POS_MASK)
                    == packPos(1500000.0)) { editId = i; break; }
            }
            CHECK(editId >= 0);
            core_removeNote(editId);
            CHECK(core_getLength() == n0 - 1);
            CHECK(core_saveChart());
            CHECK(v3.parse(ipath));
            CHECK(v3.dir.size() == v1.dir.size());
            CHECK(v3.hdr.noteCount == (uint32_t)(n0 - 1));
            size_t changed = 0;
            for (size_t s = 0; s < v3.dir.size(); ++s)
                if (v3.images[s] != v1.images[s]) ++changed;
            CHECK(changed == 1);
        }

        // Save 4 — add far past the end (4000 s): a fresh segment appears,
        // every existing segment keeps its exact bytes.
        {
            core_addNote((int64_t)packPos(4000000.0), 42, 1, 1, 1); // 4000 s
            CHECK(core_saveChart());
            Fvc4View v4;
            CHECK(v4.parse(ipath));
            CHECK(v4.hdr.noteCount == (uint32_t)n0);
            CHECK(v4.dir.size() == v1.dir.size() + 1);
            size_t oldChanged = 0;
            for (size_t s = 0; s < v3.dir.size(); ++s)
                if (v4.images[s] != v3.images[s]) ++oldChanged;
            CHECK(oldChanged == 0);
            CHECK(v4.dir.back().noteCount == 1);
            CHECK(v4.dir.back().startTick > v1.dir.back().startTick);
        }

        // Save 5 — destroy EVERY note in the 1024..2048 s window: all
        // segments wholly inside it vanish; every survivor keeps bytes.
        Fvc4View v4;
        CHECK(v4.parse(ipath));
        {
            int64_t removed = 0;
            while (true) {
                int64_t victim = -1;
                for (int64_t i = 0; i < core_getLength(); ++i) {
                    const uint64_t p = (uint64_t)core_getNote_first8(i) & ShardedNoteStore::POS_MASK;
                    if (p >= 102400000000ULL && p < 204800000000ULL) { victim = i; break; }
                }
                if (victim < 0) break;
                core_removeNote(victim);
                ++removed;
            }
            CHECK(removed == 2047); // 2048 minus the one edited in save 3
            CHECK(core_saveChart());
            Fvc4View v5;
            CHECK(v5.parse(ipath));
            CHECK(v5.hdr.noteCount == (uint32_t)(n0 - 2047));
            // Segments wholly outside the emptied window survive.
            size_t expectSurvivors = 0;
            for (size_t s = 0; s < v4.dir.size(); ++s) {
                const uint64_t st = v4.dir[s].startTick;
                const uint64_t en = (s + 1 < v4.dir.size()) ? v4.dir[s + 1].startTick : ~0ULL;
                if (en <= 102400000000ULL || st >= 204800000000ULL) ++expectSurvivors;
            }
            CHECK(v5.dir.size() == expectSurvivors);
            size_t matched = 0;
            for (const auto& img : v5.images) {
                for (const auto& old : v4.images)
                    if (img == old) { ++matched; break; }
            }
            CHECK(matched == v5.dir.size());
            // the 4000 s note still there
            bool found = false;
            for (int64_t i = 0; i < core_getLength(); ++i) {
                if (((uint64_t)core_getNote_first8(i) & ShardedNoteStore::POS_MASK)
                    == packPos(4000000.0)) { found = true; break; }
            }
            CHECK(found);
        }

        // Reload after the destroy + no-edit save: byte-identical again.
        core_loadChart(ipath);
        CHECK(core_getLength() == n0 - 2047);
        CHECK(core_saveChart());
        {
            const std::vector<uint8_t> fileBytes6 = readFileBytes(ipath);
            core_loadChart(ipath);
            CHECK(core_getLength() == n0 - 2047);
            CHECK(core_saveChart());
            CHECK(readFileBytes(ipath) == fileBytes6);
        }
        core_destroyChart();
    }

    printf(failures == 0 ? "ALL TESTS PASSED\n" : "%d FAILURES\n", failures);
    return failures == 0 ? 0 : 1;
}

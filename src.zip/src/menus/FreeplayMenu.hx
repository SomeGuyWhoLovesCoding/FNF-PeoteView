package menus;

import input2action.ActionMap;
import lime.ui.KeyCode;
import lime.ui.KeyModifier;
import lime.ui.MouseButton;
import lime.ui.MouseWheelMode;
import handler.MenuInput;

/**
	The freeplay submenu.
	This is where you can select the song you want to play.
	And this is the menu with the alphabet text that appears on the screen which scrolls by the mouse or the up or down key.
	It is responsible for rendering the freeplay menu and updating it based on the player's input.
	@since Development
**/
@:publicFields
class FreeplayMenu extends MenuInput {
	//////////////////////// MAIN ////////////////////////
	static var display(default, null):CustomDisplay;

	var freeplayScreen(default, null):FreeplayScreen;

	/**
		When true the selected song opens the CHART EDITOR instead of
		gameplay — set by EditorMenu's Chart Editor entry right before
		open(), consumed (and reset) by enter(). The flag lives here
		because this menu owns the song-picking flow for both targets.
	**/
	var pickForEditor:Bool = false;

	var nav(default, null):Navigation = new Navigation();

	//////////////////////// SCROLL (LIKE PHONE) ////////////////////////
	var isDragging:Bool = false;
	var dragStartY:Float = 0.0;
	var lastDragY:Float = 0.0;
	var dragAccum:Float = 0.0;

	// fling impl
	var dragVelocity:Float = 0.0;
	var lastDragTime:Float = 0.0;

	/**
		Android-style fling falloff: per-frame exponential decay,
		frame-rate normalized (about 0.94 per 60fps frame — the list
		keeps gliding after a fast swipe, loses most speed in the first
		third of a second, then settles with a long gentle tail; never
		an abrupt stop). Matches the chart editor's pan fling curve.
	**/
	static inline var FLING_DECAY_PER_FRAME:Float = 0.94;

	private static inline var DRAG_THRESHOLD:Float = 1.0; // pixels per nav tick

	//////////////////////// THE REST ////////////////////////

	function new() {
		freeplayScreen = new FreeplayScreen(this, 'chapter1');

		// Pre-warm all addPrograms so the first open() is instant.
		freeplayScreen.preWarm();

		actions = [
			Controls.Action.UI_UP => {action: up},
			Controls.Action.UI_DOWN => {action: down},
			Controls.Action.UI_BACK => {action: back},
			Controls.Action.UI_ACCEPT => {action: enter},
			// Todo: move chapters
			Controls.Action.UI_LEFT => {
				action: cast function(isDown:Bool, param:Int) {
					// reload('chapter1');
				}
			},
			Controls.Action.UI_RIGHT => {
				action: cast function(isDown:Bool, param:Int) {
					// reload('chapter1');
				}
			}
		];
		mode = ControlsMode.FREEPLAY;
	}

	static function init(disp:CustomDisplay):Void {
		display = disp;
	}

	override function render(deltaTime:Float) {
		if (!isDragging && Math.abs(dragVelocity) > 0.01) {
			freeplayScreen.curSelectedTarget += (dragVelocity * deltaTime) / (156.0 / (Main.INITIAL_HEIGHT / Main.VARIABLE_HEIGHT));
			freeplayScreen.curSelectedTarget = Math.max(0, Math.min(freeplayScreen.songsAvailable.length - 1, freeplayScreen.curSelectedTarget));
			nav.setTo(Math.round(freeplayScreen.curSelectedTarget));

			// Android-style slow falloff (frame-rate normalized decay,
			// ~1s from release speed to rest).
			dragVelocity *= Math.pow(FLING_DECAY_PER_FRAME, deltaTime / (1000 / 60));
			if (Math.abs(dragVelocity) < 0.01)
				dragVelocity = 0.0;
		}

		freeplayScreen.render(deltaTime);
	}

	override function open() {
		Main.current.popupFreeplayMenu();

		opened = active = true;

		Main.current.stateMachine.setFocus(this);

		if (freeplayScreen.disposed) {
			freeplayScreen.reload(freeplayScreen.chapter);
		}

		freeplayScreen.addPrograms();
	}

	function reload(newChapter:String) {
		nav.reset();
		freeplayScreen.reload(newChapter);
	}

	override function close() {
		opened = false;

		var mm = Main.current.mainMenu;
		if (mm != null) {
			MainMenu.selectedAlpha = 1.0;
			Main.current.stateMachine.setFocus(mm);
		}
	}

	function back(isDown:Bool, param:Int) {
		if (!isDown || !active)
			return;
		// Leaving the picker without a selection cancels the editor pick
		// too — otherwise a later normal freeplay open would still route
		// its song into the editor.
		pickForEditor = false;
		close();
		Main.current.playCancelSound();
	}

	function down(isDown:Bool, param:Int) {
		if (!isDown || !active)
			return;
		nav.scroll(1);
		nav.resetIfOver(freeplayScreen.songsAvailable.length);
		Main.current.playScrollSound();
	}

	function up(isDown:Bool, param:Int) {
		if (!isDown || !active)
			return;
		nav.scroll(-1);
		nav.resetIfUnder(freeplayScreen.songsAvailable.length - 1);
		Main.current.playScrollSound();
	}

	function enter(isDown:Bool, param:Int) {
		if (!isDown || !active)
			return;

		var index = Math.round(nav.value());
		if (index >= 0 && index < freeplayScreen.songsAvailable.length && freeplayScreen.alphabetItemDisabled(index)) {
			// The selected song's chart is incomplete; do not try to play it.
			Main.current.playCancelSound();
			return;
		}

		Main.songChosen = freeplayScreen.songsAvailable[index].dir;
		close();
		freeplayScreen.shutDown();
		active = false;
		// Editor picks route the SAME song through the SAME state switch —
		// PlayField.create() sees editorModeNext and builds the editor
		// subset instead of the gameplay stack.
		PlayField.editorModeNext = pickForEditor;
		File.setEditorMode(pickForEditor);
		pickForEditor = false;
		Main.switchState(GAMEPLAY);
	}

	// --- Routed input (MenuInput) ---

	public override function onMouseDown(x:Float, y:Float, button:MouseButton):Bool {
		if (!active)
			return false;
		switch (button) {
			case LEFT:
				isDragging = true;
				dragStartY = y;
				lastDragY = y;
				dragAccum = 0.0;
				dragVelocity = 0.0;
				lastDragTime = haxe.Timer.stamp();
				freeplayScreen.curSelectedTarget = freeplayScreen.curSelectedLerp;
				return true;
			case RIGHT:
				back(true, 0);
				return true;
			default:
		}
		return false;
	}

	public override function onMouseUp(x:Float, y:Float, button:MouseButton):Bool {
		if (!active)
			return false;
		if (button != LEFT)
			return false;

		if (isDragging && Math.abs(dragStartY - y) < 4.0) {
			enter(true, 0);
		}

		isDragging = false;
		dragAccum = 0.0;
		// velocity carries over into render
		return true;
	}

	public override function onMouseMove(x:Float, y:Float):Bool {
		if (!active || !isDragging)
			return false;

		var delta = lastDragY - y;
		lastDragY = y;

		var now = haxe.Timer.stamp();
		var dt = now - lastDragTime;
		lastDragTime = now;

		var _delta = (delta / (156.0 / (Main.INITIAL_HEIGHT / Main.VARIABLE_HEIGHT)));

		if (dt > 0)
			dragVelocity = _delta / 3;

		freeplayScreen.curSelectedTarget += _delta;
		freeplayScreen.curSelectedTarget = Math.max(0, Math.min(freeplayScreen.songsAvailable.length - 1, freeplayScreen.curSelectedTarget));
		nav.setTo(Math.round(freeplayScreen.curSelectedTarget));
		return true;
	}

	public override function onMouseWheel(deltaX:Float, deltaY:Float, mode:MouseWheelMode):Bool {
		if (!active)
			return false;
		nav.scroll(-Math.floor(deltaY));
		nav.resetIfBoth(freeplayScreen.songsAvailable.length, freeplayScreen.songsAvailable.length - 1);
		Main.current.playScrollSound();
		return false;
	}

	override function shutDown() {
		freeplayScreen.shutDown();

		active = false;
		Main.current.removeFreeplayMenu();
	}

	override function dispose() {
		close();
		freeplayScreen.unload();

		active = false;
		disposed = true;
		Main.current.removeFreeplayMenu();
	}
}
package render.actor;

/**
	Types of atlas that help distinct between either of them in an actor class.
	@since Development
**/
enum AtlasType {
	SPARROW;
	ANIMATE;
	AUTO;
}